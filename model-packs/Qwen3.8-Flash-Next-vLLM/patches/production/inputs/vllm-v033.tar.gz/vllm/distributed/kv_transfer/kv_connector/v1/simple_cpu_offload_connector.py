# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""SimpleCPUOffloadConnector: minimal CPU KV cache offloading."""

from collections.abc import Iterable
from typing import TYPE_CHECKING, Any

import torch

from vllm.config import VllmConfig
from vllm.distributed.kv_events import KVCacheEvent
from vllm.distributed.kv_transfer.kv_connector.v1.base import (
    KVConnectorBase_V1,
    KVConnectorMetadata,
    KVConnectorRole,
    SupportsHMA,
)
from vllm.distributed.kv_transfer.kv_connector.v1.metrics import (
    KVConnectorPromMetrics,
    KVConnectorStats,
    PromMetric,
    PromMetricT,
)
from vllm.logger import init_logger
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.metrics.cache_hit_source import CacheHitSource
from vllm.v1.outputs import KVConnectorOutput
from vllm.v1.simple_kv_offload.manager import (
    BoundaryStoreStats,
    SimpleCPUOffloadScheduler,
)
from vllm.v1.simple_kv_offload.metadata import (
    SimpleCPUOffloadMetadata,
)
from vllm.v1.simple_kv_offload.metrics import (
    SimpleCPUOffloadPromMetrics,
    SimpleCPUOffloadStats,
)
from vllm.v1.simple_kv_offload.worker import (
    SimpleCPUOffloadWorker,
)

if TYPE_CHECKING:
    from vllm.forward_context import ForwardContext
    from vllm.v1.attention.backend import AttentionMetadata
    from vllm.v1.core.block_pool import BlockPool
    from vllm.v1.core.kv_cache_manager import KVCacheBlocks
    from vllm.v1.kv_cache_interface import KVCacheConfig
    from vllm.v1.request import Request

logger = init_logger(__name__)

# Default CPU capacity: 8 GB
DEFAULT_CPU_CAPACITY_BYTES = 8 * (1024**3)

VALID_KV_OFFLOAD_BACKENDS = ("cpu", "disk")
# Keys that only apply to the disk backend, warned about under "cpu".
_DISK_ONLY_KEYS = (
    "disk_path",
    "disk_capacity_bytes",
    "disk_buffer_slots",
    "use_page_cache",
)


def _find_simple_cpu_offload_connector(
    connector: KVConnectorBase_V1,
) -> "SimpleCPUOffloadConnector | None":
    if isinstance(connector, SimpleCPUOffloadConnector):
        return connector
    child_connectors = getattr(connector, "_connectors", None)
    if child_connectors:
        for child in child_connectors:
            found = _find_simple_cpu_offload_connector(child)
            if found is not None:
                return found
    return None


class SimpleCPUOffloadConnector(KVConnectorBase_V1, SupportsHMA):
    """CPU KV cache offloading with custom kernel transfers and BlockPool LRU."""

    @property
    def requires_kv_delivery(self) -> bool:
        # Runs as kv_both, but is a best-effort cache: a dropped save is just a
        # future cache miss, so opt out of the producer-role default.
        return False

    def __init__(
        self,
        vllm_config: VllmConfig,
        role: KVConnectorRole,
        kv_cache_config: "KVCacheConfig",
    ):
        super().__init__(vllm_config, role, kv_cache_config)

        enable_prefix_caching = vllm_config.cache_config.enable_prefix_caching
        extra_config = self._kv_transfer_config.kv_connector_extra_config or {}

        cpu_capacity_bytes = int(
            extra_config.get("cpu_bytes_to_use", DEFAULT_CPU_CAPACITY_BYTES)
        )
        # cpu_bytes_to_use is server-wide for compatibility;
        # cpu_bytes_to_use_per_rank overrides for per-rank capacity.
        world_size = vllm_config.parallel_config.world_size
        cpu_capacity_per_rank = cpu_capacity_bytes // world_size
        if "cpu_bytes_to_use_per_rank" in extra_config:
            explicit = int(extra_config["cpu_bytes_to_use_per_rank"])
            if explicit != cpu_capacity_per_rank:
                logger.warning(
                    "cpu_bytes_to_use_per_rank (%.2f GB) != "
                    "cpu_bytes_to_use/world_size (%.2f GB). Using per-rank value.",
                    explicit / (1024**3),
                    cpu_capacity_per_rank / (1024**3),
                )
            cpu_capacity_per_rank = explicit

        # When set, num_cpu_blocks overrides automatic pool sizing from byte budgets
        # (including cpu_bytes_to_use and cpu_bytes_to_use_per_rank), allowing ranks
        # with different KV layouts (e.g. PP stages) to use the same pool size.
        # Byte budgets still bound capacity.
        num_cpu_blocks = extra_config.get("num_cpu_blocks")
        if num_cpu_blocks is not None and (
            type(num_cpu_blocks) is not int or num_cpu_blocks <= 0
        ):
            raise ValueError("num_cpu_blocks must be a positive integer")

        lazy_offload = bool(extra_config.get("lazy_offload", False))

        kv_offload_backend = str(extra_config.get("kv_offload_backend", "cpu"))
        if kv_offload_backend not in VALID_KV_OFFLOAD_BACKENDS:
            raise ValueError(
                f"Unknown kv_offload_backend {kv_offload_backend!r}; "
                f"expected one of {VALID_KV_OFFLOAD_BACKENDS}"
            )
        disk_mode = kv_offload_backend == "disk"
        self._cache_hit_source = (
            CacheHitSource.DISK if disk_mode else CacheHitSource.HOST
        )

        disk_path = extra_config.get("disk_path", None) or None
        disk_capacity_bytes = int(
            extra_config.get("disk_capacity_bytes", 100 * (1024**3))
        )
        disk_buffer_slots = max(1, int(extra_config.get("disk_buffer_slots", 2)))
        use_page_cache = bool(extra_config.get("use_page_cache", False))

        if disk_mode:
            if disk_path is None:
                raise ValueError(
                    'kv_offload_backend="disk" requires disk_path to be set.'
                )
            if disk_capacity_bytes <= 0:
                raise ValueError(
                    'kv_offload_backend="disk" requires disk_capacity_bytes > 0.'
                )
        else:
            ignored = [k for k in _DISK_ONLY_KEYS if k in extra_config]
            if ignored:
                logger.warning(
                    'kv_offload_backend is "cpu", ignoring disk-only config: %s. '
                    'Set kv_offload_backend="disk" to enable the disk backend.',
                    ", ".join(ignored),
                )
            disk_path = None

        self.scheduler_manager: SimpleCPUOffloadScheduler | None = None
        self.worker_handler: SimpleCPUOffloadWorker | None = None

        if not enable_prefix_caching:
            logger.warning(
                "Detected prefix caching disabled, disabling CPU offload "
                "since it requires prefix caching."
            )
            return

        logger.info(
            "SimpleCPUOffloadConnector: role=%s, "
            "per_rank=%.2f GB, world_size=%d, mode=%s, backend=%s, disk=%s",
            role.name,
            cpu_capacity_per_rank / (1024**3),
            world_size,
            "lazy" if lazy_offload else "eager",
            kv_offload_backend,
            disk_path or "none",
        )
        if num_cpu_blocks is not None:
            logger.info(
                "Using explicit num_cpu_blocks=%d for offload pool sizing "
                "instead of automatic sizing from byte budgets.",
                num_cpu_blocks,
            )

        if role == KVConnectorRole.SCHEDULER:
            from vllm.v1.core.kv_cache_utils import resolve_kv_cache_block_sizes

            assert kv_cache_config is not None
            scheduler_block_size, hash_block_size = resolve_kv_cache_block_sizes(
                kv_cache_config, vllm_config
            )
            aligned_num_cpu_blocks = (
                vllm_config.cache_config.simple_cpu_offload_num_blocks
            )
            self.scheduler_manager = SimpleCPUOffloadScheduler(
                vllm_config,
                kv_cache_config,
                cpu_capacity_per_rank,
                scheduler_block_size=scheduler_block_size,
                hash_block_size=hash_block_size,
                lazy_offload=lazy_offload,
                disk_capacity_bytes=disk_capacity_bytes if disk_mode else 0,
                use_page_cache=use_page_cache if disk_mode else False,
                num_cpu_blocks=num_cpu_blocks,
                aligned_num_cpu_blocks=aligned_num_cpu_blocks,
            )
        elif role == KVConnectorRole.WORKER:
            self.worker_handler = SimpleCPUOffloadWorker(
                vllm_config,
                kv_cache_config,
                cpu_capacity_per_rank,
                kv_offload_backend=kv_offload_backend,
                disk_path=disk_path,
                disk_capacity_bytes=disk_capacity_bytes,
                disk_buffer_slots=disk_buffer_slots,
                use_page_cache=use_page_cache,
                num_cpu_blocks=num_cpu_blocks,
            )

    # --- Worker-side methods ---

    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]) -> None:
        if self.worker_handler is not None:
            self.worker_handler.register_kv_caches(kv_caches)

    def get_aligned_num_cpu_blocks(self) -> int | None:
        if self.worker_handler is None:
            return None
        num_cpu_blocks = self.worker_handler.num_cpu_blocks
        return num_cpu_blocks if num_cpu_blocks > 0 else None

    def bind_connector_metadata(
        self,
        connector_metadata: KVConnectorMetadata,
    ) -> None:
        super().bind_connector_metadata(connector_metadata)
        if self.worker_handler is not None:
            assert isinstance(connector_metadata, SimpleCPUOffloadMetadata)
            self.worker_handler.bind_connector_metadata(connector_metadata)

    def clear_connector_metadata(self) -> None:
        super().clear_connector_metadata()
        if self.worker_handler is not None:
            self.worker_handler.clear_connector_metadata()

    def handle_preemptions(self, kv_connector_metadata: KVConnectorMetadata) -> None:
        if self.worker_handler is not None:
            assert isinstance(kv_connector_metadata, SimpleCPUOffloadMetadata)
            self.worker_handler.handle_preemptions(kv_connector_metadata)

    def start_load_kv(self, forward_context: "ForwardContext", **kwargs: Any) -> None:
        if self.worker_handler is not None:
            self.worker_handler.start_load_kv()

    def wait_for_layer_load(self, layer_name: str) -> None:
        pass  # Always load asynchronously, issued in start_load_kv()

    def save_kv_layer(
        self,
        layer_name: str,
        kv_layer: torch.Tensor,
        attn_metadata: "AttentionMetadata",
        **kwargs: Any,
    ) -> None:
        pass  # Always save asynchronously, issued in wait_for_save()

    def wait_for_save(self) -> None:
        if self.worker_handler is not None:
            self.worker_handler.wait_for_save()

    def get_finished(
        self,
        finished_req_ids: set[str],
    ) -> tuple[set[str] | None, set[str] | None]:
        if self.worker_handler is not None:
            return self.worker_handler.get_finished(finished_req_ids)
        return None, None

    def build_connector_worker_meta(self):
        if self.worker_handler is not None:
            return self.worker_handler.build_connector_worker_meta()
        return None

    # --- Scheduler-side methods ---

    def bind_gpu_block_pool(self, gpu_block_pool: "BlockPool") -> None:
        if self.scheduler_manager is not None:
            self.scheduler_manager.bind_gpu_block_pool(gpu_block_pool)

    def get_num_new_matched_tokens(
        self,
        request: "Request",
        num_computed_tokens: int,
    ) -> tuple[int | None, bool]:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.get_num_new_matched_tokens(
                request, num_computed_tokens
            )
        return 0, False

    def update_state_after_alloc(
        self,
        request: "Request",
        blocks: "KVCacheBlocks",
        num_external_tokens: int,
    ) -> None:
        if self.scheduler_manager is not None:
            self.scheduler_manager.update_state_after_alloc(
                request, blocks, num_external_tokens
            )

    def build_connector_meta(
        self,
        scheduler_output: SchedulerOutput,
    ) -> KVConnectorMetadata:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.build_connector_meta(scheduler_output)
        return SimpleCPUOffloadMetadata()

    def update_connector_output(
        self,
        connector_output: KVConnectorOutput,
    ) -> None:
        if self.scheduler_manager is not None:
            self.scheduler_manager.update_connector_output(connector_output)

    def request_finished(
        self,
        request: "Request",
        block_ids: list[int],
    ) -> tuple[bool, dict[str, Any] | None]:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.request_finished(request, block_ids)
        return False, None

    def request_finished_all_groups(
        self,
        request: "Request",
        block_ids: tuple[list[int], ...],
    ) -> tuple[bool, dict[str, Any] | None]:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.request_finished_all_groups(
                request, block_ids
            )
        return False, None

    def has_pending_push_work(self) -> bool:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.has_pending_stores()
        return False

    def get_boundary_store_stats(self) -> BoundaryStoreStats | None:
        """Return cumulative boundary-handoff store diagnostics."""
        if self.scheduler_manager is not None:
            return self.scheduler_manager.get_boundary_store_stats()
        return None

    def get_kv_connector_stats(self) -> KVConnectorStats | None:
        # Worker-side callers may invoke this hook on connectors constructed
        # via __new__ (as in test_worker.py), which lack scheduler_manager.
        scheduler_manager: SimpleCPUOffloadScheduler | None = getattr(
            self, "scheduler_manager", None
        )
        if scheduler_manager is not None:
            return scheduler_manager.get_stats()
        return None

    @classmethod
    def build_kv_connector_stats(
        cls, data: dict[str, Any] | None = None
    ) -> KVConnectorStats | None:
        return (
            SimpleCPUOffloadStats(data=data)
            if data is not None
            else SimpleCPUOffloadStats()
        )

    @classmethod
    def build_prom_metrics(
        cls,
        vllm_config: VllmConfig,
        metric_types: dict[type[PromMetric], type[PromMetricT]],
        labelnames: list[str],
        per_engine_labelvalues: dict[int, list[object]],
    ) -> KVConnectorPromMetrics:
        return SimpleCPUOffloadPromMetrics(
            vllm_config, metric_types, labelnames, per_engine_labelvalues
        )

    def take_events(self) -> Iterable[KVCacheEvent]:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.take_events()
        return []

    # NOTE: Workers are not contacted. In-flight transfers drain naturally,
    # and stale completions are ignored by the guarded
    # SimpleCPUOffloadScheduler._process_store_event().
    def reset_cache(self) -> bool | None:
        if self.scheduler_manager is not None:
            return self.scheduler_manager.reset()
        return None
