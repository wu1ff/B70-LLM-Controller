# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
import logging
import math
import queue
import threading
import time
from collections import defaultdict
from collections.abc import Collection
from concurrent.futures import Future, ThreadPoolExecutor
from typing import TYPE_CHECKING, Any, cast

import msgpack
import msgspec
import numpy as np
import torch
import zmq

from vllm.config import CUDAGraphMode, VllmConfig
from vllm.distributed.kv_transfer.kv_connector.utils import (
    BlockIds,
    clip_ssm_state_blocks,
)
from vllm.distributed.kv_transfer.kv_connector.v1.base import (
    KVConnectorBase_V1,
    KVConnectorMetadata,
    KVConnectorRole,
    SupportsHMA,
)
from vllm.distributed.kv_transfer.kv_connector.v1.moriio.moriio_common import (
    ROLE,
    EngineId,
    HandshakeError,
    MoRIIOAgentMetadata,
    MoRIIOConfig,
    MoRIIOConnectorMetadata,
    MoRIIOConstants,
    MoRIIOError,
    MoRIIOMode,
    MoRIIOTransferAck,
    ReqId,
    ReqMeta,
    TransferBatchState,
    TransferError,
    TransferId,
    WriteTask,
    fold_local_rank,
    get_moriio_mode,
    get_peer_zmq_from_request_id,
    get_port_offset,
    get_role,
    parse_moriio_zmq_address,
    pod_index,
    resolve_host_ip,
    set_role,
    zmq_ctx,
)
from vllm.distributed.kv_transfer.kv_connector.v1.moriio.moriio_engine import (
    MoRIIOWrapper,
    MoRIIOWriter,
)
from vllm.distributed.kv_transfer.kv_connector.v1.moriio.moriio_heartbeat import (
    MoRIIOHeartbeat,
)
from vllm.distributed.kv_transfer.kv_connector.v1.moriio.moriio_layout import (
    LayerTransferGeometry,
    MambaOffsetTemplate,
    apply_mamba_offset_template,
    build_layer_to_spec,
    build_mamba_offset_template,
    compute_block_transfer_offsets,
    compute_mamba_conv_split_count,
    get_layer_transfer_geometry,
    is_mla_cache_layer,
    iter_layer_registration_regions,
    kda_conv_ssm,
)
from vllm.distributed.kv_transfer.kv_connector.v1.ssm_conv_transfer_utils import (
    MambaConvSplitInfo,
    derive_mamba_conv_split,
)
from vllm.distributed.parallel_state import (
    get_tensor_model_parallel_world_size,
    get_tp_group,
    get_world_group,
)
from vllm.forward_context import ForwardContext, get_forward_context
from vllm.logger import init_logger
from vllm.utils.math_utils import cdiv
from vllm.utils.network_utils import (
    make_zmq_path,
    make_zmq_socket,
)
from vllm.v1.attention.selector import get_attn_backend
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import (
    KVCacheConfig,
    MambaSpec,
    SlidingWindowSpec,
    is_full_attention_spec,
)
from vllm.v1.metrics.cache_hit_source import CacheHitSource
from vllm.v1.outputs import KVConnectorOutput
from vllm.v1.request import RequestStatus

if TYPE_CHECKING:
    from vllm.v1.attention.backend import AttentionMetadata
    from vllm.v1.core.kv_cache_manager import KVCacheBlocks
    from vllm.v1.request import Request

logger = init_logger(__name__)

# Backoff bounds for re-posting an RDMA READ that the NIC rejected because the
# send queue was full. A separate CQ-poll thread drains completions, so the
# wait only needs to be long enough for it to make progress.
_SQ_FULL_BACKOFF_INITIAL_S = 0.001
_SQ_FULL_BACKOFF_MAX_S = 0.05
_MAX_LOCAL_MAMBA_TAIL_BLOCKS = 1


try:
    from mori.io import (
        BackendType,
        IOEngine,
        IOEngineConfig,
    )

    logger.info("MoRIIO is available")
    MoRIIO_enabled = True
except ImportError:
    logger.error("MoRIIO is not available")
    MoRIIO_enabled = False


def is_moriio_available() -> bool:
    return MoRIIO_enabled


def get_moriio_remote_tp_rank(
    local_tp_rank: int, local_tp_size: int, remote_tp_size: int
) -> int:
    if local_tp_size <= 0 or remote_tp_size <= 0:
        raise ValueError("TP sizes must be positive")
    if local_tp_rank < 0 or local_tp_rank >= local_tp_size:
        raise ValueError(
            f"local_tp_rank {local_tp_rank} must be in [0, {local_tp_size})"
        )
    if remote_tp_size == local_tp_size:
        return local_tp_rank
    if remote_tp_size > local_tp_size:
        if remote_tp_size % local_tp_size != 0:
            raise ValueError(
                f"remote tp_size {remote_tp_size} must be a multiple of local "
                f"tp_size {local_tp_size} for heterogeneous-TP P/D"
            )
        return local_tp_rank * (remote_tp_size // local_tp_size)
    if local_tp_size % remote_tp_size != 0:
        raise ValueError(
            f"local tp_size {local_tp_size} must be a multiple of remote "
            f"tp_size {remote_tp_size} for heterogeneous-TP P/D"
        )
    return local_tp_rank // (local_tp_size // remote_tp_size)


def validate_moriio_heterogeneous_tp_kv_heads(
    local_tp_size: int,
    remote_tp_size: int,
    total_num_kv_heads: int,
    is_mla: bool,
) -> None:
    if is_mla or local_tp_size == remote_tp_size:
        return
    if local_tp_size <= 0 or remote_tp_size <= 0 or total_num_kv_heads <= 0:
        raise ValueError("TP sizes and total_num_kv_heads must be positive")
    if min(local_tp_size, remote_tp_size) >= total_num_kv_heads:
        return
    raise NotImplementedError(
        "MoRIIO heterogeneous TP requires replicated KV heads on both "
        f"prefill and decode. Got total_num_kv_heads={total_num_kv_heads}, "
        f"local_tp_size={local_tp_size}, remote_tp_size={remote_tp_size}."
    )


def get_moriio_expected_ack_count(producer_tp_size: int, consumer_tp_size: int) -> int:
    if producer_tp_size <= 0 or consumer_tp_size <= 0:
        raise ValueError("TP sizes must be positive")
    if consumer_tp_size <= producer_tp_size:
        return 1
    if consumer_tp_size % producer_tp_size != 0:
        raise ValueError(
            f"consumer tp_size {consumer_tp_size} must be a multiple of "
            f"producer tp_size {producer_tp_size} for heterogeneous-TP P/D"
        )
    return consumer_tp_size // producer_tp_size


def resolve_moriio_transfer_ack(
    ack: MoRIIOTransferAck | TransferId,
    producer_tp_size: int,
    live_transfer_ids: Collection[TransferId],
    notification_counts: dict[TransferId, int],
    completed_transfer_ids: set[TransferId],
) -> TransferId | None:
    if isinstance(ack, str):
        ack = MoRIIOTransferAck(ack)
    transfer_id = ack.transfer_id
    if transfer_id not in live_transfer_ids:
        return None
    if transfer_id in completed_transfer_ids:
        return None

    expected_acks = get_moriio_expected_ack_count(
        producer_tp_size, ack.consumer_tp_size
    )
    count = notification_counts.get(transfer_id, 0) + 1
    if count < expected_acks:
        notification_counts[transfer_id] = count
        return None

    notification_counts.pop(transfer_id, None)
    completed_transfer_ids.add(transfer_id)
    return transfer_id


class MoRIIOConnector(KVConnectorBase_V1, SupportsHMA):
    _cache_hit_source = CacheHitSource.P2P

    @property
    def supports_divergent_local_hybrid_hits(self) -> bool:
        # The READ path always transfers the recurrent-state slot, including
        # when the attention prefix is already present locally.
        return self.mode == MoRIIOMode.READ and self._transfers_mamba_state

    def __init__(
        self,
        vllm_config: VllmConfig,
        role: KVConnectorRole,
        kv_cache_config: "KVCacheConfig",
    ):
        super().__init__(vllm_config, role, kv_cache_config)
        assert vllm_config.kv_transfer_config is not None, (
            "kv_transfer_config must be set for MoRIIOConnector"
        )

        self.kv_transfer_config = vllm_config.kv_transfer_config
        self._set_port_defaults(vllm_config)

        self.engine_id = (
            str(resolve_host_ip(self.kv_transfer_config.kv_connector_extra_config))
            + ":"
            + str(self.kv_transfer_config.kv_connector_extra_config["handshake_port"])
        )
        self.mode = get_moriio_mode(self.kv_transfer_config)
        self._transfers_mamba_state = any(
            group.enable_kv_transfer and isinstance(group.kv_cache_spec, MambaSpec)
            for group in kv_cache_config.kv_cache_groups
        )
        if role == KVConnectorRole.SCHEDULER:
            self.connector_scheduler: MoRIIOConnectorScheduler | None = (
                MoRIIOConnectorScheduler(vllm_config, self.engine_id, kv_cache_config)
            )
            self.connector_worker: MoRIIOConnectorWorker | None = None
        elif role == KVConnectorRole.WORKER:
            self.connector_scheduler = None
            self.connector_worker = MoRIIOConnectorWorker(
                vllm_config, self.engine_id, kv_cache_config
            )
        logger.info(
            "Initialized MoRIIO Connector,engine_id:%s,role: %s",
            self.engine_id,
            role.value,
        )

    ############################################################
    # Scheduler Side Methods
    ############################################################

    def _set_port_defaults(self, vllm_config: VllmConfig):
        assert vllm_config.kv_transfer_config is not None, (
            "kv_transfer_config must be set for MoRIIOConnector"
        )
        kv_transfer_config = vllm_config.kv_transfer_config
        extra_config = kv_transfer_config.kv_connector_extra_config

        if "handshake_port" not in extra_config or not extra_config["handshake_port"]:
            extra_config["handshake_port"] = MoRIIOConstants.DEFAULT_HANDSHAKE_PORT

        if "notify_port" not in extra_config or not extra_config["notify_port"]:
            extra_config["notify_port"] = MoRIIOConstants.DEFAULT_NOTIFY_PORT

    def get_num_new_matched_tokens(
        self, request: "Request", num_computed_tokens: int
    ) -> tuple[int, bool]:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.get_num_new_matched_tokens(
            request, num_computed_tokens
        )

    def update_state_after_alloc(
        self, request: "Request", blocks: "KVCacheBlocks", num_external_tokens: int
    ):
        assert self.connector_scheduler is not None
        return self.connector_scheduler.update_state_after_alloc(
            request, blocks, num_external_tokens, self.connector_worker
        )

    def on_new_request(self, request: "Request") -> None:
        """Fired when the scheduler admits a request, before any allocation."""
        assert self.connector_scheduler is not None
        self.connector_scheduler.on_new_request(request)

    def build_connector_meta(
        self,
        scheduler_output: SchedulerOutput,
    ) -> KVConnectorMetadata:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.build_connector_meta(scheduler_output)

    def request_finished(
        self,
        request: "Request",
        block_ids: list[int],
    ) -> tuple[bool, dict[str, Any] | None]:
        assert self.connector_scheduler is not None
        return self.connector_scheduler.request_finished(request, (block_ids,))

    def request_finished_all_groups(
        self,
        request: "Request",
        block_ids: BlockIds,
    ) -> tuple[bool, dict[str, Any] | None]:
        assert self.connector_scheduler is not None
        if self.connector_scheduler._has_mamba:
            attn_block_ids, mamba_block_groups = (
                self.connector_scheduler.split_block_groups(block_ids)
            )
            delay_free, params = self.connector_scheduler.request_finished(
                request, attn_block_ids, mamba_block_groups
            )
            return delay_free, params
        return self.connector_scheduler.request_finished(request, block_ids)

    def update_connector_output(self, connector_output: KVConnectorOutput) -> None:
        assert self.connector_scheduler is not None
        self.connector_scheduler.update_connector_output(connector_output)

    ############################################################
    # Worker Side Methods
    ############################################################
    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]):
        assert self.connector_worker is not None
        self.connector_worker.register_kv_caches(kv_caches)

    def get_finished(self, finished_req_ids: set[str]) -> tuple[set[str], set[str]]:
        """Get the finished recving and sending requests."""
        assert self.connector_worker is not None
        return self.connector_worker.get_finished()

    def get_block_ids_with_load_errors(self) -> set[int]:
        """Blocks whose MoRIIO read failed, for the scheduler to recompute."""
        if self.connector_worker is None:
            return set()
        return self.connector_worker.get_block_ids_with_load_errors()

    def start_load_kv(self, forward_context: "ForwardContext", **kwargs) -> None:
        assert self.connector_worker is not None
        if self.mode == MoRIIOMode.WRITE and get_role() == ROLE.CONSUMER:
            self.connector_worker.moriio_wrapper.async_wait_reqid()

        assert isinstance(self._connector_metadata, MoRIIOConnectorMetadata)
        self.connector_worker.start_load_kv(self._connector_metadata)

    def wait_for_layer_load(self, layer_name: str) -> None:
        assert self.connector_worker is not None
        self.connector_worker.wait_for_layer_load(layer_name)

    def save_kv_layer(
        self,
        layer_name: str,
        kv_layer: torch.Tensor,
        attn_metadata: "AttentionMetadata",
        **kwargs,
    ) -> None:
        # Only producer/prefill saves KV Cache
        if get_role() == ROLE.CONSUMER:
            return
        assert self.connector_worker is not None, (
            "save_kv_layer called on scheduler role"
        )

        assert isinstance(self._connector_metadata, MoRIIOConnectorMetadata), (
            "Connector metadata not initialized yet"
        )
        self.connector_worker.save_kv_layer(
            self._connector_metadata, layer_name, kv_layer, attn_metadata, **kwargs
        )

        return None

    def wait_for_save(self):
        if self.mode != MoRIIOMode.WRITE or get_role() != ROLE.PRODUCER:
            return
        assert self.connector_worker is not None
        assert isinstance(self._connector_metadata, MoRIIOConnectorMetadata), (
            "Connector metadata not initialized yet"
        )
        self.connector_worker.wait_for_save(self._connector_metadata)

    def shutdown(self):
        if self.connector_worker is not None:
            self.connector_worker.shutdown()
        if self.connector_scheduler is not None:
            self.connector_scheduler.shutdown()

    def has_connector_metadata(self) -> bool:
        """Check whether the connector metadata is currently set.

        Returns:
            bool: True if connector metadata exists, False otherwise.

        """
        try:
            return self._connector_metadata is not None
        except AttributeError:
            return False


def _split_kv_cache_group_kinds(
    kv_cache_config: "KVCacheConfig",
) -> tuple[list[int], list[int]]:
    """Classify kv_cache_groups into (attention_group_indices,
    mamba_group_indices) by whether each group's spec is a MambaSpec.

    Groups that opt out of external transfer are absent from
    ``KVCacheConfig.transfer_groups``. Returned indices address that filtered
    sequence and therefore also the connector's transfer block payload.
    """
    attn: list[int] = []
    mamba: list[int] = []
    for gi, group in enumerate(kv_cache_config.transfer_groups):
        if isinstance(group.kv_cache_spec, MambaSpec):
            mamba.append(gi)
        else:
            attn.append(gi)
    return attn, mamba


def _validate_hybrid_speculation(vllm_config: VllmConfig) -> None:
    speculative_config = vllm_config.speculative_config
    if speculative_config is None:
        return
    # DSpark is allowlisted because it is the only hybrid speculative method
    # validated end to end with MoRIIO READ.
    if not speculative_config.use_dspark():
        raise MoRIIOError(
            "MoRIIO hybrid READ supports DSpark speculative decoding only, got "
            f"method={speculative_config.method!r}"
        )


def _validate_mamba_specs(specs: Collection[MambaSpec]) -> MambaSpec | None:
    """Validate the common packed-state contract and return its representative."""
    specs = tuple(specs)
    if not specs:
        return None
    for spec in specs:
        if len(spec.shapes) != 2 or len(spec.dtypes) != 2:
            raise MoRIIOError(
                "MoRIIO hybrid READ supports exactly two Mamba states "
                "(conv and SSM), got "
                f"{len(spec.shapes)} shapes and {len(spec.dtypes)} dtypes"
            )
    reference = specs[0]
    if any(spec != reference for spec in specs[1:]):
        raise MoRIIOError(
            "MoRIIO hybrid READ requires all transferable Mamba groups "
            "to use the same cache spec"
        )
    return reference


class MoRIIOConnectorScheduler:
    """Implementation of Scheduler side methods."""

    def __init__(
        self,
        vllm_config: VllmConfig,
        engine_id: str,
        kv_cache_config: "KVCacheConfig",
    ):
        self.vllm_config = vllm_config
        self.kv_cache_config = kv_cache_config
        assert vllm_config.kv_transfer_config is not None, (
            "kv_transfer_config must be set for MoRIIOConnector"
        )
        self.kv_transfer_config = vllm_config.kv_transfer_config
        self.mode = get_moriio_mode(self.kv_transfer_config)
        self._attn_group_ids, self._mamba_group_ids = _split_kv_cache_group_kinds(
            kv_cache_config
        )
        self._has_mamba = bool(self._mamba_group_ids)
        mamba_spec = None
        if self._has_mamba:
            if len(self._attn_group_ids) != 1:
                raise MoRIIOError(
                    "MoRIIO hybrid READ requires exactly one transferable "
                    "attention group, got "
                    f"{len(self._attn_group_ids)}; a drafter that owns a "
                    "separate attention group is not supported, give it the "
                    "target's group or disable KV transfer for it"
                )
            mamba_specs = [
                cast(MambaSpec, kv_cache_config.transfer_groups[group_id].kv_cache_spec)
                for group_id in self._mamba_group_ids
            ]
            mamba_spec = _validate_mamba_specs(mamba_specs)
            _validate_hybrid_speculation(vllm_config)
            if self.mode != MoRIIOMode.READ:
                raise MoRIIOError(
                    "MoRIIO hybrid (mamba/KDA) transfer is implemented for READ "
                    "mode only; set kv_connector_extra_config.read_mode=true"
                )
        self._num_ssm_scratch_blocks = (
            mamba_spec.num_speculative_blocks if mamba_spec is not None else 0
        )
        self.block_size = vllm_config.cache_config.block_size
        attn_block_size = self.block_size
        max_decode_tail_tokens = 1 + vllm_config.num_lookahead_tokens
        if self._has_mamba:
            attn_spec = kv_cache_config.transfer_groups[
                self._attn_group_ids[0]
            ].kv_cache_spec
            attn_block_size = attn_spec.block_size
            if attn_spec.dcp_sharded:
                attn_block_size *= (
                    vllm_config.parallel_config.decode_context_parallel_size
                )
            # Admission can pad the final prompt token to 1 + num_spec rows;
            # allocate_slots reserves drafter lookahead in addition to those.
            max_decode_tail_tokens += vllm_config.num_speculative_tokens
        self._max_decode_tail_blocks = cdiv(max_decode_tail_tokens, attn_block_size)
        self.engine_id: EngineId = engine_id

        self._is_hma_required = (
            not vllm_config.scheduler_config.disable_hybrid_kv_cache_manager
            and any(
                not is_full_attention_spec(g.kv_cache_spec)
                for g in kv_cache_config.transfer_groups
            )
        )
        if self._is_hma_required:
            # MoRIIO handles sliding-window attention and mamba/KDA groups in
            # READ mode. Other hybrid cache specs still fail closed.
            unsupported = [
                type(g.kv_cache_spec).__name__
                for g in kv_cache_config.transfer_groups
                if not (
                    is_full_attention_spec(g.kv_cache_spec)
                    or isinstance(g.kv_cache_spec, (SlidingWindowSpec, MambaSpec))
                )
            ]
            if unsupported:
                raise NotImplementedError(
                    "MoRIIO only supports sliding-window hybrid models (e.g. "
                    "Gemma) and mamba/KDA groups under the hybrid KV cache "
                    "manager. Unsupported KV "
                    f"cache group spec(s): {sorted(set(unsupported))}. Pass "
                    "--disable-hybrid-kv-cache-manager to run without HMA."
                )
            if self.mode == MoRIIOMode.WRITE:
                # TODO(simondanielsson): support HMA in WRITE mode
                raise NotImplementedError(
                    "MoRIIO WRITE mode does not support hybrid KV cache groups "
                    "(sliding-window attention). Use READ mode, or pass "
                    "--disable-hybrid-kv-cache-manager."
                )

        sw_sizes_tokens: list[tuple[int, int]] = [
            (g.kv_cache_spec.sliding_window, g.kv_cache_spec.block_size)
            if isinstance(g.kv_cache_spec, SlidingWindowSpec)
            else (0, self.block_size)
            for g in kv_cache_config.transfer_groups
        ]
        # +1 conservatively covers window/block boundary overlap.
        self.blocks_per_sw = [
            cdiv(n_tokens, block_size) + 1 if n_tokens else 0
            for n_tokens, block_size in sw_sizes_tokens
        ]
        # Per-group block size over transfer_groups (matching blocks_per_sw and
        # the connector's block payload), used to clamp each full-attention group
        # to its prompt length on the WRITE save path.
        self._group_block_sizes = [
            getattr(g.kv_cache_spec, "block_size", self.block_size)
            for g in kv_cache_config.transfer_groups
        ]
        # The WRITE-mode prompt-block clamp only covers full-attention groups, so
        # MoRIIO + speculative decoding is not yet safe on sliding-window /
        # hybrid models. TODO: lift once SWA + spec is validated end-to-end.
        if (
            self.mode == MoRIIOMode.WRITE
            and vllm_config.speculative_config is not None
            and any(bps != 0 for bps in self.blocks_per_sw)
        ):
            raise NotImplementedError(
                "MoRIIO with speculative decoding is not yet supported for "
                "sliding-window / hybrid models: the prompt-block clamp is only "
                "validated for full-attention KV groups."
            )
        # In WRITE mode and chunked prefill, we perform the write after the last chunk.
        # Hence we need to track once we are in the last chunk. We do this by computing
        # len(block_ids[g]) * block_size[g] for a full attn group g, as hybrid groups
        # may be clipped and hence not reflect the full sequence length. Here we store
        # g and block_size[g] for later.
        self._full_attn_group_idx = 0
        self._full_attn_block_size = self.block_size
        for gi, group in enumerate(kv_cache_config.kv_cache_groups):
            if is_full_attention_spec(group.kv_cache_spec):
                self._full_attn_group_idx = gi
                self._full_attn_block_size = getattr(
                    group.kv_cache_spec, "block_size", self.block_size
                )
                break

        self.host_ip = resolve_host_ip(
            self.kv_transfer_config.kv_connector_extra_config
        )
        self.handshake_port = self.kv_transfer_config.kv_connector_extra_config[
            "handshake_port"
        ]
        logger.info("Initializing MoRIIO Scheduler engine_id = %s", engine_id)

        self.side_notify_port = self.kv_transfer_config.kv_connector_extra_config[
            "notify_port"
        ]
        self.tp_size = self.vllm_config.parallel_config.tensor_parallel_size
        # Local DP rank (0..dp_local-1) for port arithmetic; fold_local_rank
        # handles the external-DP sentinel (dp_local==0) so the arithmetic
        # can't ZeroDivisionError at init.
        _pc = self.vllm_config.parallel_config
        self.dp_rank = fold_local_rank(
            _pc.data_parallel_rank, _pc.data_parallel_size_local
        )
        # Only first-pod ranks originate notify to avoid duplicates. Guarding
        # via pod_index keeps _is_kv_master True for the external-DP sentinel
        # (single pod) instead of being silently stuck False.
        self._is_kv_master = (
            pod_index(_pc.data_parallel_rank, _pc.data_parallel_size_local) == 0
        )
        # Global DP rank for pinned request ownership check.
        self._global_dp_rank = self.vllm_config.parallel_config.data_parallel_rank
        self.is_producer = self.kv_transfer_config.kv_role == "kv_producer"
        # Requests that need to start recv/send.
        # New requests are added by update_state_after_alloc in
        # the scheduler. Used to make metadata passed to Worker.
        self._reqs_need_recv: dict[ReqId, tuple[Request, BlockIds]] = {}
        self._reqs_need_save: dict[ReqId, tuple[Request, BlockIds]] = {}
        # Snapshot of kv_transfer_params for chunked prefill recovery.
        self._req_kv_params: dict[ReqId, dict] = {}

        # For chunked prefill, we perform layer-wise access within the final chunk.
        # TODO: Perform transfer at end chunk.
        self._reqs_need_pending_save: dict[ReqId, tuple[Request, BlockIds]] = {}

        if self.is_producer:
            set_role(ROLE.PRODUCER)
        else:
            set_role(ROLE.CONSUMER)
        # Reqs to send and their expiration time
        self._reqs_need_send: dict[ReqId, float] = {}
        # Deadlines for requests whose block freeing was deferred.
        # Survives across scheduler steps. If the worker never reports
        # finished_sending before the deadline, we inject them into
        # connector_output.finished_sending so the scheduler frees the blocks to avoid
        # hanging indefinitely waiting for a free notification that never comes.
        # Value: (deadline, transfer_id) for unmapping after mutation.
        self._deferred_send_deadlines: dict[ReqId, tuple[float, TransferId | None]] = {}
        self._defer_timeout = float(
            self.kv_transfer_config.kv_connector_extra_config.get(
                "defer_timeout", MoRIIOConstants.DEFAULT_DEFER_TIMEOUT
            )
        )
        # Buffer for early ACKs that arrive before request_finished.
        self._pending_sent_acks: dict[ReqId, float] = {}
        self.paths: dict[str, zmq.Socket] = {}
        self.transfer_id_to_request_id: dict[TransferId, ReqId] = {}
        self.request_id_to_transfer_id: dict[ReqId, TransferId] = {}

    def get_exchange_clipped_blocks(
        self,
        block_ids: BlockIds,
    ) -> BlockIds:
        """Clip the block list based on the layer type.

        Behavior:
        - sliding window: keep only the last window size blocks
        - full attention: keep all blocks
        """
        if len(block_ids) == 0:
            return []
        if len(block_ids) == len(self.kv_cache_config.kv_cache_groups):
            block_ids = self.kv_cache_config.select_transfer_block_ids(block_ids)
        if not self._is_hma_required:
            return [list(blocks) for blocks in block_ids]
        return [
            blocks[-self.blocks_per_sw[i] :] if self.blocks_per_sw[i] > 0 else blocks
            for i, blocks in enumerate(block_ids)
        ]

    def map_request_id(self, request_id: ReqId, transfer_id: TransferId):
        self.transfer_id_to_request_id[transfer_id] = request_id
        self.request_id_to_transfer_id[request_id] = transfer_id

    def unmap_request_id(
        self, request_id: ReqId, transfer_id: TransferId | None = None
    ):
        """Unmap request_id/transfer_id. Uses transfer_id for lookup if
        exact request_id match fails (handles input_processor mutation)."""
        if request_id in self.request_id_to_transfer_id:
            tid = self.request_id_to_transfer_id[request_id]
            del self.request_id_to_transfer_id[request_id]
            if tid in self.transfer_id_to_request_id:
                del self.transfer_id_to_request_id[tid]
            return

        # Fallback: use transfer_id to find original request_id.
        if transfer_id is not None and transfer_id in self.transfer_id_to_request_id:
            original_rid = self.transfer_id_to_request_id[transfer_id]
            if original_rid != request_id:
                logger.debug(
                    "MoRI-IO unmap via transfer_id: %r -> %r", request_id, original_rid
                )
            if original_rid in self.request_id_to_transfer_id:
                del self.request_id_to_transfer_id[original_rid]
            del self.transfer_id_to_request_id[transfer_id]
            return

        logger.warning(
            "MoRI-IO unmap MISS: rid=%r transfer_id=%r table_size=%d",
            request_id,
            transfer_id,
            len(self.request_id_to_transfer_id),
        )

    def get_num_new_matched_tokens(
        self,
        request: "Request",
        num_computed_tokens: int,
    ) -> tuple[int, bool]:
        """For remote prefill, pull all prompt blocks from remote
        asynchronously relative to engine execution.

        Args:
            request (Request): the request object.
            num_computed_tokens (int): the number of locally
                computed tokens for this request
        Returns:
            * the number of tokens that can be loaded from the
              external KV cache beyond what is already computed.
            * true if the external KV cache tokens will be loaded
              asynchronously (between scheduler steps).

        """
        if self.is_producer:
            # The P-side prompt truncation for hybrid models happens in
            # on_new_request, before the scheduler looks the request up in the
            # prefix cache.
            return 0, False

        num_prompt_tokens = request.num_prompt_tokens
        num_external_tokens = max(num_prompt_tokens - num_computed_tokens, 0)
        if self.mode == MoRIIOMode.WRITE:
            params = request.kv_transfer_params or {}
            if not params.get("do_remote_prefill"):
                return 0, False
            # MoriiO in write mode, no remote prefill. Hybrid models never get
            # here: register_kv_caches refuses WRITE mode for them, so there is
            # no recurrent-state accounting to do.
            return num_external_tokens, True

        # READ mode always recomputes the last token locally on the decoder.
        #
        # The second element declares who waits for the KV, not whether it has
        # arrived. False keeps the wait on this side: the forward runs in the
        # same step, and the connector blocks in wait_for_layer_load (or in
        # start_load_kv under full-graph capture) until the KV is really there.
        return max(num_external_tokens - 1, 0), False

    def on_new_request(self, request: "Request") -> None:
        """Scheduler hook fired when a request is admitted.

        The hybrid P-side truncation must land here rather than in
        ``get_num_new_matched_tokens``: the scheduler runs the local prefix
        cache lookup first and only then asks the connector, so truncating
        there shortens a prompt whose cache hit was already measured against
        the full length. On a full hit that leaves ``num_computed_tokens ==
        num_tokens`` and trips the scheduler's ``num_new_tokens > 0`` assert.
        """
        if not (self.is_producer and self._has_mamba):
            return
        params = request.kv_transfer_params
        if params is not None and params.get("do_remote_decode"):
            self._truncate_mamba_request_for_prefill(request)

    def _truncate_mamba_request_for_prefill(self, request: "Request") -> None:
        """P-side only: drop the last prompt token so the prefiller computes
        h(N-1) instead of h(N).

        The decoder recomputes the last token locally to derive h(N) correctly
        (see the READ len-1 accounting in get_num_new_matched_tokens). Guarded
        by ``_p_side_truncated`` to avoid repeated truncation across a
        preemption/reschedule. Mirrors the NIXL scheduler.
        """
        params = request.kv_transfer_params
        if (
            params is not None
            and not params.get("_p_side_truncated")
            and request.num_prompt_tokens > 1
        ):
            if request.prompt_token_ids is not None:
                request.prompt_token_ids.pop()
            elif request.prompt_embeds is not None:
                request.prompt_embeds = request.prompt_embeds[:-1]
            else:
                return

            request._all_token_ids.pop()
            request.num_prompt_tokens -= 1
            request.max_tokens = 1
            params["_p_side_truncated"] = True

    def send_notify_block(
        self,
        req_id: ReqId,
        transfer_id: TransferId,
        block_notify_list: list,
        host=None,
        port=None,
    ):
        path = make_zmq_path("tcp", host, port)
        if path not in self.paths:
            ctx = zmq.Context.instance()
            sock = make_zmq_socket(
                ctx=ctx, path=path, socket_type=zmq.DEALER, bind=False
            )
            self.paths[path] = sock

        data = {
            "req_id": req_id,
            "transfer_id": transfer_id,
            "block_notify_list": block_notify_list or [],
            # GLOBAL decode dp rank: producer derives the per-pod notify offset
            # (% dp_local), owning pod index (// dp_local), and write-target
            # from it. Sending the LOCAL rank made child-pod consumers look
            # like master rank 0 and hang in WAITING_FOR_REMOTE_KVS. Single-pod:
            # local == global.
            "decode_rank": self._global_dp_rank,
            "type": "remote_blocks",
        }
        serialized_data = msgpack.dumps(data)
        self.paths[path].send(serialized_data)

    def _send_transfer_release(self, transfer_id: TransferId, host: str, port: int):
        path = make_zmq_path("tcp", host, port)
        if path not in self.paths:
            ctx = zmq.Context.instance()
            sock = make_zmq_socket(
                ctx=ctx, path=path, socket_type=zmq.DEALER, bind=False
            )
            self.paths[path] = sock

        # Advertise the consumer (decode) TP size so prefill counts the right
        # number of ACKs (get_moriio_expected_ack_count; see the upstream
        # READ-mode release in _pop_done_transfers). Resolves to 1 for our
        # homogeneous TP=1 configs; only matters under heterogeneous-TP fan-in.
        self.paths[path].send(
            msgpack.dumps(
                {
                    "type": "release",
                    "transfer_id": transfer_id,
                    "consumer_tp_size": self.tp_size,
                }
            )
        )

    def _release_write_prefill_blocks(self, request_id: ReqId, params: dict[str, Any]):
        transfer_id = params.get("transfer_id")
        if transfer_id is None:
            logger.warning(
                "Cannot release WRITE prefill blocks for request %s: "
                "missing transfer_id",
                request_id,
            )
            return

        remote_dp_rank = params.get("remote_dp_rank", 0)
        remote_host = params.get("remote_host")
        remote_notify_port = params.get("remote_notify_port")
        if remote_host is None or remote_notify_port is None:
            try:
                peer_zmq = get_peer_zmq_from_request_id(request_id, is_producer=False)
                if peer_zmq is None:
                    raise ValueError("no peer zmq address for request")
                remote_host, _, remote_notify_port = parse_moriio_zmq_address(peer_zmq)
            except ValueError:
                logger.warning(
                    "Cannot release WRITE prefill blocks for request %s: "
                    "missing remote notify address",
                    request_id,
                )
                return

        remote_notify_port = int(remote_notify_port)
        for tp_index in range(self.tp_size):
            target_port = remote_notify_port + get_port_offset(remote_dp_rank, tp_index)
            self._send_transfer_release(transfer_id, remote_host, target_port)

    def update_state_after_alloc(
        self,
        request: "Request",
        blocks: "KVCacheBlocks",
        num_external_tokens: int,
        connector_worker: "MoRIIOConnectorWorker | None" = None,
    ):
        """Scheduler-side post-allocation hook (decode leg in WRITE mode).

        In WRITE mode this fires the decode->prefill "blocks ready" notify
        that lets the producer RDMA-Write its KV into the freshly allocated
        decode blocks.

        DP-rank routing contract (router-authoritative)
        ------------------------------------------------
        Both legs of a disagg pair must agree on a single prefill DP rank,
        otherwise the notify lands on a rank that never handshook and the
        request hangs until ``VLLM_MORIIO_DEFERRED_TIMEOUT_S``.

        The routing authority is the external router/sidecar, NOT the
        connector. The llm-d routing sidecar computes ``H = pickDPRank(uuid,
        dp_size)`` (see ``dp_rank.go``) once and pins BOTH legs to ``H`` two
        ways: the ``X-data-parallel-rank`` dispatch header (which vLLM engine
        the leg lands on) and ``kv_transfer_params.remote_dp_rank=H`` (which
        prefill rank this notify targets), with ``remote_dp_rank_override=True``.

        The connector consumes ``remote_dp_rank`` verbatim and does NOT
        self-derive a rank: an independent hash here could disagree with the
        router's dispatch pin and misroute the notify. For the returnable paths
        (READ / serial WRITE) the prefill leg also echoes back the rank it ran
        on via ``request_finished`` so routing is pure propagation.

        The owning rank is the only one that originates the notify
        (``remote_dp_rank_override`` -> global-rank match; otherwise the
        ``_is_kv_master`` anti-duplicate gate). See the inline comments
        below for the exactly-once-across-pods reasoning.
        """
        params = request.kv_transfer_params
        if not params:
            return
        # LLM-D sidecar compat: the nixlv2 routing sidecar emits NIXL-shaped
        # kv_transfer_params without MoRI-IO's transfer_id. Synthesize one
        # deterministically from request_id so producer and consumer agree
        # without a sidecar wire-protocol change.
        transfer_id = params.get("transfer_id") or f"sidecar-{request.request_id}"
        params.setdefault("transfer_id", transfer_id)
        request_id = request.request_id
        self.map_request_id(request_id, transfer_id)
        if params.get("do_remote_decode") and self.mode == MoRIIOMode.WRITE:
            local_block_ids: BlockIds = blocks.get_block_ids()
            self._reqs_need_save[request.request_id] = (request, local_block_ids)
            # Snapshot params now so chunked-prefill build_connector_meta
            # can recover them on the final chunk even if the live
            # request.kv_transfer_params has been mutated/cleared.
            self._req_kv_params[request.request_id] = dict(params)

        if params is not None and params.get("do_remote_prefill"):
            if self.mode == MoRIIOMode.READ:
                if remote_block_ids := params.get("remote_block_ids"):
                    # remote_engine_id is returned by the prefill's request_finished.
                    # host/ports come from the request_id (parsed in add_new_req).
                    if "remote_engine_id" in params:
                        adjusted_remote_block_ids = remote_block_ids
                        if num_external_tokens > 0:
                            if self._has_mamba:
                                # READ is synchronous, so allocate_slots may hash
                                # destination blocks before this hook runs. Pair
                                # the attention and recurrent-state suffixes
                                # independently.
                                remote_attn = list(remote_block_ids[0])
                                remote_mamba_groups = [
                                    list(group) for group in remote_block_ids[1:]
                                ]
                                attn_block_ids, mamba_block_groups = (
                                    self.split_block_groups(blocks.get_block_ids())
                                )
                                if len(mamba_block_groups) != len(remote_mamba_groups):
                                    raise MoRIIOError(
                                        "MoRIIO hybrid READ Mamba group "
                                        "count mismatch: "
                                        f"local={len(mamba_block_groups)}, "
                                        f"remote={len(remote_mamba_groups)}"
                                    )
                                local_attn = attn_block_ids
                                local_attn, remote_attn = self._align_read_blocks(
                                    local_attn,
                                    remote_attn,
                                    self._max_decode_tail_blocks,
                                )
                                aligned_local_mamba: list[list[int]] = []
                                aligned_remote_mamba: list[list[int]] = []
                                # Scratch slots were removed by
                                # split_block_groups, so only one local running
                                # state tail can remain.
                                for local_group, remote_group in zip(
                                    mamba_block_groups,
                                    remote_mamba_groups,
                                    strict=True,
                                ):
                                    aligned_local, aligned_remote = (
                                        self._align_read_blocks(
                                            local_group,
                                            remote_group,
                                            _MAX_LOCAL_MAMBA_TAIL_BLOCKS,
                                        )
                                    )
                                    aligned_local_mamba.append(aligned_local)
                                    aligned_remote_mamba.append(aligned_remote)
                                local_block_ids = [local_attn, *aligned_local_mamba]
                                adjusted_remote_block_ids = [
                                    remote_attn,
                                    *aligned_remote_mamba,
                                ]
                            else:
                                # Preserve main's per-group HMA representation
                                # for attention-only hybrid models while
                                # accounting for the locally recomputed tail.
                                local_block_ids = self.get_exchange_clipped_blocks(
                                    blocks.get_block_ids()
                                )
                                adjusted_remote_block_ids = []
                                aligned_local_block_ids: list[list[int]] = []
                                for local_group, remote_group in zip(
                                    local_block_ids,
                                    remote_block_ids,
                                    strict=True,
                                ):
                                    aligned_local, aligned_remote = (
                                        self._align_read_blocks(
                                            local_group,
                                            remote_group,
                                            self._max_decode_tail_blocks,
                                        )
                                    )
                                    aligned_local_block_ids.append(aligned_local)
                                    adjusted_remote_block_ids.append(aligned_remote)
                                local_block_ids = aligned_local_block_ids
                        else:
                            if self._has_mamba:
                                # Attention can be a complete local hit, but the
                                # recurrent state is never prefix-cacheable.
                                _, mamba_block_groups = self.split_block_groups(
                                    blocks.get_block_ids()
                                )
                                local_block_ids = [[], *mamba_block_groups]
                            else:
                                # Nothing to pull, but retain one empty list per
                                # cache group so the worker can notify P.
                                local_block_ids = [[] for _ in remote_block_ids]

                        self._reqs_need_recv[request.request_id] = (
                            request,
                            local_block_ids,
                        )
                        # Snapshot params for chunked prefill consumption
                        # in build_connector_meta (see comment above).
                        saved_params = dict(params)
                        if num_external_tokens > 0:
                            saved_params["remote_block_ids"] = adjusted_remote_block_ids
                        self._req_kv_params[request.request_id] = saved_params
                    else:
                        logger.warning(
                            "Got invalid KVTransferParams: %s. This "
                            "request will not utilize KVTransfer",
                            params,
                        )

            else:
                # WRITE mode, decode side: notify P that blocks are ready
                assert request.kv_transfer_params is not None, (
                    "kv_transfer_params should not be None"
                )

                remote_dp_rank = request.kv_transfer_params.get("remote_dp_rank", 0)

                # Effective DP fan-out for the per-pod port/host math below
                # (see _remote_dp_rank_for_port / _pod_idx). Capped to the
                # per-pod local size when the router advertises it (Wide-EP).
                _dp_size = int(request.kv_transfer_params.get("remote_dp_size", 1) or 1)
                try:
                    _dp_local = int(
                        request.kv_transfer_params.get("remote_dp_size_local", 0) or 0
                    )
                    if _dp_local > 0:
                        _dp_size = min(_dp_size, _dp_local)
                except (TypeError, ValueError):
                    _dp_local = 0

                # Rank routing is ROUTER-AUTHORITATIVE: honor the router-pinned
                # remote_dp_rank (matched to the X-data-parallel-rank dispatch
                # pin). Self-deriving a rank could disagree and notify a rank
                # that never served the request. If unpinned in a multi-rank
                # deployment, warn instead of guessing.
                if (
                    _dp_size > 1
                    and "remote_dp_rank" not in request.kv_transfer_params
                    and "is_request_leader" not in request.kv_transfer_params
                ):
                    logger.warning(
                        "MoRI-IO decode notify: remote_dp_size=%d but the router "
                        "did not pin remote_dp_rank for request %s; defaulting to "
                        "rank 0. The router must set remote_dp_rank (and the "
                        "X-data-parallel-rank dispatch header) so the prefill and "
                        "decode legs agree on the same rank.",
                        _dp_size,
                        request.request_id,
                    )

                # Only the owning rank originates notify (exactly-once).
                # Priority: is_request_leader > remote_dp_rank_override > _is_kv_master
                _leader_flag = request.kv_transfer_params.get("is_request_leader")
                if _leader_flag is not None:
                    _should_notify = bool(_leader_flag)
                elif request.kv_transfer_params.get("remote_dp_rank_override"):
                    _should_notify = self._global_dp_rank == remote_dp_rank
                else:
                    _should_notify = self._is_kv_master
                if _should_notify:
                    peer_zmq = get_peer_zmq_from_request_id(
                        request.request_id, is_producer=False
                    )
                    if peer_zmq is not None:
                        remote_host, _, remote_notify_port = parse_moriio_zmq_address(
                            peer_zmq
                        )
                    else:
                        # Sidecar fallback: use explicit params fields.
                        params = request.kv_transfer_params or {}
                        remote_host = params.get("remote_host") or ""
                        try:
                            remote_notify_port = int(
                                params.get("remote_notify_port") or 0
                            )
                        except (TypeError, ValueError):
                            remote_notify_port = 0
                        if not remote_host or not remote_notify_port:
                            raise ValueError(
                                f"request {request.request_id!r}: "
                                f"request_id has no embedded peer "
                                f"zmq_address and kv_transfer_params is "
                                f"missing remote_host / remote_notify_port "
                                f"(got remote_host={remote_host!r}, "
                                f"remote_notify_port={remote_notify_port!r})"
                            )

                    # num_external_tokens == 0: nothing to push, so don't tell
                    # the producer to write into these blocks.
                    block_notify_list = (
                        blocks.get_block_ids()[0] if num_external_tokens > 0 else []
                    )

                    # Wide-EP multi-pod: a pod binds notify sockets only for
                    # its LOCAL ranks, so the port offset must use the per-pod
                    # local rank (% dp_local), not the global rank. Single-pod
                    # is bit-identical (modulus is a no-op).
                    _remote_dp_rank_for_port = fold_local_rank(
                        remote_dp_rank, _dp_local
                    )
                    # The target rank may live on a child pod at a different IP,
                    # so resolve the per-pod host (pod_idx = global // dp_local).
                    # Otherwise a notify for child ranks lands on the master
                    # pod and the request hangs in WAITING_FOR_REMOTE_KVS.
                    _notify_host = remote_host
                    _kvp = request.kv_transfer_params or {}
                    _remote_hosts = _kvp.get("remote_hosts") or []
                    if _dp_local > 0 and _remote_hosts:
                        _pod_idx = pod_index(remote_dp_rank, _dp_local)
                        if 0 <= _pod_idx < len(_remote_hosts):
                            _notify_host = _remote_hosts[_pod_idx]
                    for tp_index in range(self.tp_size):
                        target_port = remote_notify_port + get_port_offset(
                            _remote_dp_rank_for_port, tp_index
                        )

                        self.send_notify_block(
                            req_id=request.request_id,
                            transfer_id=request.kv_transfer_params["transfer_id"],
                            block_notify_list=block_notify_list,
                            host=_notify_host,
                            port=target_port,
                        )

            # Only trigger 1 KV transfer per request.

            params["do_remote_prefill"] = False

    def _clamp_to_prompt_blocks(self, req: "Request", block_ids: BlockIds) -> BlockIds:
        """Drop trailing speculative-lookahead blocks the consumer never
        allocated, keeping each full-attention group's prompt blocks.

        Args:
            req: Request being saved.
            block_ids: Per-KV-cache-group local block ids.

        Returns:
            ``block_ids`` with every full-attention group truncated to
            ``ceil(num_prompt_tokens / block_size)`` leading blocks;
            sliding-window groups are left unchanged.

        """
        clamped = list(block_ids)
        changed = False
        for g, group_blocks in enumerate(block_ids):
            if self.blocks_per_sw[g] != 0:
                continue
            num_prompt_blocks = math.ceil(
                req.num_prompt_tokens / self._group_block_sizes[g]
            )
            if len(group_blocks) > num_prompt_blocks:
                clamped[g] = group_blocks[:num_prompt_blocks]
                changed = True
        return clamped if changed else block_ids

    def _is_final_prefill_chunk(
        self, req: "Request", scheduler_output: SchedulerOutput
    ) -> bool:
        """Whether this step completes the prompt.

        ``build_connector_meta`` runs before ``_update_after_schedule``, so
        ``num_computed_tokens`` excludes the current chunk; add this step's
        scheduled tokens. Token progress is lookahead-safe unlike block counts.
        """
        num_scheduled = scheduler_output.num_scheduled_tokens.get(req.request_id, 0)
        return req.num_computed_tokens + num_scheduled >= req.num_prompt_tokens

    def build_connector_meta(
        self,
        scheduler_output: SchedulerOutput,
    ) -> KVConnectorMetadata:
        meta = MoRIIOConnectorMetadata()
        meta.transfer_id_to_request_id = self.transfer_id_to_request_id

        if self.mode == MoRIIOMode.WRITE and get_role() == ROLE.PRODUCER:
            # This is the logic for checking against chunked prefill.
            # When the last chunk is identified,
            # It places the request metadata into the saving queue.

            for i, req_id in enumerate(scheduler_output.scheduled_cached_reqs.req_ids):
                # Non-disagg requests aren't registered here; skip them
                # instead of KeyError-ing.
                if req_id not in self._reqs_need_pending_save:
                    continue
                req, existing_blocks = self._reqs_need_pending_save[req_id]
                # The final chunk may allocate no new blocks (the previous chunk
                # reserved speculative-lookahead slack), so new_block_ids is None;
                # still fall through to the final-chunk check below.
                new_block_ids = scheduler_output.scheduled_cached_reqs.new_block_ids[i]
                if new_block_ids is not None:
                    existing_blocks = [
                        existing_blocks[g] + new_block_ids[g]
                        for g in range(len(new_block_ids))
                    ]
                    self._reqs_need_pending_save[req_id] = (req, existing_blocks)
                if not self._is_final_prefill_chunk(req, scheduler_output):
                    continue
                # Live kv_transfer_params may be cleared; prefer the
                # update_state_after_alloc snapshot.
                kv_params = self._req_kv_params.pop(
                    req_id, req.kv_transfer_params or {}
                )
                save_block_ids = self._clamp_to_prompt_blocks(req, existing_blocks)
                meta.add_new_req(
                    request_id=req_id,
                    local_block_ids=save_block_ids,
                    kv_transfer_params=kv_params,
                    write_mode=True,
                )
                del self._reqs_need_pending_save[req_id]

        # Loop through scheduled reqs and convert to ReqMeta.
        for req_id, (req, block_ids) in self._reqs_need_recv.items():
            kv_params = self._req_kv_params.get(req_id, req.kv_transfer_params or {})
            meta.add_new_req(
                request_id=req_id,
                local_block_ids=block_ids,
                kv_transfer_params=kv_params,
            )
        if (
            self.mode == MoRIIOMode.READ
            and self._has_mamba
            and scheduler_output.new_block_ids_to_zero
        ):
            # Hybrid models zero recycled attention pages that held Mamba state.
            # Host-submitted READs overwrite these pages and can race zeroing.
            # Hybrid READ metadata puts the aligned attention pages first.
            read_dst_block_ids = {
                b
                for _, block_ids in self._reqs_need_recv.values()
                for b in block_ids[0]
            }
            scheduler_output.new_block_ids_to_zero = [
                b
                for b in scheduler_output.new_block_ids_to_zero
                if b not in read_dst_block_ids
            ]

        for req_id, (req, block_ids) in self._reqs_need_save.items():
            kv_params = self._req_kv_params.get(req_id, req.kv_transfer_params or {})
            if not self._is_final_prefill_chunk(req, scheduler_output):
                self._reqs_need_pending_save[req_id] = (req, block_ids)
                continue
            save_block_ids = self._clamp_to_prompt_blocks(req, block_ids)
            meta.add_new_req(
                request_id=req_id,
                local_block_ids=save_block_ids,
                kv_transfer_params=kv_params,
                write_mode=True,
            )
        # Clear the list once workers start the transfers

        meta.reqs_to_send = self._reqs_need_send

        # Reclaim snapshot cache entries that completed this step. Keep
        # entries that are still pending (chunked prefill not yet at the
        # final chunk) — those will be popped above on the final chunk.
        for req_id in self._reqs_need_recv:
            self._req_kv_params.pop(req_id, None)
        for req_id in self._reqs_need_save:
            if req_id not in self._reqs_need_pending_save:
                self._req_kv_params.pop(req_id, None)

        self._reqs_need_recv.clear()
        self._reqs_need_save.clear()
        self._reqs_need_send = {}

        return meta

    def shutdown(self):
        for path, sock in self.paths.items():
            try:
                sock.close(linger=0)
                logger.debug("Closed ZMQ socket for path: %s", path)
            except Exception as e:
                logger.warning("Error closing ZMQ socket for path %s: %s", path, e)
        self.paths.clear()

    def split_block_groups(
        self, block_ids: list[list[int]] | tuple[list[int], ...]
    ) -> tuple[list[int], list[list[int]]]:
        """Select transferable attention and Mamba block groups.

        The wire payload stores the attention group first, followed by every
        Mamba group in transfer-group order. Only each group's running-state
        slot is transferred.
        """
        if not block_ids:
            return [], []
        if not self._has_mamba:
            raise MoRIIOError("Mamba block groups requested for a non-hybrid model")
        transfer_block_ids = self.kv_cache_config.select_transfer_block_ids(block_ids)
        attn = list(transfer_block_ids[self._attn_group_ids[0]])
        mamba_groups = [
            clip_ssm_state_blocks(
                list(transfer_block_ids[group_id]),
                self._num_ssm_scratch_blocks,
            )
            for group_id in self._mamba_group_ids
        ]
        return attn, mamba_groups

    @staticmethod
    def _align_read_blocks(
        local_block_ids: list[int],
        remote_block_ids: list[int],
        max_decode_tail_blocks: int,
    ) -> tuple[list[int], list[int]]:
        """Pair a decode suffix with the corresponding prefill blocks.

        Prefix hits can make the decode's unhashed suffix shorter than the
        prefill's full list, so read from the matching remote suffix. The
        decoder can instead have extra tail blocks for the locally recomputed
        final token and speculative slots; these have no remote source and are
        not transferred.
        """
        if len(local_block_ids) > len(remote_block_ids):
            extra_decode_blocks = len(local_block_ids) - len(remote_block_ids)
            if extra_decode_blocks > max_decode_tail_blocks:
                raise ValueError(
                    "decode block ids exceed prefill block ids beyond the "
                    f"allowed local tail ({max_decode_tail_blocks} blocks): "
                    f"{len(local_block_ids)} > {len(remote_block_ids)}"
                )
            local_block_ids = local_block_ids[: len(remote_block_ids)]
        elif len(local_block_ids) < len(remote_block_ids):
            remote_block_ids = (
                remote_block_ids[-len(local_block_ids) :] if local_block_ids else []
            )
        return local_block_ids, remote_block_ids

    def request_finished(
        self,
        request: "Request",
        block_ids: BlockIds | list[int],
        mamba_block_groups: list[list[int]] | None = None,
    ) -> tuple[bool, dict[str, Any] | None]:
        """Once a request is finished, determine whether request blocks
        should be freed now or will be sent asynchronously and freed later.

        ``block_ids`` normally contains all cache groups. Hybrid callers from
        ``request_finished_all_groups`` pass a flat attention list and the
        recurrent-state groups separately in ``mamba_block_groups``.
        """
        request_id = request.request_id
        params = request.kv_transfer_params
        # Consumer: can unmap transfer_id<->request_id immediately since done_recving
        #   has fired at this point (i.e. KV has been transferred)
        # Producer: must keep the mapping until we get notification that blocks can
        #   be freed, which may be several scheduler steps later.
        if not self.is_producer:
            transfer_id = params.get("transfer_id") if params else None
            self.unmap_request_id(request_id, transfer_id=transfer_id)
        logger.debug(
            "MoriioConnector request_finished, request_status=%s, "
            "kv_transfer_params=%s",
            request.status,
            params,
        )
        if not params:
            return False, None

        if params.get("do_remote_prefill"):
            # If do_remote_prefill is still True when the request is finished,
            # update_state_after_alloc must not have been called (the request
            # must have been aborted before it was scheduled).
            # To avoid stranding the prefill blocks in the prefill instance,
            # READ mode adds empty block_ids to _reqs_need_recv so the worker
            # side notifies the prefill instance. WRITE mode should notify the
            # producer directly: there is no decode allocation for the producer
            # to write into, and a plain request_id may not contain router-
            # embedded MoRIIO ZMQ addresses.
            if self.mode == MoRIIOMode.WRITE:
                self._release_write_prefill_blocks(request.request_id, params)
            else:
                # Carry the actually-allocated blocks (incl. the per-request KDA
                # mamba slot) instead of []: a do_remote_prefill request finishing
                # before update_state_after_alloc still has blocks, and dropping the
                # mamba slot here would re-trip the KDA guard in _read_blocks.
                if mamba_block_groups:
                    recv_blocks: BlockIds = [
                        list(cast(list[int], block_ids)),
                        *[list(group) for group in mamba_block_groups],
                    ]
                elif block_ids and isinstance(block_ids[0], int):
                    recv_blocks = [list(cast(list[int], block_ids))]
                else:
                    grouped_block_ids = cast(BlockIds, block_ids)
                    recv_blocks = (
                        [list(group) for group in grouped_block_ids]
                        if self._has_mamba
                        else [[] for _ in self.blocks_per_sw]
                    )
                self._reqs_need_recv[request.request_id] = (request, recv_blocks)
            params["do_remote_prefill"] = False
            return False, None

        if (
            not params.get("do_remote_decode")
            or request.status != RequestStatus.FINISHED_LENGTH_CAPPED
        ):
            return False, None

        # On producer
        if mamba_block_groups is not None:
            computed_block_ids: BlockIds = [
                list(cast(list[int], block_ids)),
                *[list(group) for group in mamba_block_groups],
            ]
        elif self._has_mamba:
            raise MoRIIOError("Hybrid request completion requires all KV cache groups")
        else:
            computed_block_ids = self.get_exchange_clipped_blocks(
                cast(BlockIds, block_ids)
            )
        delay_free_blocks = any(len(group) > 0 for group in computed_block_ids)

        if delay_free_blocks:
            # Prefill request on remote. It will be read from D upon completion
            self._reqs_need_send[request.request_id] = (
                time.perf_counter()
                + MoRIIOConstants.VLLM_MORI_READ_ABORT_REQUEST_TIMEOUT
            )
            self._deferred_send_deadlines[request.request_id] = (
                time.monotonic() + self._defer_timeout,
                params.get("transfer_id") if params else None,
            )

        # Return KV transfer params forwarded verbatim to the decode instance by
        # the router. remote_dp_rank is the rank THIS prefill leg actually ran
        # on: on the returnable paths (READ / serial WRITE) the router forwards
        # it to the decode leg, so the decode->prefill notify is routed by pure
        # propagation of the producer's real rank -- no hashing, no reliance on
        # the router independently pinning the same rank. remote_dp_rank_override
        # makes the decode side honor it via the global-rank match gate.
        return delay_free_blocks, dict(
            do_remote_prefill=True,
            do_remote_decode=False,
            remote_block_ids=computed_block_ids,
            remote_engine_id=self.engine_id,
            remote_host=self.host_ip,
            remote_handshake_port=self.handshake_port,
            remote_notify_port=self.side_notify_port,
            remote_dp_rank=self._global_dp_rank,
            remote_dp_rank_override=True,
            remote_dp_size=self.vllm_config.parallel_config.data_parallel_size,
            remote_dp_size_local=(
                self.vllm_config.parallel_config.data_parallel_size_local
            ),
            tp_size=self.vllm_config.parallel_config.tensor_parallel_size,
            transfer_id=params["transfer_id"],
        )

    def update_connector_output(self, connector_output: KVConnectorOutput) -> None:
        """Reconcile worker finished_sending ACKs with the producer lifecycle.

        Called every scheduler step (when there is KV connector output),
        BEFORE the scheduler's finished_sending free loop. We rewrite
        ``connector_output.finished_sending`` in place so it contains
        exactly the producer requests that are safe for the scheduler to
        free this step, letting the scheduler keep the plain upstream
        ``assert req_id in self.requests`` + ``_free_blocks`` path:

        * An ACK whose request is in ``_deferred_send_deadlines``
          (request_finished ran with delay_free_blocks=True, so the
          scheduler is holding its blocks) is surfaced -> freed now.
        * An ACK that arrives BEFORE its request finished is parked in
          ``_pending_sent_acks`` and released on a later step once the
          request enters ``_deferred_send_deadlines``.
        * A deferred send whose ACK never arrives is reaped after
          ``_defer_timeout`` and surfaced, so leaked blocks are freed.
        * A parked ACK that never matches a deferral before its own
          deadline is a stale duplicate (e.g. a real ACK landing after the
          send was already reaped) and is dropped.

        Consumers never populate finished_sending (they report
        finished_recving), and they unmap in request_finished, so this is a
        no-op for them.
        """
        if not self.is_producer:
            return

        incoming = set(connector_output.finished_sending or ())
        now = time.monotonic()

        # Surface ACKs whose request is already finished (blocks held for
        # delayed free); park the rest until their request finishes.
        safe: set[ReqId] = set()
        for req_id in incoming:
            if req_id in self._deferred_send_deadlines:
                safe.add(req_id)
            else:
                self._pending_sent_acks.setdefault(req_id, now + self._defer_timeout)

        # Release previously parked ACKs whose request has since finished.
        for req_id in self._pending_sent_acks:
            if req_id in self._deferred_send_deadlines:
                safe.add(req_id)

        # Reap deferred sends whose ACK never arrived (avoid leaking blocks).
        expired = [
            req_id
            for req_id, (deadline, _) in self._deferred_send_deadlines.items()
            if now >= deadline
        ]
        if expired:
            safe.update(expired)
            logger.warning(
                "Reaped %d deferred sends with no finished_sending "
                "notification after %.0fs. This indicates lost async KV "
                "completion notifications from the KV connector.",
                len(expired),
                self._defer_timeout,
            )

        # Finalize the requests we are surfacing: drop their deferral/park
        # bookkeeping and unmap their transfer ids.
        for req_id in safe:
            deferred_info = self._deferred_send_deadlines.pop(req_id, None)
            transfer_id = deferred_info[1] if deferred_info else None
            self._pending_sent_acks.pop(req_id, None)
            self.unmap_request_id(req_id, transfer_id=transfer_id)

        # Drop stale parked ACKs that never matched a deferral in time.
        stale = [
            req_id
            for req_id, deadline in self._pending_sent_acks.items()
            if now >= deadline
        ]
        for req_id in stale:
            self._pending_sent_acks.pop(req_id, None)

        connector_output.finished_sending = safe or None


class MoRIIOConnectorWorker:
    """Implementation of Worker side methods."""

    def __init__(
        self,
        vllm_config: VllmConfig,
        engine_id: str,
        kv_cache_config: "KVCacheConfig",
    ):
        if not is_moriio_available():
            raise RuntimeError(
                "MoRIIO is not available. Please ensure the 'mori' package "
                "is installed and properly configured."
            )

        assert vllm_config.kv_transfer_config is not None
        self.moriio_config = MoRIIOConfig.from_vllm_config(vllm_config)
        self.mode = (
            MoRIIOMode.READ if self.moriio_config.read_mode else MoRIIOMode.WRITE
        )

        logger.info("Initializing MoRIIO worker %s", engine_id)

        logging.getLogger("aiter").disabled = True

        # Config.
        self.vllm_config = vllm_config
        assert vllm_config.kv_transfer_config is not None, (
            "kv_transfer_config must be set for MoRIIOConnector"
        )
        self.kv_transfer_config = vllm_config.kv_transfer_config
        self.is_producer = self.kv_transfer_config.is_kv_producer
        self.layer_to_spec = build_layer_to_spec(kv_cache_config)
        # we transfer by layer, but store by kv cache group
        self.layer_to_group = dict(kv_cache_config.transfer_group_index_by_layer)
        self._transfer_layer_names = set(self.layer_to_group)
        _, mamba_transfer_group_ids = _split_kv_cache_group_kinds(kv_cache_config)
        self._num_mamba_transfer_groups = len(mamba_transfer_group_ids)
        self._mamba_payload_index_by_layer = {
            layer_name: payload_index
            for payload_index, group_id in enumerate(mamba_transfer_group_ids, start=1)
            for layer_name in kv_cache_config.transfer_groups[group_id].layer_names
        }

        if self.is_producer:
            set_role(ROLE.PRODUCER)
        else:
            set_role(ROLE.CONSUMER)
        # mori engine
        self._rank = get_world_group().rank
        self._local_rank = get_world_group().local_rank
        self.tp_rank = self.moriio_config.tp_rank
        self.dp_rank = self.moriio_config.dp_rank

        self.local_ip = self.moriio_config.local_ip
        self.local_kv_port = self.moriio_config.local_kv_port
        self.proxy_ip = self.moriio_config.proxy_ip
        self.local_ping_port = self.moriio_config.local_ping_port
        self.proxy_ping_port = self.moriio_config.proxy_ping_port
        self.http_port = self.moriio_config.http_port
        self.handshake_port = self.moriio_config.handshake_port
        self.notify_port = self.moriio_config.notify_port

        self.zmq_context = zmq.Context()
        self.metadata_address = (
            f"{self.moriio_config.local_ip}:{self.moriio_config.local_ping_port}"
        )
        self.request_address = (
            f"{self.moriio_config.local_ip}:{self.moriio_config.http_port}"
        )

        self.moriio_engine = None
        self._handle_request_thread = None
        self._heartbeat: MoRIIOHeartbeat | None = None
        self._writer = MoRIIOWriter(self)
        # Completions that arrived before transfer_id_to_request_id was populated.
        # Retried each step until the mapping is established.
        self._unmatched_write_completions: set[str] = set()
        # Producer-side READ-mode ACK fan-in. When decode TP is larger than
        # prefill TP, multiple decode ranks can read from one prefill rank and
        # notify the same transfer_id. Blocks are reusable only after all ACKs.
        self._consumer_notification_counts: dict[TransferId, int] = {}
        self._completed_consumer_notifications: set[TransferId] = set()

        role = "producer" if self.is_producer else "consumer"
        engine_suffix = (
            f"{self.moriio_config.local_ip}:{self.moriio_config.handshake_port}:"
            f"tp{self.tp_rank}:dp{self.dp_rank}"
        )
        self.moriio_engine = IOEngine(
            f"{role}:{engine_suffix}",
            IOEngineConfig(
                self.moriio_config.local_ip, self.moriio_config.local_kv_port
            ),
        )
        logger.debug(
            "build MORI IOEngine %s (ip=%s port=%s)",
            f"{role}:{engine_suffix}",
            self.moriio_config.local_ip,
            self.moriio_config.local_kv_port,
        )

        if self._rank == 0 and self.moriio_config.proxy_ip:
            self._heartbeat = self._start_heartbeat()

        logger.info(
            "Initializing MoRIIO Engine, engine = %s, role = %s",
            self.moriio_engine,
            "producer" if self.is_producer else "consumer",
        )

        # Agent.
        self.moriio_wrapper = MoRIIOWrapper(
            tp_rank=self.tp_rank,
            dp_rank=self.dp_rank,
            transfer_timeout=self.moriio_config.transfer_timeout,
        )
        self.moriio_wrapper.set_moriio_engine(self.moriio_engine)
        backend = (
            BackendType.XGMI
            if self.moriio_config.backend == "xgmi"
            else BackendType.RDMA
        )
        self.moriio_wrapper.set_backend_type(
            backend,
            qp_per_transfer=self.moriio_config.qp_per_transfer,
            post_batch_size=self.moriio_config.post_batch_size,
            num_workers=self.moriio_config.num_workers,
        )
        self.moriio_wrapper.notify_port = self.moriio_config.notify_port
        self.local_kv_cache_metadata: list[bytes] = []
        self.local_kv_cache_size: list[int] = []
        self.layer_name_to_local_kv_cache_metadata: dict[str, list[bytes]] = {}

        self.remote_kv_cache_metadata: list[bytes] = []
        self.remote_kv_cache_size: list[int] = []
        self.layer_name_to_remote_kv_cache_metadata: dict[str, dict[str, list[Any]]] = (
            dict()
        )
        self.remote_moriio_metadata: dict[EngineId, MoRIIOAgentMetadata] = {}
        self.slot_size_bytes = 0

        self.load_ready_flag: dict[str, bool] = {}
        self.write_ready_flags: dict[str, bool] = {}
        self.kv_cache_shape = None
        self.block_shape = None
        self.kv_element_size = 0
        self.kv_cache_shapes: dict[str, torch.Size] = {}
        self.block_lens: dict[str, int] = {}

        # Map of engine_id -> {agent_name0, agent_name1..}.
        self._remote_agents: dict[EngineId, set[str]] = {}

        self.side_channel_port: int = (
            self.moriio_config.handshake_port
            + get_port_offset(self.dp_rank, self.tp_rank)
        )
        self.engine_id: EngineId = engine_id

        self.world_size = get_tensor_model_parallel_world_size()
        self.tp_group = get_tp_group()

        # KV Caches and moriio tracking data.
        self.kv_caches: dict[str, torch.Tensor] = {}
        self.kv_layer_mr_offset: dict[str, int] = {}
        self.layer_base_addr_index: dict[str, int] = {}

        # Map of engine_id -> kv_caches_base_addr. For TP case, each local
        # rank will still only pull from a single remote TP worker.
        self.kv_caches_base_addr: dict[EngineId, list[int]] = {}

        # Number of MoRIIO regions. Currently one region per cache
        # (so 1 per layer for MLA, otherwise 2 per layer)
        self.num_regions = 0
        self.num_layers = 0

        # Map of engine_id -> num_blocks. All ranks in the same deployment will
        # have the same number of blocks.
        self.dst_num_blocks: dict[EngineId, int] = {}
        # In-progress READ transfers: req_id -> {layer_name: [statuses]}.
        # A KDA layer posts two reads (conv + ssm), so a layer maps to a list.
        self._recving_transfers: defaultdict[ReqId, dict] = defaultdict(dict)
        # Values are (remote_host, remote_notify_port, transfer_id).
        self._recving_transfers_callback_addr: dict[ReqId, tuple[str, str, str]] = {}
        # Monotonic-clock start times for each in-flight recv transfer.
        # Used by _pop_done_transfers to abort transfers whose RDMA
        # completion is lost, instead of hanging forever.
        self._recving_transfers_start: dict[str, float] = {}
        # Destination attention blocks per in-flight recv. Failed non-HMA reads
        # report these to the scheduler's single-group recovery path.
        self._recving_local_blocks: dict[ReqId, list[int]] = {}
        # Drained by get_block_ids_with_load_errors.
        self._invalid_block_ids: set[int] = set()
        # This step's posted reads, awaited before the forward when the
        # per-layer barrier cannot run.
        self._reads_issued_this_step: list = []
        # This step's posted recurrent-state reads. Mamba layers are not
        # wrapped by the attention KV-transfer decorator, so wait_for_layer_load
        # never fires for them and these must be awaited in start_load_kv.
        self._mamba_reads_this_step: list = []

        # Track the expiration time of requests that are waiting to be sent.
        self._reqs_to_send: dict[ReqId, float] = {}

        # Background thread for handling new handshake requests.
        self._moriio_handshake_listener_t: threading.Thread | None = None
        # Background thread for initializing new MoRIIO handshakes.
        self._handshake_initiation_executor = ThreadPoolExecutor(
            # MoRIIO is not guaranteed to be thread-safe, limit 1 worker.
            max_workers=1,
            thread_name_prefix="vllm-moriio-handshake-initiator",
        )
        self._ready_requests = queue.Queue[tuple[ReqId, ReqMeta]]()
        self._handshake_futures: dict[EngineId, Future[set[str]]] = {}
        # Protects _handshake_futures and _remote_agents.
        self._handshake_lock = threading.RLock()
        # Remote engines already covered by the eager pre-forward handshake.
        self._eager_handshaked_engines: set[EngineId] = set()

        self.block_size = vllm_config.cache_config.block_size
        self.model_config = vllm_config.model_config
        self.cache_config = vllm_config.cache_config

        self.block_window_per_layer: list[int | None] = []
        self.use_mla = self.model_config.use_mla
        # Hybrid (mamba/KDA) recurrent-state transfer. Populated in
        # register_kv_caches when the model has a MambaSpec kv_cache group.
        self._has_mamba = False
        self._conv_decomp: MambaConvSplitInfo | None = None
        self._mamba_offset_templates: dict[str, MambaOffsetTemplate] = {}
        # layer_name -> flat session indices (one per registered region:
        # 1 for attention, 2 (conv, ssm) for a KDA layer). Built once lazily.
        self._region_session_index: dict[str, list[int]] | None = None
        self.built_session = False
        self.built_write_session: defaultdict[str, list] = defaultdict(list)
        backend = get_attn_backend(
            self.model_config.get_head_size(),
            self.model_config.dtype,
            self.cache_config.cache_dtype,
            use_mla=self.use_mla,
        )
        self.transfer_id_to_request_id: dict[TransferId, ReqId] = {}
        # READ-mode producer: a decode release-ACK can arrive BEFORE
        # start_load_kv populates transfer_id_to_request_id (the notify races
        # ahead of the scheduler->worker sync). Buffer such ACKs and retry them
        # next get_finished tick instead of dropping them -- dropping loses the
        # completion, so the request is never marked done_sending, its KV blocks
        # leak, and the prefill KV cache wedges at high concurrency. Buffered
        # BEFORE resolve_moriio_transfer_ack, so each ACK is counted exactly once
        # (on the tick its mapping exists) -- the heterogeneous-TP ack-counting
        # is preserved.
        self._pending_unmapped_acks: list = []

        # TODO: consider the integration of flashinfer or other backends.
        self.backend_name = backend.get_name()
        logger.debug("Detected attention backend %s", self.backend_name)

    def schedule_write_blocks(
        self,
        request_id: ReqId,
        transfer_id: TransferId,
        dst_engine_id: str,
        local_block_ids: list[int],
        remote_block_ids: list[int] | None,
        layer_name: str,
        kv_layer: torch.Tensor,
        remote_notify_port: int,
        remote_ip: str,
        multi_pod_hosts: list[str],
        remote_dp_size_local: int,
    ) -> None:
        """Schedule a block write operation.

        Args:
            request_id: Unique identifier for the request
            transfer_id: Unique identifier for the transfer
            dst_engine_id: Destination engine ID
            local_block_ids: Local block IDs to transfer
            remote_block_ids: Hint for remote block IDs
            layer_name: Name of the layer
            kv_layer: KV cache tensor
            remote_notify_port: Port for completion notification
            remote_ip: IP address of remote node
            multi_pod_hosts: List of pod IPs for multi-pod Wide-EP
            remote_dp_size_local: Per-pod DP size for multi-pod

        """
        # synchronization to prevent dirty reads between
        # transfer and attention operations
        # we can consider removing this synchronization after ibgda is enabled.
        # when mori-io supports ibgda functionality

        stream = torch.cuda.current_stream()
        event = torch.cuda.Event()
        event.record(stream)

        task = WriteTask(
            request_id=request_id,
            transfer_id=transfer_id,
            dst_engine_id=dst_engine_id,
            local_block_ids=local_block_ids,
            remote_block_ids_hint=remote_block_ids,
            layer_name=layer_name,
            event=event,
            remote_notify_port=remote_notify_port,
            remote_ip=remote_ip,
            multi_pod_hosts=multi_pod_hosts,
            remote_dp_size_local=remote_dp_size_local,
        )
        self._writer.schedule_write(task)

    def _get_built_session(self, remote_engine_id):
        if remote_engine_id not in self.built_write_session:
            remote_layer_map = self.layer_name_to_remote_kv_cache_metadata[
                remote_engine_id
            ]
            cur_remote_engine_sessions = []
            for ln, local_metas in self.layer_name_to_local_kv_cache_metadata.items():
                remote_metas = remote_layer_map[ln]
                if len(remote_metas) != len(local_metas):
                    # Sessions are addressed by region index, so a peer that
                    # registered a different number of regions for this layer
                    # would not just lose a region to zip(): every later index
                    # would point into the wrong layer's session.
                    raise MoRIIOError(
                        f"peer {remote_engine_id} registered "
                        f"{len(remote_metas)} region(s) for layer {ln}, this "
                        f"engine has {len(local_metas)}; the two sides must run "
                        "the same model and KV cache layout"
                    )
                # One session per registered region, in registration order:
                # attention layers have a single region; KDA layers have two
                # (conv then ssm). This flat layout is indexed via
                # _region_session_indices(layer_name).
                for local_meta, remote_meta in zip(local_metas, remote_metas):
                    unpacked_local_memory_meta = (
                        self.moriio_wrapper.get_unpack_memory_metadata(local_meta)
                    )
                    unpacked_remote_memory_meta = (
                        self.moriio_wrapper.get_unpack_memory_metadata(remote_meta)
                    )
                    cur_remote_engine_sessions.append(
                        self.moriio_wrapper.build_session(
                            unpacked_local_memory_meta, unpacked_remote_memory_meta
                        )
                    )
            self.built_write_session[remote_engine_id] = cur_remote_engine_sessions
        return self.built_write_session[remote_engine_id], self.remote_moriio_metadata[
            remote_engine_id
        ]

    def _start_heartbeat(self) -> MoRIIOHeartbeat:
        payload = {
            "type": "P" if self.is_producer else "D",
            "http_address": self.request_address,
            "zmq_address": (
                f"host:{self.local_ip},handshake:{self.handshake_port},"
                f"notify:{self.notify_port}"
            ),
            "dp_size": self.moriio_config.dp_size,
            "tp_size": self.moriio_config.tp_size,
            "transfer_mode": self.mode.name,
        }
        return MoRIIOHeartbeat(
            f"tcp://{self.proxy_ip}:{self.proxy_ping_port}",
            payload,
            MoRIIOConstants.PING_INTERVAL,
            MoRIIOConstants.MAX_PING_RETRIES,
        )

    def shutdown(self):
        heartbeat = getattr(self, "_heartbeat", None)
        if heartbeat is not None:
            heartbeat.shutdown()
            self._heartbeat = None

        if hasattr(self, "moriio_wrapper") and self.moriio_wrapper:
            self.moriio_wrapper.shutdown()

        if hasattr(self, "_handshake_initiation_executor"):
            self._handshake_initiation_executor.shutdown(wait=False)

        if (
            hasattr(self, "_moriio_handshake_listener_t")
            and self._moriio_handshake_listener_t
        ):
            self._moriio_handshake_listener_t.join(timeout=0)

        if hasattr(self, "zmq_context") and self.zmq_context:
            self.zmq_context.destroy(linger=0)
            self.zmq_context = None

    def __del__(self):
        self.shutdown()

    @staticmethod
    def _moriio_handshake_listener(
        metadata: MoRIIOAgentMetadata,
        ready_event: threading.Event,
        base_port: int,
        tp_rank: int,
        dp_rank: int,
        layer_name_to_local_kv_cache_metadata: dict,
    ):
        """Background thread for getting new MoRIIO handshakes."""
        encoder = msgspec.msgpack.Encoder()
        encoded_data = encoder.encode(metadata)
        size_in_bytes = len(encoded_data)
        logger.debug(
            "Size of encoded MoRIIOAgentMetadata: %s bytes", str(size_in_bytes)
        )

        # Listen for new requests for metadata.
        host = "*"

        path = make_zmq_path("tcp", host, base_port)
        logger.debug("mori handshake starting listening on path: %s", path)

        with zmq_ctx(zmq.ROUTER, path) as sock:
            ready_event.set()
            while True:
                identity, msg = sock.recv_multipart()
                if (
                    msg != MoRIIOConstants.GET_META_MSG
                    and msg != MoRIIOConstants.POP_DONE_RECV
                ):
                    logger.error("Connection listener got unexpected message")
                    raise HandshakeError("handshake failed, unexpected msg type")
                elif msg == MoRIIOConstants.GET_META_MSG:
                    sock.send_multipart(
                        (identity, b"", encoded_data)
                    )  # send local mori io engine meta data
                    logger.debug("MoRIIO handshake listener sent metadata")
                    # now we send tensor meta data for each block
                    buf = msgpack.dumps(layer_name_to_local_kv_cache_metadata)
                    sock.send_multipart((identity, b"", buf))
                elif msg == MoRIIOConstants.POP_DONE_RECV:
                    _, req_id = sock.recv_multipart()
                    logger.debug(
                        "MoRIIO handshake listener received done recv for req",
                        req_id.decode(),
                    )

    def _moriio_handshake(
        self,
        host: str,
        port: int,
        remote_tp_size: int,
        expected_engine_id: str,
        remote_dp_rank: int = 0,
        remote_tp_rank: int | None = None,
    ) -> set[str]:
        """Do a MoRIIO handshake with a remote instance.

        remote_tp_rank: explicit remote TP index to dial. Flexible-read callers
        pass the chosen prefill TP rank so the handshake, the (dp, tp) session
        key and the notify port all address the SAME rank. None falls back to the
        local-rank mapping _remote_tp_rank -- byte-identical for callers not yet
        TP-aware.
        """
        start_time = time.perf_counter()

        # NOTE(rob): we need each rank to have a unique port. This is
        # a hack to keep us moving. We will switch when moving to etcd
        # or where we have a single ZMQ socket in the scheduler.

        dial_tp_rank = (
            self._remote_tp_rank(remote_tp_size)
            if remote_tp_rank is None
            else int(remote_tp_rank)
        )
        port_offset = get_port_offset(remote_dp_rank, dial_tp_rank, remote_tp_size)
        path = make_zmq_path("tcp", host, port + port_offset)
        logger.debug("handshake Querying metadata on path: %s", path)

        # Send query for the request.
        with zmq_ctx(zmq.DEALER, path) as sock:
            logger.debug("prepare send msg INSTAZNCE: %s", path)
            sock.send(MoRIIOConstants.GET_META_MSG)
            received_frame = sock.recv_multipart()
            if len(received_frame) != 2 or received_frame[0] != b"":
                raise HandshakeError(f"Unexpected frame! {received_frame = }")

            metadata_bytes = received_frame[1]
            decoder = msgspec.msgpack.Decoder(MoRIIOAgentMetadata)
            metadata = decoder.decode(metadata_bytes)
            got_metadata_time = time.perf_counter()
            logger.info(
                "MoRIIO handshake: get metadata took: %s",
                got_metadata_time - start_time,
            )

            self.moriio_wrapper.remote_engine_ip = host
            remote_agent_name = self.moriio_wrapper.register_remote_engine(
                metadata.agent_metadata
            )

            logger.debug(
                "MoRIIO handshake: registered"
                "remote agent %s for engine ID %s, path = %s",
                remote_agent_name,
                expected_engine_id,
                path,
            )

            if len(self.local_kv_cache_metadata) > 0:
                logger.warning(
                    "len(self.local_kv_cache_metadata) = %s,"
                    "maybe you didnt clear this buffer correctly",
                    len(self.local_kv_cache_metadata),
                )
                self.local_kv_cache_metadata = []
            if len(self.remote_kv_cache_metadata) > 0:
                logger.warning(
                    "len(self.remote_kv_cache_metadata) = %s,"
                    "maybe you didnt clear this buffer correctly",
                    len(self.remote_kv_cache_metadata),
                )
                self.remote_kv_cache_metadata = []

            received_frame = sock.recv_multipart()
            if len(received_frame) != 2 or received_frame[0] != b"":
                raise HandshakeError(f"unexpected frame! {received_frame = }")
            buf = received_frame[1]
            self.layer_name_to_remote_kv_cache_metadata[expected_engine_id] = (
                msgpack.loads(buf)
            )
            self.remote_moriio_metadata[expected_engine_id] = metadata
            setup_agent_time = time.perf_counter()
            logger.debug(
                "MoRIIO handshake: add agent took: %s",
                setup_agent_time - got_metadata_time,
            )

        return {remote_agent_name}

    def _remote_tp_rank(self, remote_tp_size: int) -> int:
        # 0/unknown remote TP == homogeneous (avoids collapsing all ranks to 0).
        if remote_tp_size == 0:
            remote_tp_size = self.world_size
        return get_moriio_remote_tp_rank(self.tp_rank, self.world_size, remote_tp_size)

    def _background_moriio_handshake(
        self, req_id: ReqId, remote_engine_id: EngineId, meta: ReqMeta
    ):
        # Do MoRIIO handshake in background and add to _ready_requests when done.
        fut = None
        if remote_engine_id is not None:
            fut = self._handshake_futures.get(remote_engine_id)
        if fut is None:
            host = meta.remote_host
            port = int(meta.remote_handshake_port)
            tp_size = int(meta.tp_size)
            remote_dp_size = int(meta.remote_dp_size)
            # Wide-EP multi-pod: remote DP ranks span pods at different IPs
            # (ranks per pod = dp_local), so resolve the host per cur_dp_rank
            # below instead of using a single host for all ranks.
            pod_hosts = list(meta.multi_pod_hosts) if meta.multi_pod_hosts else [host]
            remote_dp_size_local = int(meta.remote_dp_size_local) or remote_dp_size

        def request_ready(_f: Future[Any], entry=(req_id, meta)):
            logger.info("MoRIIO handshake done for request %s", req_id)
            self._ready_requests.put(entry)
            self.load_ready_flag[remote_engine_id] = True
            self.write_ready_flags[remote_engine_id] = True

        fut_list = []

        # In dp(prefill)<->dp(decode) communication, we require an all-to-all handshake.

        for cur_dp_rank in range(remote_dp_size):
            dp_engine_id = self.get_engine_name_with_dp(remote_engine_id, cur_dp_rank)
            _pod_idx = pod_index(cur_dp_rank, remote_dp_size_local)
            if _pod_idx >= len(pod_hosts):
                _pod_idx = 0
            _per_rank_host = pod_hosts[_pod_idx]
            # The handshake port offset must use the per-pod local rank, since
            # each pod binds sockets only for its local ranks; dp_engine_id
            # keeps the global rank for uniqueness. Single-pod is bit-identical.
            _per_rank_local_dp = fold_local_rank(cur_dp_rank, remote_dp_size_local)
            future = self._handshake_initiation_executor.submit(
                self._moriio_handshake,
                _per_rank_host,
                port,
                tp_size,
                dp_engine_id,
                _per_rank_local_dp,
            )
            fut_list.append(future)

            def done_callback(f: Future[set[str]], eid=dp_engine_id):
                with self._handshake_lock:
                    self._handshake_futures.pop(eid, None)
                    try:
                        self._remote_agents[eid] = f.result()
                    except Exception:
                        logger.exception("Handshake with %s failed", eid)

            future.add_done_callback(done_callback)
            self._handshake_futures[dp_engine_id] = future

        # fut = fut_list
        def wait_all_dp():
            for future in fut_list:
                future.result()
            return True

        all_done_future = self._handshake_initiation_executor.submit(wait_all_dp)
        all_done_future.add_done_callback(request_ready)

    def _is_mla_cache_layer(self, layer_name: str) -> bool:
        return is_mla_cache_layer(self.layer_to_spec, layer_name)

    def _is_mamba_layer(self, layer_name: str) -> bool:
        """True for a hybrid/KDA layer backed by a packed state page."""
        return isinstance(self.layer_to_spec.get(layer_name), MambaSpec)

    @staticmethod
    def _contiguous_byte_alias(tensor: torch.Tensor) -> torch.Tensor:
        """Return a contiguous uint8 view over ``tensor``'s full byte extent.

        KDA conv/ssm caches are slot-strided views (``stride(0)`` may exceed the
        per-slot element count), so they are non-contiguous and cannot be passed
        to ``register_torch_tensor``. This aliases the same storage (zero-copy,
        identical ``data_ptr``) as a flat uint8 tensor spanning
        ``shape[0] * stride(0)`` elements -- the full slot-strided extent that
        transfer offsets (``slot * stride(0) * elem``) address.
        """
        esz = tensor.element_size()
        storage_nbytes = tensor.untyped_storage().nbytes()
        offset_bytes = tensor.storage_offset() * esz
        extent_bytes = tensor.shape[0] * tensor.stride(0) * esz
        # Clamp to the bytes remaining from the view's storage offset. In a
        # packed page, the ssm view starts after conv, so its slot-strided extent
        # would otherwise run past the backing allocation.
        extent_bytes = min(extent_bytes, storage_nbytes - offset_bytes)
        assert extent_bytes > 0, (
            "KDA byte alias empty: storage_offset="
            f"{tensor.storage_offset()} * esz={esz} >= "
            f"storage_nbytes={storage_nbytes}"
        )
        alias = torch.empty(0, dtype=torch.uint8, device=tensor.device)
        alias.set_(
            tensor.untyped_storage(),
            tensor.storage_offset() * esz,
            (extent_bytes,),
            (1,),
        )
        return alias

    def _get_layer_transfer_geometry(
        self, layer_name: str, remote_num_blocks: int | None = None
    ) -> LayerTransferGeometry:
        geometry = get_layer_transfer_geometry(
            layer_name,
            self.kv_caches[layer_name],
            self.layer_to_spec,
            remote_num_blocks,
        )
        # get_layer_transfer_geometry also serves mamba layers, whose geometry
        # is a different NamedTuple with no block fields. Every caller here is
        # on the attention path (mamba layers return before reaching it), so
        # narrow the type instead of leaking the union.
        assert isinstance(geometry, LayerTransferGeometry), (
            f"layer {layer_name} is a mamba layer; use get_mamba_transfer_geometry"
        )
        return geometry

    def _iter_layer_registration_regions(
        self, layer_name: str
    ) -> list[tuple[torch.Tensor, int]]:
        return iter_layer_registration_regions(
            layer_name,
            self.kv_caches[layer_name],
            self.layer_to_spec,
        )

    def _build_shared_kv_mr(
        self, kv_caches: dict[str, torch.Tensor]
    ) -> tuple[torch.Tensor, dict[str, int]]:
        page_size = 4096
        backing = next(iter(kv_caches.values())).view(torch.uint8)
        nbytes = backing.untyped_storage().nbytes()
        base = torch.as_strided(backing, (nbytes,), (1,), 0)
        ptr = base.data_ptr()
        slack = ptr % page_size
        end = 0
        for layer_name in kv_caches:
            _, region_len = next(
                iter(self._iter_layer_registration_regions(layer_name))
            )
            end = max(end, kv_caches[layer_name].data_ptr() - ptr + region_len)
        reg_nbytes = ((slack + end + page_size - 1) // page_size) * page_size
        if reg_nbytes > nbytes:
            raise ValueError(
                f"shared KV backing too small for page-aligned MR: "
                f"need {reg_nbytes}, have {nbytes}"
            )
        reg = torch.as_strided(base, (reg_nbytes,), (1,), 0 if slack == 0 else -slack)
        mr_ptr = reg.data_ptr()
        return reg, {
            name: cache.data_ptr() - mr_ptr for name, cache in kv_caches.items()
        }

    def _remote_layer_mr_offset(
        self,
        layer_name: str,
        remote_moriio_meta: MoRIIOAgentMetadata,
        remote_engine_id: EngineId | None,
    ) -> int:
        if not self.kv_layer_mr_offset or not remote_engine_id:
            return 0
        idx = self.layer_base_addr_index[layer_name]
        metas = self.layer_name_to_remote_kv_cache_metadata.get(
            remote_engine_id, {}
        ).get(layer_name)
        if not metas or idx >= len(remote_moriio_meta.kv_caches_base_addr):
            return 0
        mr_base = self.moriio_wrapper.get_unpack_memory_metadata(metas[0]).data
        return remote_moriio_meta.kv_caches_base_addr[idx] - mr_base

    def register_kv_caches(self, kv_caches: dict[str, torch.Tensor]):
        """Register the KV Cache data in moriio."""
        kv_caches = {
            layer_name: kv_cache
            for layer_name, kv_cache in kv_caches.items()
            if layer_name in self._transfer_layer_names
        }
        if not kv_caches:
            raise MoRIIOError("MoRIIO has no transfer-enabled KV cache layers")
        self.kv_caches = kv_caches  # layer name to kv cache
        self._has_mamba = any(
            self._is_mamba_layer(layer_name) for layer_name in kv_caches
        )
        if self._has_mamba and self.mode == MoRIIOMode.WRITE:
            # WRITE needs a distinct conv/ssm transfer plan. Reject before
            # allocating or registering any regions rather than silently
            # serving a zero recurrent state.
            raise MoRIIOError(
                "MoRIIO hybrid (mamba/KDA) transfer is implemented for READ "
                "mode only; set kv_connector_extra_config.read_mode=true "
                "for hybrid models"
            )
        if self._has_mamba:
            mamba_specs = [
                cast(MambaSpec, self.layer_to_spec[layer_name])
                for layer_name in kv_caches
                if self._is_mamba_layer(layer_name)
            ]
            mamba_spec = _validate_mamba_specs(mamba_specs)
            assert mamba_spec is not None

            from vllm.model_executor.layers.mamba.mamba_utils import (
                is_conv_state_dim_first,
            )

            if not is_conv_state_dim_first():
                raise MoRIIOError(
                    "MoRIIO KDA conv transfer requires the DS (dim-first) "
                    "state layout; set VLLM_SSM_CONV_STATE_LAYOUT=DS"
                )
            self._conv_decomp = derive_mamba_conv_split(mamba_spec, self.world_size)
        # KDA layers use packed pages with different geometry; only record
        # attention tensor shapes here.
        self.kv_cache_shapes = {
            layer_name: kv_cache.shape
            for layer_name, kv_cache in kv_caches.items()
            if not self._is_mamba_layer(layer_name)
        }

        # Geometry selection must pick an attention layer (never a KDA tuple):
        # prefer a standard 5-D K/V layer, else the first attention layer.
        attn_items = [
            (layer_name, kv_cache)
            for layer_name, kv_cache in kv_caches.items()
            if not self._is_mamba_layer(layer_name)
        ]
        first_layer_name, first_kv_cache = next(
            (
                (layer_name, kv_cache)
                for layer_name, kv_cache in attn_items
                if (
                    not self._is_mla_cache_layer(layer_name)
                    and len(kv_cache.shape) == 5
                    and (kv_cache.shape[0] == 2 or kv_cache.shape[1] == 2)
                )
            ),
            attn_items[0] if attn_items else next(iter(kv_caches.items())),
        )
        kv_elem_size = first_kv_cache.element_size()

        use_mla = self._is_mla_cache_layer(first_layer_name)
        first_geometry = self._get_layer_transfer_geometry(first_layer_name)

        if use_mla:
            # MLA case.
            block_rank = 2  # [block_size, latent_dim]
            block_shape = first_kv_cache.shape[-block_rank:]
        else:
            # [2, num_blocks, ...] or [num_blocks, 2, ...]
            block_rank = 3  # [block_size, kv_heads, head_dim]
            block_shape = first_kv_cache.shape[-block_rank:]
        self.num_blocks = first_geometry.num_blocks
        self.slot_size_bytes = first_geometry.slot_size_bytes
        if first_geometry.block_size != self.block_size:
            # DeepSeek-V3 / MLA backends (e.g. FlashMLA) override the
            # configured block_size at attention-layer creation time, so
            # the KV cache tensor is laid out with a different (usually
            # larger) block_size than vllm_config.cache_config.block_size.
            # Trust the actual tensor shape and reconcile.
            logger.info(
                "KV cache block_size=%d differs from config block_size=%d; "
                "using actual tensor shape (attention backend override).",
                first_geometry.block_size,
                self.block_size,
            )
            self.block_size = first_geometry.block_size
        # block size in bytes
        self.block_len = first_geometry.block_len
        self.kv_cache_shape = first_kv_cache.shape
        self.block_shape = block_shape
        self.kv_element_size = kv_elem_size

        self.dst_num_blocks[self.engine_id] = self.num_blocks
        kv_caches_base_addr = []
        caches_data = []
        self.layer_base_addr_index = {}
        base_addr_idx = 0

        hma_enabled = (
            not self.vllm_config.scheduler_config.disable_hybrid_kv_cache_manager
        )
        for layer_name in kv_caches:
            self.layer_base_addr_index[layer_name] = base_addr_idx
            if self._is_mamba_layer(layer_name):
                # KDA layer: two whole-tensor regions (conv, ssm); no block-size
                # geometry (recurrent state is per-slot, not paged).
                for cache, region_len in self._iter_layer_registration_regions(
                    layer_name
                ):
                    base_addr = cache.data_ptr()
                    caches_data.append((base_addr, region_len, cache.device.index, ""))
                    kv_caches_base_addr.append(base_addr)
                    base_addr_idx += 1
                continue
            geometry = self._get_layer_transfer_geometry(layer_name)
            if hma_enabled:
                if geometry.block_len != self.block_len:
                    raise ValueError(
                        "MoRIIO KV cache block length mismatch for layer "
                        f"{layer_name}: {geometry.block_len} != {self.block_len}"
                    )
            elif geometry.block_size != self.block_size:
                raise ValueError(
                    "MoRIIO KV cache block size mismatch for layer "
                    f"{layer_name}: {geometry.block_size} != {self.block_size}"
                )
            # num_blocks is advertised as a single scalar to the peer, so must it
            # be uniform
            if geometry.num_blocks != self.num_blocks:
                raise ValueError(
                    "MoRIIO KV cache num_blocks mismatch for layer "
                    f"{layer_name}: {geometry.num_blocks} != {self.num_blocks}"
                )
            self.block_lens[layer_name] = geometry.block_len
            for cache, region_len in self._iter_layer_registration_regions(layer_name):
                base_addr = cache.data_ptr()
                caches_data.append((base_addr, region_len, cache.device.index, ""))
                kv_caches_base_addr.append(base_addr)
                base_addr_idx += 1

        shared_backing = (
            all(isinstance(t, torch.Tensor) for t in kv_caches.values())
            and len({id(t.untyped_storage()) for t in kv_caches.values()}) == 1
        )
        shared_mr = None
        if shared_backing:
            reg_tensor, self.kv_layer_mr_offset = self._build_shared_kv_mr(kv_caches)
            shared_mr = self.moriio_wrapper.register_local_tensor(reg_tensor)

        # Say it out loud when the groups disagree. This is expected on a hybrid
        # model and used to be fatal, so a run that silently had one page size
        # and a run that has three should not look identical in the log.
        distinct_block_lens = sorted(set(self.block_lens.values()))
        if len(distinct_block_lens) > 1:
            logger.info(
                "MoRIIO registered %d attention layers with %d distinct block "
                "lengths (bytes): %s; transfer sizes and strides are per layer, "
                "and %d is the page advertised to the peer.",
                len(self.block_lens),
                len(distinct_block_lens),
                distinct_block_lens,
                self.block_len,
            )

        for layer_name, kv_cache in kv_caches.items():
            if layer_name not in self.layer_name_to_local_kv_cache_metadata:
                self.layer_name_to_local_kv_cache_metadata[layer_name] = []

            if self._is_mamba_layer(layer_name):
                # Register conv and ssm as two whole-tensor regions, appending
                # both metadata blobs (order: conv then ssm) so the session
                # layout matches iter_layer_registration_regions. conv/ssm are
                # slot-strided views and are not contiguous, which
                # register_torch_tensor rejects; register a contiguous uint8
                # alias over each tensor's full byte extent instead (zero-copy:
                # same storage and data_ptr).
                conv, ssm = kda_conv_ssm(
                    kv_cache, cast(MambaSpec, self.layer_to_spec[layer_name])
                )
                logger.debug(
                    "MoRIIO KDA register %s: conv shape=%s stride=%s contig=%s "
                    "storage_nbytes=%s ; ssm shape=%s stride=%s contig=%s "
                    "storage_nbytes=%s",
                    layer_name,
                    tuple(conv.shape),
                    tuple(conv.stride()),
                    conv.is_contiguous(),
                    conv.untyped_storage().nbytes(),
                    tuple(ssm.shape),
                    tuple(ssm.stride()),
                    ssm.is_contiguous(),
                    ssm.untyped_storage().nbytes(),
                )
                for tensor in (conv, ssm):
                    alias = self._contiguous_byte_alias(tensor)
                    meta = self.moriio_wrapper.register_local_tensor(alias)
                    self.layer_name_to_local_kv_cache_metadata[layer_name].append(meta)
                    self.local_kv_cache_size.append(alias.numel())
            else:
                moriio_mem_metadata = shared_mr or (
                    self.moriio_wrapper.register_local_tensor(kv_cache)
                )
                self.layer_name_to_local_kv_cache_metadata[layer_name].append(
                    moriio_mem_metadata
                )
                self.local_kv_cache_size.append(
                    kv_cache.nelement() * kv_cache.element_size()
                )

        self.kv_caches_base_addr[self.engine_id] = kv_caches_base_addr
        self.num_regions = len(caches_data)
        self.num_layers = len(self.kv_caches.keys())

        # Report the prevalidated KDA decomposition after registration.
        if self._has_mamba:
            assert self._conv_decomp is not None
            logger.info(
                "MoRIIO registered %d KDA (conv+ssm) layer(s); ssm sizes=%s",
                sum(1 for ln in kv_caches if self._is_mamba_layer(ln)),
                self._conv_decomp.ssm_sizes,
            )
        # Optimization for models with local attention (Llama 4)
        if self.vllm_config.model_config.hf_config.model_type == "llama4":
            from transformers import Llama4TextConfig

            assert isinstance(
                self.vllm_config.model_config.hf_text_config, Llama4TextConfig
            )
            llama4_config = self.vllm_config.model_config.hf_text_config
            no_rope_layers = llama4_config.no_rope_layers
            chunk_size = llama4_config.attention_chunk_size
            chunk_block_size = math.ceil(chunk_size / self.block_size)
            for layer_idx in range(self.num_layers):
                # no_rope_layers[layer_idx] == 0 means NoPE (global)
                # Any other value means RoPE (local chunked)
                is_local_attention = no_rope_layers[layer_idx] != 0
                block_window = chunk_block_size if is_local_attention else None
                self.block_window_per_layer.append(block_window)
            logger.debug(
                "Llama 4 block window per layer mapping: %s",
                self.block_window_per_layer,
            )
            assert len(self.block_window_per_layer) == self.num_layers

        metadata = MoRIIOAgentMetadata(
            engine_id=self.engine_id,
            agent_metadata=self.moriio_wrapper.get_agent_metadata(),
            kv_caches_base_addr=self.kv_caches_base_addr[self.engine_id],
            num_blocks=self.num_blocks,
            block_len=self.block_len,
            attn_backend_name=self.backend_name,
        )
        ready_event = threading.Event()
        self._moriio_handshake_listener_t = threading.Thread(
            target=self._moriio_handshake_listener,
            args=(
                metadata,
                ready_event,
                self.side_channel_port,
                self.tp_rank,
                self.dp_rank,
                self.layer_name_to_local_kv_cache_metadata,
            ),
            daemon=True,
            name="moriio_handshake_listener",
        )
        self._moriio_handshake_listener_t.start()
        ready_event.wait()  # Wait for listener ZMQ socket to be ready.
        self.moriio_wrapper.async_wait_reqid()

    def get_finished(self) -> tuple[set[str], set[str]]:
        """Get requests that are done sending or recving on this specific worker.
        The scheduler process (via the MultiprocExecutor) will use this output
        to track which workers are done.
        """
        heartbeat = getattr(self, "_heartbeat", None)
        if heartbeat is not None:
            heartbeat.check_health()
        done_sending, done_recving = set(), set()

        if self.is_producer:
            # pop_finished_req_ids returns release ACKs sent by decode. Keep
            # duplicate ACKs because heterogeneous TP can fan multiple decode
            # ranks into one prefill rank for the same transfer_id.
            # Combine freshly-arrived ACKs with any buffered from prior ticks
            # whose transfer_id wasn't mapped yet (notify raced ahead of
            # start_load_kv); retry the lookup every tick. Buffered before
            # resolve_moriio_transfer_ack so each ACK is counted exactly once.
            finished_acks = self._pending_unmapped_acks + list(
                self.moriio_wrapper.pop_finished_req_ids()
            )
            self._pending_unmapped_acks = []
            resolved_transfer_ids: set[TransferId] = set()
            for ack in finished_acks:
                transfer_id = ack if isinstance(ack, str) else ack.transfer_id
                if transfer_id not in self.transfer_id_to_request_id:
                    # Mapping not populated yet -- buffer and retry next tick,
                    # do NOT drop (dropping leaks producer KV at high conc and
                    # wedges the prefill).
                    self._pending_unmapped_acks.append(ack)
                    continue
                resolved_transfer_id = resolve_moriio_transfer_ack(
                    ack,
                    producer_tp_size=self.world_size,
                    live_transfer_ids=self.transfer_id_to_request_id.keys(),
                    notification_counts=self._consumer_notification_counts,
                    completed_transfer_ids=(self._completed_consumer_notifications),
                )
                if resolved_transfer_id is not None:
                    resolved_transfer_ids.add(resolved_transfer_id)
            done_sending = {
                self.transfer_id_to_request_id[xfer_id]
                for xfer_id in resolved_transfer_ids
            }
        else:
            if self.mode == MoRIIOMode.WRITE:
                fresh = self.moriio_wrapper.pop_finished_write_req_ids()
                # Accumulate with any completions that arrived before their
                # transfer_id was registered in transfer_id_to_request_id.
                self._unmatched_write_completions |= fresh
                done_recving = self._unmatched_write_completions
            else:
                # READ mode: the scheduler treats KV loads as synchronous
                # (load_kv_async=False), so requests go directly to RUNNING
                # instead of WAITING_FOR_REMOTE_KVS. We still call
                # _pop_done_transfers() to send the notify to the prefill
                # side and clean up internal state, but we must NOT report
                # these as done_recving because the scheduler doesn't
                # expect a finished_recving signal for RUNNING requests.
                self._pop_done_transfers()

        done_recving = {
            self.transfer_id_to_request_id[id]
            for id in filter(
                lambda id: id in self.transfer_id_to_request_id, done_recving
            )
        }
        if self.mode == MoRIIOMode.WRITE and not self.is_producer:
            # Remove the ones we successfully matched; leave unmatched for retry.
            matched_xfer_ids = {
                id
                for id in self._unmatched_write_completions
                if id in self.transfer_id_to_request_id
            }
            self._unmatched_write_completions -= matched_xfer_ids

        return done_sending, done_recving

    def wait_for_layer_load(self, layer_name: str) -> None:
        """Block until all in-flight READs of this layer have landed.

        A host-side blocking wait must not run during full-graph capture.
        """
        if self.is_producer or self.mode != MoRIIOMode.READ:
            return

        if get_forward_context().cudagraph_runtime_mode == CUDAGraphMode.FULL:
            return

        with self.moriio_wrapper.lock:
            pending = [
                status
                for status_by_layer in self._recving_transfers.values()
                for status in status_by_layer.get(layer_name, ())
            ]

        if not pending:
            return

        try:
            self.moriio_wrapper.waiting_for_transfer_complete(pending)
        except TransferError:
            if self._has_mamba:
                logger.exception(
                    "MoRIIO hybrid READ failed before layer %s; aborting the "
                    "forward because HMA load-error recovery is unsupported.",
                    layer_name,
                )
                raise
            logger.warning(
                "MoRIIO READ barrier did not complete for layer %s; proceeding "
                "to transfer cleanup.",
                layer_name,
                exc_info=True,
            )

    def _pop_done_transfers(self) -> set[str]:
        done_req_ids: set[str] = set()
        _xfer_timeout = self.moriio_config.recv_abort_timeout
        with self.moriio_wrapper.lock:
            to_remove = []
            for req_id, status_by_layer in self._recving_transfers.items():
                # Every layer's read must land before the request is complete,
                # so the whole batch is polled rather than just the newest
                # status.
                statuses = [
                    status
                    for layer_statuses in status_by_layer.values()
                    for status in layer_statuses
                ]
                state = self.moriio_wrapper.poll_transfer_batch(statuses)
                if statuses and state is TransferBatchState.DONE:
                    host, port, xfer_id = self._recving_transfers_callback_addr[req_id]
                    done_req_ids.add(xfer_id)
                    self.moriio_wrapper.send_notify(
                        xfer_id,
                        host,
                        port,
                        message_type="release",
                        message_fields={"consumer_tp_size": self.world_size},
                    )
                    to_remove.append(req_id)
                elif state is TransferBatchState.FAILED:
                    failed_status = next(
                        (status for status in statuses if status.Failed()), None
                    )
                    logger.error(
                        "RDMA transfer failed for request %s: %s (code=%s). "
                        "Notifying prefill to free blocks and recording the "
                        "load error where scheduler recovery is supported.",
                        req_id,
                        failed_status.Message() if failed_status else "unknown",
                        failed_status.Code() if failed_status else "unknown",
                    )
                    self._record_failed_recv(req_id)
                    host, port, xfer_id = self._recving_transfers_callback_addr[req_id]
                    try:
                        self.moriio_wrapper.send_notify(
                            xfer_id,
                            host,
                            port,
                            message_type="release",
                            message_fields={"consumer_tp_size": self.world_size},
                        )
                    except Exception:
                        logger.exception(
                            "Failed to send error notification for request %s",
                            req_id,
                        )
                    to_remove.append(req_id)
                    # Deliberately not in done_req_ids: the decode KV is
                    # incomplete, so this is a load error rather than a
                    # completion.
                elif req_id in self._recving_transfers_start:
                    # Abort still-in-flight transfers that exceed the
                    # configured deadline. Otherwise a lost RDMA
                    # completion would leave the decode worker hung
                    # indefinitely on this request.
                    _age = time.monotonic() - self._recving_transfers_start[req_id]
                    if _age > _xfer_timeout:
                        logger.error(
                            "RDMA read TIMED OUT for req %s after %.1fs "
                            "(kv_connector_extra_config.recv_abort_timeout=%.0f)",
                            req_id,
                            _age,
                            _xfer_timeout,
                        )
                        self._record_failed_recv(req_id)
                        to_remove.append(req_id)
            for req_id in to_remove:
                del self._recving_transfers[req_id]
                del self._recving_transfers_callback_addr[req_id]
                self._recving_transfers_start.pop(req_id, None)
                self._recving_local_blocks.pop(req_id, None)

            return done_req_ids

    def _await_reads_issued_this_step(self) -> None:
        """Step-level READ barrier, for the reads no per-layer barrier covers.

        load_kv_async=False promises the KV is in place before the forward runs.
        wait_for_layer_load keeps that promise per layer, letting early layers
        overlap later transfers, but it only fires for layers that go through
        the attention KV-transfer decorator. Two cases fall through it:

        * mamba/KDA layers have no such hook at all, so their conv+ssm reads
          would otherwise be consumed while still in flight;
        * under CUDAGraphMode.FULL a host-side blocking wait is illegal
          anywhere in the graph, so every read is awaited here instead.

        start_load_kv runs outside the graph, so blocking here is safe.
        Attention reads keep their per-layer overlap in the non-FULL case.

        Attention-only failures are reported via
        get_block_ids_with_load_errors. Hybrid failures are re-raised because
        the scheduler's recovery path does not support multiple cache groups;
        this fails the step closed instead of running forward with incomplete
        recurrent state.
        """
        all_statuses = self._reads_issued_this_step
        self._reads_issued_this_step = []
        mamba_statuses = self._mamba_reads_this_step
        self._mamba_reads_this_step = []
        if get_forward_context().cudagraph_runtime_mode == CUDAGraphMode.FULL:
            statuses = all_statuses
        else:
            statuses = mamba_statuses
        if not statuses:
            return
        try:
            self.moriio_wrapper.waiting_for_transfer_complete(statuses)
        except TransferError:
            if self._has_mamba:
                logger.exception(
                    "MoRIIO hybrid READ failed before the forward; aborting "
                    "because HMA load-error recovery is unsupported."
                )
                raise
            logger.exception(
                "MoRIIO reads did not complete before the forward; proceeding "
                "to transfer cleanup."
            )

    def _record_failed_recv(self, req_id: ReqId) -> None:
        """Hand a failed attention-only read to scheduler recovery.

        The scheduler's invalid-block recovery currently assumes exactly one
        KV cache group. Reporting IDs for a hybrid request would crash it while
        unpacking the request's groups, so match NIXL and keep HMA failures out
        of this API until scheduler recovery carries group identity.
        """
        if self._has_mamba:
            return
        self._invalid_block_ids.update(self._recving_local_blocks.get(req_id, ()))

    def get_block_ids_with_load_errors(self) -> set[int]:
        """Drain the blocks whose read failed, for the scheduler to recompute."""
        invalid, self._invalid_block_ids = self._invalid_block_ids, set()
        return invalid

    def save_kv_layer(
        self,
        metadata: MoRIIOConnectorMetadata,
        layer_name: str,
        kv_layer: torch.Tensor,
        attn_metadata: "AttentionMetadata | None",
        **kwargs,
    ):
        if not self.is_producer:
            return
        if self.mode == MoRIIOMode.READ:
            return
        remote_engine_id = None

        for req_id, meta in metadata.reqs_to_save.items():
            # we only need to check if dp0 in rank
            remote_engine_id = (
                str(meta.remote_host) + ":" + str(meta.remote_handshake_port)
            )

            meta.remote_engine_id = remote_engine_id

            dp0_remote_engine_id = self.get_engine_name_with_dp(remote_engine_id, 0)
            if dp0_remote_engine_id not in self._remote_agents:
                # Initiate handshake with remote engine to exchange metadata.
                with self._handshake_lock:
                    if remote_engine_id not in self._remote_agents:
                        self._background_moriio_handshake(
                            req_id, remote_engine_id, meta
                        )

                        continue
            self._write_blocks_for_req(req_id, meta, layer_name, kv_layer)

        if remote_engine_id is None:
            return
        _deadline = time.monotonic() + self.moriio_config.transfer_timeout
        while True:
            if (
                self._ready_requests.empty()
                and remote_engine_id not in self.write_ready_flags
            ):
                if time.monotonic() > _deadline:
                    logger.warning(
                        "Timed out waiting for write_ready_flags[%s]; "
                        "adjust with kv_connector_extra_config.transfer_timeout",
                        remote_engine_id,
                    )
                    break
                time.sleep(0.001)
                continue
            elif not self._ready_requests.empty() and (
                remote_engine_id in self.write_ready_flags
            ):
                self._write_blocks_for_req(
                    *self._ready_requests.get_nowait(), layer_name, kv_layer
                )
                break
            else:
                break

    def get_engine_name_with_dp(self, engine_name, dp_rank):
        return f"{engine_name}_dp{dp_rank}"

    def get_engine_name_with_dp_tp(self, engine_name, dp_rank, tp_rank):
        # Per-(dp, tp) session key. The flexible mirror read keys sessions per
        # (dp, tp) so one decode worker can hold a session to EACH prefill TP
        # rank and spread reads across them; other configs keep the DP-only key.
        return f"{engine_name}_dp{dp_rank}_tp{tp_rank}"

    def _eager_handshake_all_dp_ranks(self, metadata: MoRIIOConnectorMetadata) -> None:
        """Handshake EVERY remote prefill DP rank BEFORE the decode forward pass,
        identically across all local TP workers.

        Why this exists (the deadlock it prevents): with heterogeneous DP prefill
        a decode TP worker reads KV from whichever prefill DP rank owns the
        request, so across requests every worker must reach several prefill DP
        ranks. The decode forward issues per-layer TP collectives (e.g. an
        all-gather) that all local TP workers must enter together. If the
        handshakes are left to fire lazily on the read path, the workers diverge:
        a worker whose target rank is already cached races ahead into the forward
        collective while a peer is still blocked in a handshake recv(). The first
        worker then waits inside the collective for the stuck peer -> 600s NCCL
        timeout / hang. This was observed directly with mixed TP<->DP configs.

        Fix: complete ALL prefill-DP-rank handshakes for every referenced remote
        engine HERE, before any read enters the forward, so no worker is still
        handshaking once its peers reach a collective. Fires ONCE per remote
        engine (first contact), gated by _eager_handshaked_engines. The engine
        set comes from scheduler-built metadata (identical on every TP worker),
        so all workers run the same handshakes in the same order and reach the
        all-reduce barrier below together.

        Failure handling: handshake exceptions are caught, never raised before
        the collective (raising early would hang the peers still waiting for it).
        Every worker reaches the all-reduce(MIN) vote; if ANY worker failed, ALL
        raise the same error AFTER the collective, so the step fails fast and
        uniformly in ~seconds instead of one rank hanging the forward for 600s.
        """
        import torch.distributed as dist

        # Distinct remote engines referenced this step, in metadata (==
        # scheduler) order so every TP worker iterates engines identically.
        engines: dict[str, ReqMeta] = {}
        for _req_id, meta in metadata.reqs_to_recv.items():
            remote_engine_id = (
                str(meta.remote_host) + ":" + str(meta.remote_handshake_port)
            )
            engines.setdefault(remote_engine_id, meta)

        for remote_engine_id, meta in engines.items():
            if remote_engine_id in self._eager_handshaked_engines:
                continue

            remote_dp_size = int(meta.remote_dp_size)
            port = int(meta.remote_handshake_port)
            tp_size = int(meta.tp_size)

            # Flexible mirror (TP prefill + MLA, world_size==1 decode): the read
            # round-robins over prefill TP ranks, so pre-warm a session to EVERY
            # (dp, tp) rank. Other configs pre-warm per DP rank (tp resolved by
            # the fixed local-rank mapping) -- byte-identical to before. The
            # mirror's decode is DP+EP, whose forward all-to-all is the collective
            # that the eager barrier keeps everyone in step for.
            flexible = (
                self.world_size == 1
                and self.use_mla
                and remote_dp_size == 1
                and tp_size > 1
            )
            # (engine_id, dp_rank, tp_rank_or_None); tp_rank is None on the legacy
            # path so _moriio_handshake falls back to its _remote_tp_rank mapping.
            targets: list[tuple[Any, int, int | None]]
            if flexible:
                targets = [
                    (self.get_engine_name_with_dp_tp(remote_engine_id, dp, tp), dp, tp)
                    for dp in range(remote_dp_size)
                    for tp in range(max(1, tp_size))
                ]
            else:
                targets = [
                    (self.get_engine_name_with_dp(remote_engine_id, dp), dp, None)
                    for dp in range(remote_dp_size)
                ]

            # Submit handshakes for every not-yet-known target UNDER the lock; do
            # NOT hold it across the join or the collective (a stalled recv must
            # not block another thread's lock acquisition). Gate on BOTH
            # _remote_agents AND layer metadata: a rank with an agent entry but no
            # layer metadata is half-handshaked and would KeyError at read time.
            futures: list[tuple[str, Future[set[str]]]] = []
            with self._handshake_lock:
                for eid, cur_dp_rank, cur_tp_rank in targets:
                    if (
                        eid in self._remote_agents
                        and eid in self.layer_name_to_remote_kv_cache_metadata
                    ):
                        continue
                    fut = self._handshake_initiation_executor.submit(
                        self._moriio_handshake,
                        meta.remote_host,
                        port,
                        tp_size,
                        eid,
                        cur_dp_rank,
                        cur_tp_rank,
                    )
                    futures.append((eid, fut))

            # Join outside the lock. Bounded handshake errors are recorded here
            # and reported after the all-reduce.
            all_ok = True
            results: dict[str, set[str]] = {}
            for eid, fut in futures:
                try:
                    results[eid] = fut.result()
                except Exception:
                    logger.exception("Eager MoRIIO handshake failed for %s", eid)
                    all_ok = False

            with self._handshake_lock:
                for eid, agents in results.items():
                    self._remote_agents[eid] = agents

            logger.info(
                "Eager MoRIIO handshake: engine=%s dp_size=%d new_ranks=%d "
                "ok=%s tp_rank=%d",
                remote_engine_id,
                remote_dp_size,
                len(futures),
                all_ok,
                self.tp_rank,
            )
            # CPU all-reduce = TP-uniform success vote AND lockstep barrier: it
            # blocks until every TP worker arrives, gives them the same verdict,
            # and stays off the model compute stream.
            vote = torch.tensor([1 if all_ok else 0], device="cpu", dtype=torch.int32)
            dist.all_reduce(vote, group=self.tp_group.cpu_group, op=dist.ReduceOp.MIN)
            if int(vote.item()) == 0:
                raise HandshakeError(
                    f"Eager MoRIIO handshake failed for {remote_engine_id} on "
                    "at least one TP rank; failing this step fast to avoid a "
                    "TP collective hang"
                )

            self._eager_handshaked_engines.add(remote_engine_id)

    def start_load_kv(self, metadata: MoRIIOConnectorMetadata):
        """Start loading by triggering non-blocking moriio_xfer.
        We check for these trnxs to complete in each step().
        """
        self.transfer_id_to_request_id = metadata.transfer_id_to_request_id
        if self.is_producer:
            live_transfer_ids = set(self.transfer_id_to_request_id)
            self._consumer_notification_counts = {
                transfer_id: count
                for transfer_id, count in self._consumer_notification_counts.items()
                if transfer_id in live_transfer_ids
            }
            self._completed_consumer_notifications.intersection_update(
                live_transfer_ids
            )
            self.moriio_wrapper.async_wait_reqid()
            return
        if self.mode == MoRIIOMode.WRITE:
            return

        # Handshake every referenced remote prefill rank up front, before any
        # read enters the forward pass. A lazy per-rank handshake on the read
        # path lets TP workers diverge into a forward collective while a peer is
        # still blocked handshaking -> NCCL hang (see below).
        self._eager_handshake_all_dp_ranks(metadata)

        wait_handshake_readd_req = False
        remote_engine_id = None

        for req_id, meta in metadata.reqs_to_recv.items():
            remote_engine_id = (
                str(meta.remote_host) + ":" + str(meta.remote_handshake_port)
            )
            meta.remote_engine_id = remote_engine_id
            # The eager handshake above already covered every referenced engine
            # (and keys the mirror per (dp, tp), which the DP-only dp0 probe below
            # would miss). Only fall back to the lazy background handshake for an
            # engine it did not cover.
            dp0_remote_engine_id = self.get_engine_name_with_dp(remote_engine_id, 0)
            if (
                remote_engine_id not in self._eager_handshaked_engines
                and dp0_remote_engine_id not in self._remote_agents
            ):
                # Initiate handshake with remote engine to exchange metadata.
                with self._handshake_lock:
                    if remote_engine_id not in self._remote_agents:
                        self._background_moriio_handshake(
                            req_id, remote_engine_id, meta
                        )
                        wait_handshake_readd_req = True

                        continue

            # Handshake already completed, start the read xfer.
            self._read_blocks_for_req(req_id, meta)
        # Start transfers for requests whose handshakes have now finished.

        if remote_engine_id is None and not wait_handshake_readd_req:
            self._await_reads_issued_this_step()
            return
        _deadline = time.monotonic() + self.moriio_config.transfer_timeout
        while True:
            if (
                self._ready_requests.empty()
                and remote_engine_id not in self.load_ready_flag
                and wait_handshake_readd_req
            ):
                if time.monotonic() > _deadline:
                    logger.warning(
                        "Timed out waiting for load_ready_flag[%s]; "
                        "adjust with kv_connector_extra_config.transfer_timeout",
                        remote_engine_id,
                    )
                    break
                time.sleep(0.001)
                continue
            elif (
                not self._ready_requests.empty()
                and remote_engine_id in self.load_ready_flag
            ):
                self._read_blocks_for_req(*self._ready_requests.get_nowait())
                break
            else:
                break

        self._await_reads_issued_this_step()
        self._reqs_to_send.update(metadata.reqs_to_send)

    def wait_for_save(self, metadata: MoRIIOConnectorMetadata):
        if self.mode == MoRIIOMode.WRITE and self.is_producer:
            for layer_name, kv_layer in self.kv_caches.items():
                self.save_kv_layer(metadata, layer_name, kv_layer, None)
            self._writer.seal_pending_transfers()

    def _next_flex_tp_rank(self, remote_tp_size: int) -> int:
        """Deterministic round-robin over prefill tp0..N-1 for the flexible read.

        Round-robin (not random): exactly uniform and testable, with the same
        prefill-NIC balancing. Seeded from this decode rank's dp_rank so
        concurrent decode DP ranks are phase-staggered -- at a given read index
        distinct decode ranks target distinct prefill TP ranks.
        """
        rr = getattr(self, "_flex_tp_rr", None)
        if rr is None:
            rr = int(getattr(self, "dp_rank", 0) or 0)
        self._flex_tp_rr = rr + 1
        return rr % remote_tp_size

    def _resolve_read_source(self, meta: ReqMeta) -> tuple[int, bool]:
        """Resolve (chosen_tp, flexible) for reading this request's KV.

        Flexible mirror (decode world_size==1 + MLA + pure-TP prefill): MLA
        replicates the latent KV across the prefill TP ranks, so any is a valid
        source; round-robin across them to spread RDMA/NIC load. Otherwise the
        source TP rank is fixed by the local-rank mapping (_remote_tp_rank) --
        forward DP8EP->TP8 -> tp0; symmetric TP -> tp_rank -- byte-identical to
        prior behaviour. chosen_tp is the single value threaded into the (dp, tp)
        session key, the handshake dial and the notify port, so all three address
        the SAME prefill rank (drift -> read one rank but notify another -> the
        read rank's prefill buffer is never freed).
        """
        remote_tp_size = int(meta.tp_size)
        flexible = (
            self.world_size == 1
            and self.use_mla
            and int(meta.remote_dp_size) == 1
            and remote_tp_size > 1
        )
        if flexible:
            chosen_tp = self._next_flex_tp_rank(remote_tp_size)
        else:
            chosen_tp = self._remote_tp_rank(remote_tp_size)
        return chosen_tp, flexible

    def _read_blocks_for_req(self, req_id: str, meta: ReqMeta):
        logger.debug(
            "Remote agent %s available, calling _read_blocks for req %s",
            meta.remote_engine_id,
            req_id,
        )
        chosen_tp, flexible = self._resolve_read_source(meta)
        self._read_blocks(
            request_id=req_id,
            transfer_id=meta.transfer_id,
            dst_engine_id=meta.remote_engine_id,
            local_block_ids=meta.local_block_ids,
            remote_block_ids=meta.remote_block_ids,
            remote_host=meta.remote_host,
            remote_notify_port=meta.remote_notify_port,
            remote_tp_size=meta.tp_size,
            remote_dp_rank=meta.remote_dp_rank,
            chosen_tp=chosen_tp,
            flexible=flexible,
        )

    def _write_blocks_for_req(self, req_id: ReqId, meta: ReqMeta, layer_name, kv_layer):
        # Compute per-request values to pass through the task (no shared state).
        # This avoids race conditions when concurrent requests target different
        # decode pods - each WriteTask carries its own routing info.
        hosts = (
            list(meta.multi_pod_hosts) if meta.multi_pod_hosts else [meta.remote_host]
        )
        dp_local = (
            int(meta.remote_dp_size_local)
            if meta.remote_dp_size_local
            else int(meta.remote_dp_size)
        )
        # WRITE does not support HMA, so unwrap blocks into flat lists.
        # remote_block_ids can itself be empty so need to be careful when unwrapping.
        local_block_ids = meta.local_block_ids[0]
        remote_block_ids = meta.remote_block_ids[0] if meta.remote_block_ids else []
        self.schedule_write_blocks(
            request_id=req_id,
            transfer_id=meta.transfer_id,
            dst_engine_id=meta.remote_engine_id,
            local_block_ids=local_block_ids,
            remote_block_ids=remote_block_ids,
            layer_name=layer_name,
            kv_layer=kv_layer,
            remote_notify_port=meta.remote_notify_port,
            remote_ip=meta.remote_host,
            multi_pod_hosts=hosts,
            remote_dp_size_local=dp_local,
        )

    def merge_contiguous_blocks(
        self,
        offsets_local: list[int],
        offsets_remote: list[int],
        sizes: list[int],
        assume_sorted: bool = False,
    ) -> tuple[list[int], list[int], list[int]]:
        n = len(offsets_local)
        if n == 0:
            return [], [], []
        if not (n == len(offsets_remote) == len(sizes)):
            raise ValueError("Input list lengths mismatch")
        local_arr = np.fromiter(offsets_local, dtype=np.int64, count=n)
        remote_arr = np.fromiter(offsets_remote, dtype=np.int64, count=n)
        sizes_arr = np.fromiter(sizes, dtype=np.int64, count=n)

        if assume_sorted:
            local_sorted = local_arr
            remote_sorted = remote_arr
            sizes_sorted = sizes_arr
        else:
            if np.all(local_arr[:-1] <= local_arr[1:]):
                local_sorted = local_arr
                remote_sorted = remote_arr
                sizes_sorted = sizes_arr
            else:
                sort_idx = np.argsort(local_arr, kind="stable")
                local_sorted = local_arr[sort_idx]
                remote_sorted = remote_arr[sort_idx]
                sizes_sorted = sizes_arr[sort_idx]

        if n == 1:
            return (
                [int(local_sorted[0])],
                [int(remote_sorted[0])],
                [int(sizes_sorted[0])],
            )

        diff_local = local_sorted[1:] - local_sorted[:-1]
        diff_remote = remote_sorted[1:] - remote_sorted[:-1]
        prev_size = sizes_sorted[:-1]

        contiguous = (diff_local == prev_size) & (diff_remote == prev_size)

        if not contiguous.any():
            return local_sorted.tolist(), remote_sorted.tolist(), sizes_sorted.tolist()

        if contiguous.all():
            total_size = int(sizes_sorted.sum())
            return [int(local_sorted[0])], [int(remote_sorted[0])], [total_size]

        break_positions = np.flatnonzero(~contiguous) + 1
        segment_starts = np.concatenate(([0], break_positions))
        segment_ends = np.concatenate((break_positions, [n]))

        seg_count = len(segment_starts)
        merged_local = [0] * seg_count
        merged_remote = [0] * seg_count
        merged_sizes = [0] * seg_count

        for si in range(seg_count):
            s = segment_starts[si]
            e = segment_ends[si]
            merged_local[si] = int(local_sorted[s])
            merged_remote[si] = int(remote_sorted[s])

            merged_sizes[si] = int(
                local_sorted[e - 1] + sizes_sorted[e - 1] - local_sorted[s]
            )

        return merged_local, merged_remote, merged_sizes

    def _compute_block_transfer_offsets(
        self,
        layer_name: str,
        local_block_ids: list[int],
        remote_block_ids: list[int],
        remote_moriio_meta: MoRIIOAgentMetadata,
        remote_tp_size: int | None = None,
        remote_engine_id: EngineId | None = None,
    ) -> tuple[list[int], list[int], list[int]]:
        """Compute transfer offsets for block data.

        Args:
            layer_name: Name of the layer to transfer
            local_block_ids: IDs of local blocks
            remote_block_ids: IDs of remote blocks
            remote_moriio_meta: Metadata of the remote MoRIIO agent
            remote_tp_size: Tensor parallel size of the remote engine. Falls
                back to the locally recorded value when None.
            remote_engine_id: Id of the remote engine the blocks live on.

        Returns:
            Tuple of (local_offsets, remote_offsets, transfer_sizes)

        """
        validate_moriio_heterogeneous_tp_kv_heads(
            local_tp_size=self.world_size,
            remote_tp_size=(
                remote_tp_size
                if remote_tp_size and remote_tp_size > 0
                else self.world_size
            ),
            total_num_kv_heads=self.model_config.get_total_num_kv_heads(),
            is_mla=self._is_mla_cache_layer(layer_name),
        )
        local, remote, sizes = compute_block_transfer_offsets(
            layer_name=layer_name,
            kv_cache=self.kv_caches[layer_name],
            layer_to_spec=self.layer_to_spec,
            local_block_ids=local_block_ids,
            remote_block_ids=remote_block_ids,
            remote_num_blocks=remote_moriio_meta.num_blocks,
            merge_fn=lambda local, remote, sizes: self.merge_contiguous_blocks(
                local, remote, sizes, assume_sorted=False
            ),
        )
        if self.kv_layer_mr_offset:
            local_off = self.kv_layer_mr_offset[layer_name]
            remote_off = self._remote_layer_mr_offset(
                layer_name, remote_moriio_meta, remote_engine_id
            )
            local = [x + local_off for x in local]
            remote = [x + remote_off for x in remote]
        return local, remote, sizes

    def _region_session_indices(self, layer_name: str) -> list[int]:
        """Flat session indices for a layer's registered regions.

        Sessions are built one per region in registration order (see
        _get_built_session), so an attention layer maps to a single index and a
        KDA layer to two indices ([conv, ssm]). Built once and cached.
        """
        if self._region_session_index is None:
            mapping: dict[str, list[int]] = {}
            idx = 0
            for ln, metas in self.layer_name_to_local_kv_cache_metadata.items():
                mapping[ln] = list(range(idx, idx + len(metas)))
                idx += len(metas)
            self._region_session_index = mapping
        return self._region_session_index[layer_name]

    def _mamba_tp_ratio(self, remote_tp_size: int | None) -> int:
        """Validate the homogeneous-TP KDA contract."""
        remote = self.world_size if remote_tp_size is None else remote_tp_size
        if remote != self.world_size:
            raise NotImplementedError(
                "heterogeneous-TP mamba/KDA transfer is not supported yet "
                f"(local_tp={self.world_size}, remote_tp={remote}); use equal "
                "prefill/decode TP for hybrid models"
            )
        return 1

    def _mamba_blocks_for_layer(
        self,
        layer_name: str,
        block_groups: BlockIds,
    ) -> list[int]:
        payload_index = self._mamba_payload_index_by_layer.get(layer_name)
        if payload_index is None or payload_index >= len(block_groups):
            raise MoRIIOError(
                f"KDA layer {layer_name} has no block group in the transfer payload"
            )
        return list(block_groups[payload_index])

    def _compute_mamba_transfer_offsets(
        self,
        layer_name: str,
        local_slots: list[int],
        remote_slots: list[int],
        remote_tp_size: int | None = None,
    ) -> tuple[list[int], list[int], list[int], int]:
        """Compute (local, remote, sizes, n_conv) for a KDA layer.

        Entries [:n_conv] address the conv region/session; entries [n_conv:]
        address the ssm region/session.
        """
        assert self._conv_decomp is not None, "KDA decomposition not derived"
        conv, ssm = kda_conv_ssm(
            self.kv_caches[layer_name],
            cast(MambaSpec, self.layer_to_spec[layer_name]),
        )
        tp_ratio = self._mamba_tp_ratio(remote_tp_size)
        # Cache the slot-independent geometry per layer; only the per-request
        # slot bases vary, and heterogeneous TP is rejected above.
        template = self._mamba_offset_templates.get(layer_name)
        if template is None:
            template = build_mamba_offset_template(
                conv,
                ssm,
                self._conv_decomp,
                tp_ratio,
            )
            self._mamba_offset_templates[layer_name] = template
        local_offs, remote_offs, sizes = apply_mamba_offset_template(
            template, local_slots, remote_slots
        )
        n_conv = compute_mamba_conv_split_count(local_slots, self._conv_decomp)
        return local_offs, remote_offs, sizes, n_conv

    def _post_mamba_reads(
        self,
        layer_name: str,
        sessions: list,
        region_sessions: list[int],
        local_slots: list[int],
        remote_slots: list[int],
        remote_tp_size: int,
        request_id: str,
        deadline: float,
    ) -> list:
        """Post one KDA layer's conv and ssm reads; return their statuses.

        The layer owns two registered regions, so the offset list is split at
        the conv/ssm boundary and each half goes to its own session. A half
        with nothing to move is skipped rather than posted empty.
        """
        local, remote, sizes, n_conv = self._compute_mamba_transfer_offsets(
            layer_name,
            local_slots,
            remote_slots,
            remote_tp_size=remote_tp_size,
        )
        statuses: list = []
        for sess_idx, sl in (
            (region_sessions[0], slice(0, n_conv)),
            (region_sessions[1], slice(n_conv, None)),
        ):
            region_sizes = sizes[sl]
            if not region_sizes:
                continue
            statuses.append(
                self._post_read_with_backoff(
                    sessions[sess_idx],
                    region_sizes,
                    local[sl],
                    remote[sl],
                    request_id,
                    layer_name,
                    deadline,
                )
            )
        return statuses

    def _post_read_with_backoff(
        self,
        session,
        sizes: list[int],
        local_offsets: list[int],
        remote_offsets: list[int],
        request_id: str,
        layer_name: str,
        deadline: float,
    ):
        """Post one RDMA READ, backing off on transient SQ-full rejection.

        read_remote_data posts synchronously, so a send-queue-full rejection is
        a Failed() status on return; a separate CQ-poll thread drains
        completions and frees SQ depth, so we back off and re-post until
        transfer_timeout, then store the failed status (get_finished notifies
        prefill and drops the request non-fatally).
        """
        _backoff = _SQ_FULL_BACKOFF_INITIAL_S
        while True:
            transfer_status = self.moriio_wrapper.read_remote_data(
                sizes, local_offsets, remote_offsets, session
            )
            if not self._is_sq_full_status(transfer_status):
                break
            if time.monotonic() > deadline:
                logger.warning(
                    "MoRIIO READ send queue stayed full past "
                    "transfer_timeout for req %s layer %s; storing failed "
                    "status (get_finished notifies prefill and drops the "
                    "request). Raise qp_per_transfer if frequent.",
                    request_id,
                    layer_name,
                )
                break
            time.sleep(_backoff)
            _backoff = min(_backoff * 2, _SQ_FULL_BACKOFF_MAX_S)
        return transfer_status

    @staticmethod
    def _is_sq_full_status(status) -> bool:
        """True if a MoRIIO transfer status is a transient RDMA send-queue-full
        rejection (retryable backpressure), not a terminal failure.

        read_remote_data posts the RDMA READ synchronously (the mori executor
        joins its worker before returning and marks the status on the calling
        thread), so a send-queue-full rejection is a Failed() status the moment
        the call returns. mori surfaces it as a generic ERR_RDMA_OP carrying
        "SQ full" in the message (no distinct code), so we match the message.
        Only meaningful once status.Failed() is True.
        """
        try:
            return bool(status.Failed()) and "SQ full" in (status.Message() or "")
        except Exception:
            return False

    def _read_blocks(
        self,
        local_block_ids: BlockIds,
        remote_block_ids: BlockIds,
        dst_engine_id: str,
        request_id: str,
        transfer_id: str,
        remote_host: str,
        remote_notify_port: int,
        remote_tp_size: int,
        remote_dp_rank: int = 0,
        chosen_tp: int | None = None,
        flexible: bool = False,
    ) -> None:
        if self.mode == MoRIIOMode.WRITE:
            return

        # Read from the prefill rank that actually computed this request's KV
        # (forwarded by the proxy). Hardcoding DP0 reads from a different rank's
        # memory registration; per-rank num_blocks differ, so high block ids can
        # overrun the wrong rank's region.
        #
        # eff_tp = the remote TP rank this read targets. The flexible mirror
        # reads from a round-robin-chosen prefill TP rank and keys the session
        # per (dp, tp); other configs use the fixed local-rank mapping (eff_tp ==
        # _remote_tp_rank), byte-identical to before. This key MUST match the one
        # the eager handshake stored the session under.
        eff_tp = (
            int(chosen_tp)
            if chosen_tp is not None
            else self._remote_tp_rank(remote_tp_size)
        )
        if not any(local_block_ids):
            # A request aborted before decode allocation still carries the
            # producer's block table. There is no local destination or forward,
            # so release the producer blocks without building sessions or
            # posting RDMA reads.
            self.moriio_wrapper.send_notify(
                transfer_id,
                remote_host,
                str(
                    remote_notify_port
                    + get_port_offset(
                        int(remote_dp_rank),
                        eff_tp,
                        remote_tp_size,
                    )
                ),
                message_type="release",
                message_fields={"consumer_tp_size": self.world_size},
            )
            return

        if self._has_mamba:
            expected_groups = 1 + self._num_mamba_transfer_groups
            if (
                len(local_block_ids) != expected_groups
                or len(remote_block_ids) != expected_groups
            ):
                raise MoRIIOError(
                    "MoRIIO hybrid READ block group count mismatch: "
                    f"expected={expected_groups}, local={len(local_block_ids)}, "
                    f"remote={len(remote_block_ids)}"
                )
            local_attn = list(local_block_ids[0])
            remote_attn = list(remote_block_ids[0])
            self._mamba_tp_ratio(remote_tp_size)
        else:
            local_attn = remote_attn = []

        if flexible:
            remote_dp_engine_id = self.get_engine_name_with_dp_tp(
                dst_engine_id, int(remote_dp_rank), eff_tp
            )
        else:
            remote_dp_engine_id = self.get_engine_name_with_dp(
                dst_engine_id, int(remote_dp_rank)
            )
        sessions, remote_moriio_meta = self._get_built_session(remote_dp_engine_id)

        # SQ-full backpressure deadline, shared across this request's layers.
        _sq_deadline = time.monotonic() + self.moriio_config.transfer_timeout
        # TODO: apply multi-session batch-read when MoRIIO supports it.
        for layer_name in self.layer_name_to_local_kv_cache_metadata:
            region_sessions = self._region_session_indices(layer_name)
            statuses = []
            if self._is_mamba_layer(layer_name):
                local_mamba = self._mamba_blocks_for_layer(layer_name, local_block_ids)
                remote_mamba = self._mamba_blocks_for_layer(
                    layer_name, remote_block_ids
                )
                # KDA layer: pull conv (sub-projection offsets) and ssm at the
                # request's recurrent-state slot. Two regions -> two sessions.
                if not local_mamba or not remote_mamba:
                    if not local_attn and not remote_attn:
                        # Whole-request no-op (e.g. full prefix cache hit):
                        # nothing to transfer for any layer.
                        continue
                    # A KDA layer must have its recurrent-state slot in the
                    # block-id tuple; missing it (while attention blocks are
                    # present) means the mamba KV-cache group is absent -> bug.
                    raise MoRIIOError(
                        f"KDA layer {layer_name}: missing mamba recurrent-state "
                        f"block ids (local={local_mamba}, remote={remote_mamba}) "
                        f"with attention blocks present for request {request_id}; "
                        "the mamba KV-cache group is absent from the transfer "
                        "block-id tuple"
                    )
                statuses = self._post_mamba_reads(
                    layer_name,
                    sessions,
                    region_sessions,
                    local_mamba,
                    remote_mamba,
                    remote_tp_size,
                    request_id,
                    _sq_deadline,
                )
            else:
                if self._has_mamba:
                    local_layer_blocks = local_attn
                    remote_layer_blocks = remote_attn
                else:
                    group_idx = self.layer_to_group[layer_name]
                    local_layer_blocks = local_block_ids[group_idx]
                    remote_layer_blocks = remote_block_ids[group_idx]
                offs = self._compute_block_transfer_offsets(
                    layer_name,
                    local_layer_blocks,
                    remote_layer_blocks,
                    remote_moriio_meta,
                    remote_tp_size=remote_tp_size,
                    remote_engine_id=remote_dp_engine_id,
                )
                statuses.append(
                    self._post_read_with_backoff(
                        sessions[region_sessions[0]],
                        offs[2],
                        offs[0],
                        offs[1],
                        request_id,
                        layer_name,
                        _sq_deadline,
                    )
                )
            with self.moriio_wrapper.lock:
                self._recving_transfers[request_id][layer_name] = statuses
                self._recving_transfers_start.setdefault(request_id, time.monotonic())
                # Destination blocks, kept for _record_failed_recv.
                if self._has_mamba:
                    failed_recv_blocks = local_attn
                else:
                    failed_recv_blocks = [
                        block_id for group in local_block_ids for block_id in group
                    ]
                self._recving_local_blocks.setdefault(
                    request_id, list(failed_recv_blocks)
                )
                # Awaited before the forward when the per-layer barrier cannot
                # run (see _await_reads_issued_this_step).
                self._reads_issued_this_step.extend(statuses)
                if self._is_mamba_layer(layer_name):
                    # No per-layer barrier exists for mamba layers, so these are
                    # always awaited in start_load_kv.
                    self._mamba_reads_this_step.extend(statuses)
                self._recving_transfers_callback_addr[request_id] = (
                    remote_host,
                    str(
                        remote_notify_port
                        + get_port_offset(
                            int(remote_dp_rank),
                            eff_tp,
                            remote_tp_size,
                        )
                    ),
                    transfer_id,
                )
