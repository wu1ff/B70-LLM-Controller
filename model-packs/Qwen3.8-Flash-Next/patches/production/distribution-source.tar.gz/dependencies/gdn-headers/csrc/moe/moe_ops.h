#pragma once

#include <torch/all.h>

void moe_sum(
    torch::Tensor& input,
    torch::Tensor& output,
    const std::optional<torch::Tensor>& topk_ids,
    const std::optional<torch::Tensor>& expert_map);

void moe_align_block_size(
    torch::Tensor topk_ids,
    int64_t num_experts,
    int64_t block_size,
    torch::Tensor sorted_token_ids,
    torch::Tensor experts_ids,
    torch::Tensor num_tokens_post_pad,
    std::optional<torch::Tensor> maybe_expert_map);

void batched_moe_align_block_size(
    int64_t max_tokens_per_batch,
    int64_t block_size,
    torch::Tensor const& expert_num_tokens,
    torch::Tensor sorted_ids,
    torch::Tensor expert_ids,
    torch::Tensor num_tokens_post_pad);

void moe_lora_align_block_size(
    torch::Tensor topk_ids,
    torch::Tensor token_lora_mapping,
    int64_t num_experts,
    int64_t block_size,
    int64_t max_loras,
    int64_t max_num_tokens_padded,
    int64_t max_num_m_blocks,
    torch::Tensor sorted_token_ids,
    torch::Tensor expert_ids,
    torch::Tensor num_tokens_post_pad,
    torch::Tensor adapter_enabled,
    torch::Tensor lora_ids,
    std::optional<torch::Tensor> maybe_expert_map);

std::tuple<torch::Tensor, torch::Tensor> grouped_topk(
    torch::Tensor const& scores,
    int64_t n_group,
    int64_t topk_group,
    int64_t topk,
    bool renormalize,
    double routed_scaling_factor,
    torch::Tensor const& bias,
    int64_t scoring_func);

void topk_softmax(
    torch::Tensor& topk_weights,
    torch::Tensor& topk_indices,
    torch::Tensor& token_expert_indices,
    torch::Tensor& gating_output,
    const bool renormalize,
    std::optional<torch::Tensor> bias,
    std::optional<torch::Tensor> is_padding);

void topk_sigmoid(
    torch::Tensor& topk_weights,
    torch::Tensor& topk_indices,
    torch::Tensor& token_expert_indices,
    torch::Tensor& gating_output,
    const bool renormalize,
    std::optional<torch::Tensor> bias,
    double routed_scaling_factor,
    std::optional<torch::Tensor> is_padding);

void topk_softplus_sqrt(
    torch::Tensor& topk_weights,
    torch::Tensor& topk_indices,
    torch::Tensor& token_expert_indices,
    torch::Tensor& gating_output,
    bool renormalize,
    double routed_scaling_factor,
    const c10::optional<torch::Tensor>& correction_bias,
    const c10::optional<torch::Tensor>& input_ids,
    const c10::optional<torch::Tensor>& tid2eid,
    const c10::optional<torch::Tensor>& is_padding,
    const c10::optional<torch::Tensor>& bias_vl,
    int64_t image_sentinel_lo);

void moe_gather(
    torch::Tensor& output,
    const torch::Tensor& moe_output,
    const torch::Tensor& topk_weights,
    const torch::Tensor& unpermuted_row_to_permuted_row,
    const int64_t num_experts);

void init_expert_map(
    torch::Tensor& expert_map,
    const int64_t num_experts,
    const int64_t ep_rank,
    const int64_t ep_size);

void remap_hidden_states(
    torch::Tensor& hidden_states,
    const c10::optional<torch::Tensor>& hidden_states_scales,
    torch::Tensor& remapped_hidden_states,
    const c10::optional<torch::Tensor>& remapped_hidden_states_scales,
    const c10::optional<torch::Tensor>& expert_map,
    torch::Tensor& rows_per_expert,
    torch::Tensor& unpermuted_row_to_permuted_row,
    torch::Tensor& topk_ids,
    int64_t total_experts_num,
    int64_t local_experts_num);

torch::Tensor reorder_mxfp_scales(
    const torch::Tensor& A_scales,
    const torch::Tensor& rows_per_expert,
    const int64_t total_padded_rows);
