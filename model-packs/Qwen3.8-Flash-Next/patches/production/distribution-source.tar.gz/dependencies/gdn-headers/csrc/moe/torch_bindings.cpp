#include "core/registration.h"
#include "moe_ops.h"

TORCH_LIBRARY_EXPAND(TORCH_EXTENSION_NAME, m) {
  // Calculate the result of moe by summing up the partial results
  // from all selected experts.
  m.def(
      "moe_sum(Tensor input, Tensor! output, Tensor? topk_ids, "
      "Tensor? expert_map) -> ()");
  m.impl("moe_sum", torch::kXPU, &moe_sum);

  // Aligning the number of tokens to be processed by each expert such
  // that it is divisible by the block size.
  m.def(
      "moe_align_block_size(Tensor topk_ids, int num_experts,"
      "                     int block_size, Tensor! sorted_token_ids,"
      "                     Tensor! experts_ids,"
      "                     Tensor! num_tokens_post_pad,"
      "                     Tensor? maybe_expert_map) -> ()");
  m.impl("moe_align_block_size", torch::kXPU, &moe_align_block_size);

  // Aligning the number of tokens to be processed by each expert such
  // that it is divisible by the block size, but for the batched case.
  m.def(
      "batched_moe_align_block_size(int max_tokens_per_batch,"
      "                     int block_size, Tensor expert_num_tokens,"
      "                     Tensor! sorted_token_ids,"
      "                     Tensor! experts_ids,"
      "                     Tensor! num_tokens_post_pad) -> ()");
  m.impl(
      "batched_moe_align_block_size",
      torch::kXPU,
      &batched_moe_align_block_size);

  // Aligning the number of tokens to be processed by each expert such
  // that it is divisible by the block size.
  m.def(
      "moe_lora_align_block_size(Tensor topk_ids,"
      "                     Tensor token_lora_mapping,"
      "                     int num_experts,"
      "                     int block_size, int max_loras, "
      "                     int max_num_tokens_padded, "
      "                     int max_num_m_blocks, "
      "                     Tensor! sorted_token_ids,"
      "                     Tensor! experts_ids,"
      "                     Tensor! num_tokens_post_pad,"
      "                     Tensor! adapter_enabled,"
      "                     Tensor! lora_ids,"
      "                     Tensor? maybe_expert_map) -> () ");
  m.impl("moe_lora_align_block_size", torch::kXPU, &moe_lora_align_block_size);

  // Apply fused grouped topk routing to select experts.
  // bias and scores may have different dtypes.
  // scoring_func: 0=none (softmax pre-applied), 1=sigmoid.
  // topk_values is always float32.
  m.def(
      "grouped_topk(Tensor scores, int n_group, int topk_group, "
      "int topk, bool renormalize, float routed_scaling_factor, "
      "Tensor bias, int scoring_func) -> (Tensor, Tensor)");
  m.impl("grouped_topk", torch::kXPU, &grouped_topk);
  // Apply topk softmax to the gating outputs.
  m.def(
      "topk_softmax(Tensor! topk_weights, Tensor! topk_indices, Tensor! "
      "token_expert_indices, Tensor gating_output, bool renormalize, Tensor? "
      "bias, Tensor? is_padding) -> ()");
  m.impl("topk_softmax", torch::kXPU, &topk_softmax);
  // Apply topk sigmoid to the gating outputs.
  m.def(
      "topk_sigmoid(Tensor! topk_weights, Tensor! topk_indices, Tensor! "
      "token_expert_indices, Tensor gating_output, bool renormalize, "
      "Tensor? bias, float routed_scaling_factor, Tensor? is_padding) -> ()");
  m.impl("topk_sigmoid", torch::kXPU, &topk_sigmoid);
  // Apply topk softplus sqrt to the gating outputs.
  m.def(
      "topk_softplus_sqrt(Tensor! topk_weights, Tensor! topk_indices, "
      "Tensor! token_expert_indices, Tensor gating_output, bool renormalize, "
      "float routed_scaling_factor, Tensor? correction_bias=None, Tensor? "
      "input_ids=None, Tensor? tid2eid=None, Tensor? is_padding=None, Tensor? "
      "bias_vl=None, int image_sentinel_lo=0) -> ()");
  m.impl("topk_softplus_sqrt", torch::kXPU, &topk_softplus_sqrt);
  // Apply topk softmax to the gating outputs.
  m.def(
      "moe_gather(Tensor! output, Tensor moe_output, Tensor topk_weights, "
      "Tensor unpermuted_row_to_permuted_row, "
      "int num_experts) -> ()");
  m.impl("moe_gather", torch::kXPU, &moe_gather);
  m.def(
      "init_expert_map(Tensor expert_map,"
      "int num_experts, "
      "int ep_rank, int ep_size) -> "
      "()");
  m.impl("init_expert_map", torch::kXPU, &init_expert_map);
  m.def(
      "remap_hidden_states(Tensor hidden_states, Tensor? hidden_states_scales, "
      "Tensor remapped_hidden_states,"
      "Tensor? remapped_hidden_states_scales,"
      "Tensor? expert_map, Tensor rows_per_expert,"
      "Tensor unpermuted_row_to_permuted_row, Tensor topk_ids,"
      "int total_experts_num, int "
      "local_experts_num) -> "
      "()");
  m.impl("remap_hidden_states", torch::kXPU, &remap_hidden_states);

  m.def(
      "reorder_mxfp_scales(Tensor A_scales, Tensor rows_per_expert, "
      "int total_padded_rows) -> Tensor");
  m.impl("reorder_mxfp_scales", torch::kXPU, &reorder_mxfp_scales);
}

REGISTER_EXTENSION(TORCH_EXTENSION_NAME)
