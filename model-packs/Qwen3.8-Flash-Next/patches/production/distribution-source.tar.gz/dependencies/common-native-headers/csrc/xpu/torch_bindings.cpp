#include "core/registration.h"
#include "xpu/ops.h"
#ifdef VLLM_XPU_ENABLE_XE2
  #include "xpu/gemv/fp8_gemv_interface.h"
#endif
#ifdef VLLM_MOE_ENABLED
  #include "xpu/grouped_gemm/grouped_gemm_interface.h"
  #include "xpu/grouped_gemm/moe_shared_fused_interface.h"
#endif
#include "xpu/lora/lora_ops.h"

#include <torch/library.h>
#include <torch/version.h>

TORCH_LIBRARY_EXPAND(TORCH_EXTENSION_NAME, xpu_ops) {
  at::Tag stride_tag = at::Tag::needs_fixed_stride_order;

  // fp8_gemm is exposed as two schemas sharing one C++ implementation:
  // a pure functional variant, and an explicit out-variant. Keeping the
  // mutable `out` out of the functional schema is required for
  // torch.compile: a `Tensor(a!)?` argument makes functionalization wrap
  // every call in `auto_functionalized`, which Inductor cannot decompose
  // for optional mutable tensors.
  xpu_ops.def(
      "fp8_gemm(Tensor A, Tensor B, ScalarType? out_dtype, Tensor? A_scale_, "
      "Tensor? B_scale_, Tensor? bias_) -> Tensor");
  xpu_ops.impl("fp8_gemm", torch::kXPU, &fp8_gemm);

  // Writes the result in place into `out` (whose shape and device must
  // already match A/B) and returns it.
  xpu_ops.def(
      "fp8_gemm_out(Tensor(a!) out, Tensor A, Tensor B, ScalarType? out_dtype, "
      "Tensor? A_scale_, Tensor? B_scale_, Tensor? bias_) -> Tensor");
  xpu_ops.impl("fp8_gemm_out", torch::kXPU, &fp8_gemm_out);

  xpu_ops.def(
      "fp8_bmm(Tensor A, Tensor B, ScalarType? out_dtype, Tensor? A_scale_, "
      "Tensor? B_scale_, Tensor? bias_) -> Tensor");
  xpu_ops.impl("fp8_bmm", torch::kXPU, &fp8_bmm);

  xpu_ops.def(
      "fp8_gemm_w8a16(Tensor A, Tensor B, Tensor? B_scale_, "
      "Tensor? bias_) -> Tensor");
  xpu_ops.impl("fp8_gemm_w8a16", torch::kXPU, &fp8_gemm_w8a16);

  // One-shot P2P custom all-reduce for tensor parallel = 2 (Level Zero IPC).
  xpu_ops.def("custom_ar_create(int max_bytes) -> int");
  xpu_ops.impl("custom_ar_create", &custom_ar_create);
  xpu_ops.def("custom_ar_export(int handle) -> int[]");
  xpu_ops.impl("custom_ar_export", &custom_ar_export);
  xpu_ops.def(
      "custom_ar_open(int handle, int rank, int[] peer, int mode_mask) -> int");
  xpu_ops.impl("custom_ar_open", &custom_ar_open);
  xpu_ops.def("custom_ar_all_reduce_(Tensor(a!) x, int handle) -> ()");
  xpu_ops.impl("custom_ar_all_reduce_", torch::kXPU, &custom_ar_all_reduce_);
  xpu_ops.def("custom_ar_error(int handle) -> int");
  xpu_ops.impl("custom_ar_error", &custom_ar_error);
  xpu_ops.def("custom_ar_destroy(int handle) -> ()");
  xpu_ops.impl("custom_ar_destroy", &custom_ar_destroy);
  xpu_ops.def("custom_ar_max_bytes_limit() -> int");
  xpu_ops.impl("custom_ar_max_bytes_limit", &custom_ar_max_bytes_limit);
#ifdef VLLM_XPU_ENABLE_XE2
  // Two fp8_gemm_w8a16 sharing A (e.g. GDN in_proj_qkvz + in_proj_ba): one
  // GEMV launch for single-row A, two oneDNN calls otherwise.
  xpu_ops.def(
      "fp8_gemm_w8a16_pair(Tensor A, Tensor B1, Tensor B1_scale, Tensor B2, "
      "Tensor B2_scale) -> (Tensor, Tensor)");
  xpu_ops.impl(
      "fp8_gemm_w8a16_pair", torch::kXPU, &vllm::fp8_gemv::fp8_gemm_w8a16_pair);
  // RMSNorm-prologue + fp8 linear fusions (one GEMV launch for decode rows,
  // unfused norm + fp8_gemm_w8a16 otherwise).
  xpu_ops.def(
      "gated_rmsnorm_fp8_gemm(Tensor x, Tensor z, Tensor norm_weight, "
      "float eps, Tensor B, Tensor B_scale) -> Tensor");
  xpu_ops.impl(
      "gated_rmsnorm_fp8_gemm",
      torch::kXPU,
      &vllm::fp8_gemv::gated_rmsnorm_fp8_gemm);
  xpu_ops.def(
      "resadd_rmsnorm_fp8_gemm(Tensor x, Tensor residual, Tensor "
      "norm_weight, float eps, Tensor B, Tensor B_scale) -> (Tensor, Tensor)");
  xpu_ops.impl(
      "resadd_rmsnorm_fp8_gemm",
      torch::kXPU,
      &vllm::fp8_gemv::resadd_rmsnorm_fp8_gemm);
  xpu_ops.def(
      "resadd_rmsnorm_fp8_gemm_pair(Tensor x, Tensor residual, Tensor "
      "norm_weight, float eps, Tensor B1, Tensor B1_scale, Tensor B2, Tensor "
      "B2_scale) -> (Tensor, Tensor, Tensor)");
  xpu_ops.impl(
      "resadd_rmsnorm_fp8_gemm_pair",
      torch::kXPU,
      &vllm::fp8_gemv::resadd_rmsnorm_fp8_gemm_pair);
#endif

  xpu_ops.def(
      "fp4_gemm(Tensor A, Tensor B, Tensor A_scale, Tensor B_scale, "
      "ScalarType? out_dtype, Tensor? bias_) -> Tensor");
  xpu_ops.impl("fp4_gemm", torch::kXPU, &fp4_gemm);

  xpu_ops.def(
      "int4_gemm_w4a16(Tensor A, Tensor B, Tensor? bias, Tensor B_scale, "
      "Tensor B_zp, int group_size, Tensor? g_idx) -> Tensor");
  xpu_ops.impl("int4_gemm_w4a16", torch::kXPU, &int4_gemm_w4a16);

  xpu_ops.def(
      "int4_gemm_w4a8(Tensor A_, Tensor A_scale, Tensor A_zp, Tensor B, "
      "Tensor B_scale, Tensor B_zp, int group_size, Tensor? g_idx, Tensor? "
      "bias) -> Tensor");
  xpu_ops.impl("int4_gemm_w4a8", torch::kXPU, &int4_gemm_w4a8);

#ifdef VLLM_MOE_ENABLED
  xpu_ops.def(
      "cutlass_grouped_gemm_interface(Tensor ptr_A, Tensor? ptr_A_scale, "
      "Tensor ptr_B, Tensor? ptr_B_scale, Tensor? ptr_bias, Tensor ptr_D, "
      "Tensor rows_per_expert, int N, int K, int num_experts) -> Tensor");
  xpu_ops.impl(
      "cutlass_grouped_gemm_interface",
      torch::kXPU,
      &cutlass_grouped_gemm_interface);

  // Fused routed + shared-expert MoE for small-M decode (fp16 activations,
  // fp8-e4m3 per-tensor weights). tile_m = 0 selects the tile by M.
  xpu_ops.def(
      "moe_shared_fused_decode_interface(Tensor(a!) output, Tensor x, "
      "Tensor topk_ids, Tensor topk_weights, Tensor w13, Tensor w13_scale, "
      "Tensor w2, Tensor w2_scale, Tensor shared_w13, Tensor "
      "shared_w13_scale, Tensor shared_w2, Tensor shared_w2_scale, Tensor "
      "shared_gate, Tensor(b!) ws, int tile_m=0) -> ()");
  xpu_ops.impl(
      "moe_shared_fused_decode_interface",
      torch::kXPU,
      &moe_shared_fused_decode_interface);
#endif

  xpu_ops.def(
      "deepseek_scaling_rope(Tensor! positions, Tensor! query, Tensor! key, "
      "Tensor? offsets_opt, Tensor! cos_sin_cache, int rotary_dim, bool "
      "is_neox_style) "
      "-> (Tensor, Tensor)");
  xpu_ops.impl("deepseek_scaling_rope", torch::kXPU, &deepseek_scaling_rope);

  xpu_ops.def(
      "fused_kv_compress_norm_rope_insert_sparse_attn(Tensor state_cache, "
      "Tensor token_to_req_indices, "
      "Tensor positions, Tensor slot_mapping, Tensor block_table, "
      "Tensor rms_norm_weight, float rms_norm_eps, Tensor cos_sin_cache, "
      "Tensor! k_cache, Tensor kv_slot_mapping, int kv_cache_block_size, "
      "int compress_ratio, int overlap, int rope_head_dim, int token_stride, "
      "int scale_dim, int kv_block_stride) -> ()");
  xpu_ops.impl(
      "fused_kv_compress_norm_rope_insert_sparse_attn",
      torch::kXPU,
      &fused_kv_compress_norm_rope_insert_sparse_attn);

  // Multi-modal Rotary Embedding (M-RoPE) — used by e.g. Qwen2-VL.
  // positions has shape [num_mrope_sections, num_tokens]; mrope_section is
  // an int32 device tensor of length num_mrope_sections that partitions the
  // rotation dimensions across positional axes (e.g. time / height / width).
  xpu_ops.def(
      "multimodal_rotary_embedding(Tensor positions, Tensor! query,"
      "                            Tensor!? key, int head_size,"
      "                            Tensor cos_sin_cache, bool is_neox,"
      "                            int[] mrope_section) -> ()");
  xpu_ops.impl(
      "multimodal_rotary_embedding", torch::kXPU, &multimodal_rotary_embedding);

  // Apply rotary embedding taking cos/sin directly (flash_attn style).
  // For diffusion models where cos/sin are pre-computed externally.
  xpu_ops.def(
      "apply_rotary_emb(Tensor! output, Tensor input,"
      "                 Tensor cos, Tensor sin, bool is_neox) -> ()");
  xpu_ops.impl("apply_rotary_emb", torch::kXPU, &apply_rotary_emb);

  // DeepSeek-V4 fused Q-RMSNorm + GPT-J RoPE + KV cache insert.
  // kv_cache_dtype: "bf16" or "fp8_ds_mla"
  xpu_ops.def(
      "deepseek_qnorm_rope_kv_insert(Tensor! q, Tensor kv,"
      "                              Tensor! cache,"
      "                              Tensor slot_mapping,"
      "                              Tensor position_ids,"
      "                              Tensor cos_sin_cache,"
      "                              float eps, int block_size,"
      "                              str kv_cache_dtype) -> ()");
  xpu_ops.impl(
      "deepseek_qnorm_rope_kv_insert",
      torch::kXPU,
      &deepseek_qnorm_rope_kv_insert);

  // DeepSeek-V4 inverse RoPE (bf16): fused inv GPT-J rotation + group-major
  // layout transform.
  xpu_ops.def(
      "deepseek_inv_rope_bf16(Tensor attn_output, Tensor positions,"
      "                       Tensor cos_sin_cache, int n_groups,"
      "                       int heads_per_group, int nope_dim,"
      "                       int rope_dim) -> Tensor");
  xpu_ops.impl("deepseek_inv_rope_bf16", torch::kXPU, &deepseek_inv_rope_bf16);

  // DeepSeek-V4 fused inverse RoPE + FP8 quantization: inv GPT-J rotation +
  // per-128-block UE8M0 FP8 E4M3 quantization + group-major layout transform.
  xpu_ops.def(
      "deepseek_inv_rope_fp8_quant(Tensor attn_output, Tensor positions,"
      "                            Tensor cos_sin_cache, int n_groups,"
      "                            int heads_per_group, int nope_dim,"
      "                            int rope_dim) -> (Tensor, Tensor)");
  xpu_ops.impl(
      "deepseek_inv_rope_fp8_quant", torch::kXPU, &deepseek_inv_rope_fp8_quant);

#ifdef VLLM_MHC_ENABLED
  xpu_ops.def(
      "mhc_pre(Tensor residual, Tensor fn, Tensor hc_scale, Tensor hc_base,"
      "        float rms_eps, float hc_pre_eps, float hc_sinkhorn_eps,"
      "        float hc_post_mult_value, int sinkhorn_repeat)"
      "        -> (Tensor, Tensor, Tensor)");
  xpu_ops.impl("mhc_pre", torch::kXPU, &mhc_pre);

  xpu_ops.def(
      "mhc_post(Tensor x, Tensor residual, Tensor post_layer_mix,"
      "         Tensor comb_res_mix) -> Tensor");
  xpu_ops.impl("mhc_post", torch::kXPU, &mhc_post);

  xpu_ops.def(
      "hc_head_fused(Tensor hs_flat, Tensor fn, Tensor hc_scale,"
      "              Tensor hc_base, Tensor! out, float rms_eps,"
      "              float hc_eps) -> ()");
  xpu_ops.impl("hc_head_fused", torch::kXPU, &hc_head_fused);

  xpu_ops.def(
      "mhc_fused_post_pre(Tensor x, Tensor residual, Tensor post_layer_mix,"
      "                   Tensor comb_res_mix, Tensor fn, Tensor hc_scale,"
      "                   Tensor hc_base, float rms_eps, float hc_pre_eps,"
      "                   float hc_sinkhorn_eps, float hc_post_mult_value,"
      "                   int sinkhorn_repeat)"
      "                   -> (Tensor, Tensor, Tensor, Tensor)");
  xpu_ops.impl("mhc_fused_post_pre", torch::kXPU, &mhc_fused_post_pre);
#endif

  xpu_ops.def(
      "bgmv_shrink(Tensor! outputs, Tensor inputs, Tensor weights, Tensor "
      "indices, float scale) -> ()");
  xpu_ops.impl("bgmv_shrink", torch::kXPU, &bgmv_shrink);

  xpu_ops.def(
      "bgmv_expand(Tensor! outputs, Tensor inputs, Tensor weights, Tensor "
      "indices, bool add_to_output) -> ()");
  xpu_ops.impl("bgmv_expand", torch::kXPU, &bgmv_expand);

  xpu_ops.def(
      "bgmv_expand_slice(Tensor! outputs, Tensor inputs, Tensor weights, "
      "Tensor indices, int slice_offset, int slice_size, bool add_to_output) "
      "-> ()");
  xpu_ops.impl("bgmv_expand_slice", torch::kXPU, &bgmv_expand_slice);

  xpu_ops.def(
      "lora_shrink(Tensor inputs, Tensor[] lora_a_weights, "
      "Tensor! output_tensor, Tensor lora_indices, float scaling) -> ()");
  xpu_ops.impl("lora_shrink", torch::kXPU, &lora_shrink);

  xpu_ops.def(
      "lora_expand(Tensor inputs, Tensor[] lora_b_weights, "
      "Tensor! output_tensor, Tensor lora_indices, int offset_start, "
      "bool add_inputs) -> ()");
  xpu_ops.impl("lora_expand", torch::kXPU, &lora_expand);

#ifdef VLLM_GDN_ENABLED
  xpu_ops.def(
      "causal_conv1d_spec(Tensor! z, Tensor "
      "projected_states_qkvz, Tensor projected_states_ba,"
      "int num_k_heads, int num_v_heads, int head_k_dim, int head_v_dim,"
      "Tensor! conv_state, Tensor conv_weights, Tensor? "
      "conv_bias, str activation,"
      "int num_prefills, int num_decodes, int num_spec_decodes,"
      "Tensor spec_query_start_loc, Tensor spec_token_indx, "
      "Tensor spec_state_indices_tensor, Tensor num_accepted_tokens,"
      "int num_actual_tokens, int tp_size, bool reorder_input) -> Tensor[]");
  xpu_ops.impl("causal_conv1d_spec", torch::kXPU, &causal_conv1d_spec);

  xpu_ops.def(
      "causal_conv1d_non_spec(Tensor! z, Tensor "
      "projected_states_qkvz, Tensor projected_states_ba,"
      "int num_k_heads, int num_v_heads, int head_k_dim, int head_v_dim,"
      "Tensor! conv_state, Tensor conv_weights, Tensor? "
      "conv_bias, str activation,"
      "int num_prefills, int num_decodes, int num_spec_decodes, Tensor? "
      "has_initial_state, Tensor non_spec_query_start_loc, Tensor? "
      "non_spec_token_indx, Tensor non_spec_state_indices_tensor,"
      "int num_actual_tokens, int tp_size, bool reorder_input) -> Tensor[]");
  xpu_ops.impl("causal_conv1d_non_spec", torch::kXPU, &causal_conv1d_non_spec);

  xpu_ops.def(
      "gated_delta_rule_spec(Tensor! core_attn_out,"
      "Tensor q, Tensor k, Tensor v, Tensor b, Tensor a,"
      "int num_v_heads, int head_v_dim,"
      "Tensor A_log, Tensor dt_bias, Tensor! ssm_state,"
      "int num_prefills, int num_decodes, int num_spec_decodes,"
      "Tensor spec_query_start_loc, Tensor spec_token_indx, "
      "Tensor spec_state_indices_tensor, Tensor num_accepted_tokens,"
      "int num_actual_tokens, int tp_size) -> ()");
  xpu_ops.impl("gated_delta_rule_spec", torch::kXPU, &gated_delta_rule_spec);

  xpu_ops.def(
      "gated_delta_rule_non_spec(Tensor! core_attn_out,"
      "Tensor q, Tensor k, Tensor v, Tensor b, Tensor a,"
      "int num_v_heads, int head_v_dim,"
      "Tensor A_log, Tensor dt_bias, Tensor! ssm_state,"
      "int num_prefills, int num_decodes, int num_spec_decodes, Tensor? "
      "has_initial_state, Tensor non_spec_query_start_loc, Tensor? "
      "non_spec_token_indx, Tensor non_spec_state_indices_tensor,"
      "int num_actual_tokens, int tp_size) -> ()");
  xpu_ops.impl(
      "gated_delta_rule_non_spec", torch::kXPU, &gated_delta_rule_non_spec);

  xpu_ops.def(
      "gdn_attention(Tensor! core_attn_out, Tensor! z, Tensor "
      "projected_states_qkvz, Tensor projected_states_ba,"
      "int num_k_heads, int num_v_heads, int head_k_dim, int head_v_dim,"
      "Tensor! conv_state, Tensor! ssm_state, Tensor conv_weights, Tensor? "
      "conv_bias, str activation, Tensor A_log, Tensor dt_bias,"
      "int num_prefills, int num_decodes, int num_spec_decodes, Tensor? "
      "has_initial_state, Tensor? "
      "non_spec_query_start_loc,  Tensor? non_spec_token_indx,"
      "Tensor? non_spec_state_indices_tensor, Tensor? spec_query_start_loc, "
      "Tensor? spec_token_indx, Tensor? spec_state_indices_tensor, Tensor? "
      "num_accepted_tokens, int num_actual_tokens, int "
      "tp_size, bool reorder_input) -> ()");
  xpu_ops.impl("gdn_attention", torch::kXPU, &gdn_attention);
#endif

  // for empty tensor functions, we don't need dispatch key like torch::kXPU
  xpu_ops.def("is_bmg_g21(int device_index) -> bool");
  xpu_ops.impl("is_bmg_g21", &is_bmg_g21);

  xpu_ops.def("is_bmg_g31(int device_index) -> bool");
  xpu_ops.impl("is_bmg_g31", &is_bmg_g31);

  xpu_ops.def("is_bmg(int device_index) -> bool");
  xpu_ops.impl("is_bmg", &is_bmg);

  xpu_ops.def("is_pvc(int device_index) -> bool");
  xpu_ops.impl("is_pvc", &is_pvc);

  xpu_ops.def("is_xe2_arch(int device_index=-1) -> bool");
  xpu_ops.impl("is_xe2_arch", &is_xe2_arch);

  xpu_ops.def("is_xe3_arch(int device_index=-1) -> bool");
  xpu_ops.impl("is_xe3_arch", &is_xe3_arch);

  // test only, will not use in vllm
  xpu_ops.def(
      "exponential_2d_(Tensor! tensor, Tensor! seeds, float lambda) -> ()");
  xpu_ops.impl("exponential_2d_", torch::kXPU, &exponential_2d_);

  xpu_ops.def(
      "topk_topp_sampler(Tensor! random_sampled, Tensor? logits_to_return,"
      "Tensor! logits, Tensor? k, Tensor? p, str logprobs_mode, Tensor! seeds, "
      "float lambda) -> ()");
  xpu_ops.impl("topk_topp_sampler", torch::kXPU, &topk_topp_sampler);

#ifdef VLLM_MQA_LOGITS_ENABLED
  xpu_ops.def(
      "fp8_mqa_logits(Tensor q, Tensor kv, Tensor kv_scales, Tensor weights, "
      "Tensor cu_seqlen_ks, Tensor cu_seqlen_ke) -> Tensor");
  xpu_ops.impl("fp8_mqa_logits", torch::kXPU, &fp8_mqa_logits);

  xpu_ops.def(
      "fp8_paged_mqa_logits(Tensor q_fp8, Tensor kv_cache_fp8, Tensor "
      "weights, Tensor context_lens, Tensor block_tables, Tensor? "
      "schedule_metadata, int max_model_len) -> Tensor");
  xpu_ops.impl("fp8_paged_mqa_logits", torch::kXPU, &fp8_paged_mqa_logits);
#endif

  xpu_ops.def("get_onednn_version() -> str");
  xpu_ops.impl("get_onednn_version", &get_onednn_version);

  xpu_ops.def(
      "deepseek_fused_indexer_q_rope_fp8(Tensor q, Tensor positions, "
      "Tensor cos_sin_cache, Tensor index_weights, float softmax_scale, "
      "float head_scale, Tensor! q_fp8, Tensor! weights_out) -> ()");
  xpu_ops.impl(
      "deepseek_fused_indexer_q_rope_fp8",
      torch::kXPU,
      &deepseek_fused_indexer_q_rope_fp8);

  xpu_ops.def(
      "deepseek_fused_indexer_q_rope_mxfp4(Tensor q, Tensor positions, "
      "Tensor cos_sin_cache, Tensor index_weights, float softmax_scale, "
      "float head_scale, Tensor! packed_out, Tensor! scales_out, "
      "Tensor! weights_out) -> ()");
  xpu_ops.impl(
      "deepseek_fused_indexer_q_rope_mxfp4",
      torch::kXPU,
      &deepseek_fused_indexer_q_rope_mxfp4);

  xpu_ops.def(
      "fused_input_norm(Tensor! out, Tensor input, Tensor weight, "
      "Tensor bias) -> ()");
  xpu_ops.impl("fused_input_norm", torch::kXPU, &fused_input_norm);

  xpu_ops.def(
      "compact_sampling_mask(Tensor logits, Tensor num_sampled_tokens,"
      "int max_num_kept, int max_compact_support) -> (Tensor, Tensor, Tensor)");
  xpu_ops.impl("compact_sampling_mask", torch::kXPU, &compact_sampling_mask);

  // Split of a (gated) QKV projection + per-head q/k RMSNorm + NeoX (M)RoPE
  // [+ copy of the raw output gate]; v stays a view of qkv.
  xpu_ops.def(
      "qkv_split_norm_rope(Tensor qkv, Tensor positions, Tensor q_weight, "
      "Tensor k_weight, Tensor cos_sin_cache, Tensor! q_out, Tensor! k_out, "
      "Tensor!? gate_out, int num_q_heads, int num_kv_heads, int head_dim, "
      "int rotary_dim, float eps, float weight_offset, int[] mrope_section, "
      "bool mrope_interleaved) -> ()");
  xpu_ops.impl("qkv_split_norm_rope", torch::kXPU, &qkv_split_norm_rope);
}

REGISTER_EXTENSION(TORCH_EXTENSION_NAME)
