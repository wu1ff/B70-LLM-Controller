/***************************************************************************************************
 * Copyright (c) 2025 Intel Corporation. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 *LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
/*! \file
    \brief CUTLASS Intel BMG MoE API example based on sycl-tla Group GEMM

*/
#include <torch/all.h>
#include "csrc/utils.h"

#include <cute/tensor.hpp>
#include <random>

#include <cute/util/compat.hpp>
#include <sycl/ext/intel/experimental/grf_size_properties.hpp>
#include <sycl/sycl.hpp>

#include <cute/tensor.hpp>

#include "cutlass/kernel_hardware_info.h"
#include "cutlass/platform/platform.h"
#include "cutlass/tensor_ref.h"
#include "cutlass/util/GPU_Clock.hpp"
#include "cutlass/util/device_memory.h"
#include "cutlass/util/reference/device/gemm_complex.h"
#include "cutlass/util/reference/device/tensor_compare.h"
#include "cutlass/util/reference/host/tensor_fill.h"

#include "gemm_xe2_policy.hpp"
#include "grouped_gemm_xe2.hpp"

#pragma clang diagnostic ignored "-Wpass-failed"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

namespace MoE {
using namespace cute;

// type tag to define a unique sycl kernel name
template <
    typename,
    typename,
    typename,
    typename,
    char,
    char,
    class,
    A_DTYPE,
    B_DTYPE>
class GemmCuteName;

template <
    char layoutA,
    char layoutB,
    class policy,
    A_DTYPE TENSOR_A_DTYPE,
    B_DTYPE TENSOR_B_DTYPE,
    typename ElementA,
    typename ElementB,
    typename ElementS,
    typename ElementBI,
    typename ElementD>
void MoEGEMMLauncher(
    sycl::queue& stream,
    const ElementA* activations,
    const ElementB* weights,
    const ElementS* scales,
    const ElementBI* bias,
    ElementD* outputs,
    const int gemm_n,
    const int gemm_k,
    const int* rows_per_expert,
    const int num_experts,
    const int group_size,
    int32_t* atomic_buffer) {
  using ElementA_non_CV = cutlass::platform::remove_cv_t<ElementA>;
  auto op = XE_DPAS_TT<8, float, ElementA_non_CV>{};

  using WGTile = typename policy::WGTile;
  using SGLayout = typename policy::SGLayout;
  using MMA = typename TiledMMAHelper<
      MMA_Atom<decltype(op)>,
      Layout<WGTile>,
      SGLayout>::TiledMMA;
  auto mma = MMA{};

  int sm_count =
      cutlass::KernelHardwareInfo::query_device_multiprocessor_count(0);
  auto MaxThreadsPerWorkgroup = size(mma);

  static constexpr int MaxThreadsPerSM = 512;

  TORCH_CHECK(
      MaxThreadsPerSM % MaxThreadsPerWorkgroup == 0,
      "MaxThreadsPerSM must be divisible by MaxThreadsPerWorkgroup")

  sycl::range<3> local(1, 1, MaxThreadsPerWorkgroup);
  sycl::range<3> global(
      1, sm_count * MaxThreadsPerSM / MaxThreadsPerWorkgroup, 1);

  namespace syclex = sycl::ext::oneapi::experimental;
  namespace intelex = sycl::ext::intel::experimental;

  syclex::properties kernel_props{
      syclex::sub_group_size<16>, intelex::grf_size<256>};

  using GmemTiledCopyA = typename policy::GmemTiledCopyA;
  using GmemTiledCopyB = typename policy::GmemTiledCopyB;
  using GmemTiledCopyD = typename policy::GmemTiledCopyD;

  stream.submit([&](sycl::handler& cgh) {
    sycl::local_accessor<int32_t, 1> local_mem(sycl::range<1>(1), cgh);
    cgh.parallel_for<GemmCuteName<
        ElementA,
        ElementB,
        ElementS,
        ElementD,
        layoutA,
        layoutB,
        policy,
        TENSOR_A_DTYPE,
        TENSOR_B_DTYPE>>(
        sycl::nd_range<3>{global * local, local}, kernel_props, [=](auto) {
          MoE::MoEGEMM<
              TENSOR_A_DTYPE,
              TENSOR_B_DTYPE,
              GmemTiledCopyA,
              GmemTiledCopyB,
              GmemTiledCopyD,
              layoutA,
              layoutB,
              'R'>(
              activations,
              weights,
              scales,
              bias,
              outputs,
              mma,
              rows_per_expert,
              num_experts,
              group_size,
              gemm_n,
              gemm_k,
              atomic_buffer,
              local_mem);
        });
  });
}

at::Tensor cutlass_grouped_gemm_xe2_impl(
    at::Tensor& ptr_A,
    at::Tensor& ptr_B,
    const c10::optional<at::Tensor>& ptr_scales,
    const c10::optional<at::Tensor>& ptr_bias,
    at::Tensor& ptr_D,
    at::Tensor& rows_per_expert,
    int64_t N,
    int64_t K,
    int64_t num_experts) {
  auto& dpcpp_queue =
      at::xpu::getCurrentXPUStream(ptr_A.device().index()).queue();
  auto A_dtype = ptr_A.dtype();
  auto B_dtype = ptr_B.dtype();
  bool is_weight_fp8 =
      ((B_dtype == at::kFloat8_e4m3fn) || (B_dtype == at::kFloat8_e5m2));
  bool is_B_int4 = (B_dtype == at::kChar) && ptr_scales.has_value();
  bool is_B_mxfp4 =
      (B_dtype == at::kFloat4_e2m1fn_x2) && ptr_scales.has_value();
  // MXFP8: FP8 weights + E8M0 (uint8 / float8_e8m0fnu) block scales, gs=32.
  bool is_B_mxfp8 = false;
  if (is_weight_fp8 && ptr_scales.has_value() && ptr_scales->dim() == 3) {
    auto sd = ptr_scales->dtype();
    is_B_mxfp8 = (sd == at::kByte) || (sd == at::kFloat8_e8m0fnu);
  }
  // Block-FP8: FP8 weights + float32 2D scales [E, K/128, N/128].
  bool is_B_block_fp8 = false;
  if (is_weight_fp8 && ptr_scales.has_value() && ptr_scales->dim() == 3 &&
      !is_B_mxfp8) {
    is_B_block_fp8 = (ptr_scales->dtype() == at::kFloat);
  }

  TORCH_CHECK(N % 8 == 0, "N must be divisible by 8");

  TORCH_CHECK(ptr_A.dim() == 2, "ptr_A must be 2D [Total_M, K]");
  TORCH_CHECK(ptr_B.dim() == 3, "ptr_B must be 3D [num_experts, K, N]");
  TORCH_CHECK(ptr_D.dim() == 2, "ptr_D must be 2D [Total_M, N]");
  if (ptr_bias.has_value()) {
    TORCH_CHECK(ptr_bias->dim() == 2, "ptr_bias must be 2D [num_experts, N]");
  }

  TORCH_CHECK(ptr_A.is_contiguous(), "ptr_A must be contiguous");
  TORCH_CHECK(ptr_B.is_contiguous(), "ptr_B must be contiguous");
  TORCH_CHECK(ptr_D.is_contiguous(), "ptr_D must be contiguous");
  if (ptr_bias.has_value()) {
    TORCH_CHECK(ptr_bias->is_contiguous(), "ptr_bias must be contiguous");
  }

  int A_total_M = ptr_A.size(0);
  int A_K = ptr_A.size(1);

  int B_E = ptr_B.size(0);
  int B_K = ptr_B.size(1);
  int B_N = ptr_B.size(2);
  if (is_B_int4 || is_B_mxfp4) {
    B_K = ptr_B.size(2) * 2;
    B_N = ptr_B.size(1);
  }

  int D_total_M = ptr_D.size(0);
  int D_N = ptr_D.size(1);
  int group_size = -1;
  int A_avg_M = A_total_M / num_experts;

  TORCH_CHECK(B_E == num_experts, "ptr_B.size(0) must match num_experts");
  TORCH_CHECK(A_total_M == D_total_M, "ptr_A.size(0) must match ptr_D.size(0)");
  TORCH_CHECK(A_K == B_K && B_K == K, "ptr_A.size(1) must match ptr_B.size(1)");
  TORCH_CHECK(B_N == D_N && D_N == N, "ptr_B.size(2) must match ptr_D.size(1)");
  if (ptr_bias.has_value()) {
    TORCH_CHECK(
        ptr_bias->size(0) == num_experts,
        "ptr_bias.size(0) must match num_experts");
    TORCH_CHECK(ptr_bias->size(1) == N, "ptr_bias.size(1) must match N");
  }

  // Must be zeroed before kernel launch. Workgroup execution order
  // is non-deterministic, so initializing in the definition is the most
  // safe place to avoid any race condition as well as garbage data
  at::Tensor atomic_buffer =
      at::zeros({static_cast<long>(1)}, ptr_A.options().dtype(at::kInt));

#define MoEGEMMLauncherCallER(                                                 \
    LayoutA,                                                                   \
    LayoutB,                                                                   \
    Policy,                                                                    \
    TENSOR_A_DTYPE,                                                            \
    TENSOR_B_DTYPE,                                                            \
    ElementA,                                                                  \
    ElementB,                                                                  \
    ElementS)                                                                  \
  MoEGEMMLauncher<LayoutA, LayoutB, Policy, TENSOR_A_DTYPE, TENSOR_B_DTYPE>(   \
      dpcpp_queue,                                                             \
      reinterpret_cast<ElementA*>(ptr_A.data_ptr()),                           \
      reinterpret_cast<ElementB*>(ptr_B.data_ptr()),                           \
      ptr_scales.has_value()                                                   \
          ? reinterpret_cast<ElementS*>(ptr_scales->data_ptr())                \
          : static_cast<ElementS*>(nullptr),                                   \
      ptr_bias.has_value() ? reinterpret_cast<ElementA*>(ptr_bias->data_ptr()) \
                           : static_cast<ElementA*>(nullptr),                  \
      reinterpret_cast<ElementA*>(ptr_D.data_ptr()),                           \
      N,                                                                       \
      K,                                                                       \
      reinterpret_cast<int*>(rows_per_expert.data_ptr()),                      \
      num_experts,                                                             \
      group_size,                                                              \
      static_cast<int*>(atomic_buffer.data_ptr()));

  if (is_B_int4 || is_B_mxfp4) {
    TORCH_CHECK(ptr_scales.has_value(), "w8a16 grouped gemm must have scales");
    TORCH_CHECK(ptr_scales->is_contiguous(), "ptr_scales must be contiguous");
    TORCH_CHECK(
        ptr_scales->dim() == 3,
        "ptr_scales of int4 must be 3D [num_experts, group_num, N]");
    TORCH_CHECK(
        ptr_scales->size(0) == num_experts,
        "ptr_scales.size(0) of int4 must match num_experts");
    TORCH_CHECK(
        K % ptr_scales->size(2) == 0,
        "ptr_scales.size(2) of int4 must be divisible by K");
    TORCH_CHECK(
        ptr_scales->size(1) == N, "ptr_scales.size(1) of int4 must match N");
    int group_num = ptr_scales->size(2);
    group_size = K / group_num;

    TORCH_CHECK(
        group_size == 32 || group_size == 64 || group_size == 128 ||
            group_size == 256,
        "group_size must be 32, 64, 128 or 256");

#define W4A16LauncherCallER(policy)    \
  if (is_B_int4) {                     \
    if (A_dtype == at::kBFloat16) {    \
      using scalar_t = bfloat16_t;     \
      MoEGEMMLauncherCallER(           \
          'R',                         \
          'C',                         \
          policy,                      \
          A_DTYPE::BITS16,             \
          B_DTYPE::INT4,               \
          scalar_t,                    \
          uint8_t,                     \
          scalar_t);                   \
    } else if (A_dtype == at::kHalf) { \
      using scalar_t = half_t;         \
      MoEGEMMLauncherCallER(           \
          'R',                         \
          'C',                         \
          policy,                      \
          A_DTYPE::BITS16,             \
          B_DTYPE::INT4,               \
          scalar_t,                    \
          uint8_t,                     \
          scalar_t);                   \
    }                                  \
  } else if (is_B_mxfp4) {             \
    if (A_dtype == at::kBFloat16) {    \
      using scalar_t = bfloat16_t;     \
      MoEGEMMLauncherCallER(           \
          'R',                         \
          'C',                         \
          policy,                      \
          A_DTYPE::BITS16,             \
          B_DTYPE::MXFP4,              \
          scalar_t,                    \
          uint8_t,                     \
          uint8_t);                    \
    } else if (A_dtype == at::kHalf) { \
      using scalar_t = half_t;         \
      MoEGEMMLauncherCallER(           \
          'R',                         \
          'C',                         \
          policy,                      \
          A_DTYPE::BITS16,             \
          B_DTYPE::MXFP4,              \
          scalar_t,                    \
          uint8_t,                     \
          uint8_t);                    \
    }                                  \
  }

    if (A_avg_M <= 4) {
      using policy = w4a16_policy_m_8;
      W4A16LauncherCallER(policy);
    } else if (A_avg_M <= 8) {
      using policy = w4a16_policy_m_16;
      W4A16LauncherCallER(policy);
    } else if (A_avg_M <= 128) {
      using policy = w4a16_policy_m_32;
      W4A16LauncherCallER(policy);
    } else {
      using policy = w4a16_policy;
      W4A16LauncherCallER(policy);
    }
#undef W4A16LauncherCallER
  } else if (is_B_mxfp8) {
    TORCH_CHECK(ptr_scales.has_value(), "mxfp8 grouped gemm must have scales");
    TORCH_CHECK(ptr_scales->is_contiguous(), "ptr_scales must be contiguous");
    TORCH_CHECK(
        ptr_scales->dim() == 3,
        "ptr_scales of mxfp8 must be 3D [num_experts, K/32, N] "
        "or [num_experts, N, K/32]");
    TORCH_CHECK(
        ptr_scales->size(0) == num_experts,
        "ptr_scales.size(0) of mxfp8 must match num_experts");
    TORCH_CHECK(K % 32 == 0, "mxfp8 requires K divisible by 32");

    // Canonical kernel layout is [E, N, K/32] (same indexing as mxfp4 E8M0).
    // Accept [E, K/32, N] from moe_utils / vLLM and transpose once on host.
    at::Tensor scales_nk = *ptr_scales;
    if (scales_nk.scalar_type() == at::kFloat8_e8m0fnu) {
      scales_nk = scales_nk.view(at::kByte);
    }
    if (scales_nk.size(1) == (K / 32) && scales_nk.size(2) == N) {
      scales_nk = scales_nk.transpose(1, 2).contiguous();
    }
    TORCH_CHECK(
        scales_nk.size(1) == N && scales_nk.size(2) == (K / 32),
        "mxfp8 scales must be [E, N, K/32] after layout normalize; got [",
        scales_nk.size(0),
        ", ",
        scales_nk.size(1),
        ", ",
        scales_nk.size(2),
        "] with N=",
        N,
        " K=",
        K);
    group_size = 32;

    // Rebind ptr_scales for the launcher macro below.
    // MoEGEMMLauncherCallER reads ptr_scales->data_ptr().
    c10::optional<at::Tensor> scales_opt = scales_nk;
    const c10::optional<at::Tensor>& ptr_scales_mx = scales_opt;
#undef MoEGEMMLauncherCallER
#define MoEGEMMLauncherCallER(                                                 \
    LayoutA,                                                                   \
    LayoutB,                                                                   \
    Policy,                                                                    \
    TENSOR_A_DTYPE,                                                            \
    TENSOR_B_DTYPE,                                                            \
    ElementA,                                                                  \
    ElementB,                                                                  \
    ElementS)                                                                  \
  MoEGEMMLauncher<LayoutA, LayoutB, Policy, TENSOR_A_DTYPE, TENSOR_B_DTYPE>(   \
      dpcpp_queue,                                                             \
      reinterpret_cast<ElementA*>(ptr_A.data_ptr()),                           \
      reinterpret_cast<ElementB*>(ptr_B.data_ptr()),                           \
      ptr_scales_mx.has_value()                                                \
          ? reinterpret_cast<ElementS*>(ptr_scales_mx->data_ptr())             \
          : static_cast<ElementS*>(nullptr),                                   \
      ptr_bias.has_value() ? reinterpret_cast<ElementA*>(ptr_bias->data_ptr()) \
                           : static_cast<ElementA*>(nullptr),                  \
      reinterpret_cast<ElementA*>(ptr_D.data_ptr()),                           \
      N,                                                                       \
      K,                                                                       \
      reinterpret_cast<int*>(rows_per_expert.data_ptr()),                      \
      num_experts,                                                             \
      group_size,                                                              \
      static_cast<int*>(atomic_buffer.data_ptr()));

#define W8MXFP8LauncherCallER(policy)                                     \
  if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kHalf) {            \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::MXFP8,                                                   \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        uint8_t);                                                         \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kHalf) {       \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::MXFP8,                                                   \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        uint8_t);                                                         \
  } else if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kBFloat16) { \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::MXFP8,                                                   \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        uint8_t);                                                         \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kBFloat16) {   \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::MXFP8,                                                   \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        uint8_t);                                                         \
  } else {                                                                \
    TORCH_CHECK(                                                          \
        false,                                                            \
        "mxfp8 grouped gemm requires A in {fp16,bf16} and B in "          \
        "{float8_e4m3fn, float8_e5m2}");                                  \
  }

    if (A_avg_M <= 8) {
      using policy = w8a16_policy_m_16;
      W8MXFP8LauncherCallER(policy);
    } else if (A_avg_M <= 32) {
      using policy = w8a16_policy_m_32;
      W8MXFP8LauncherCallER(policy);
    } else {
      using policy = w8a16_policy;
      W8MXFP8LauncherCallER(policy);
    }
#undef W8MXFP8LauncherCallER
// Restore the default launcher macro for subsequent branches.
#undef MoEGEMMLauncherCallER
#define MoEGEMMLauncherCallER(                                                 \
    LayoutA,                                                                   \
    LayoutB,                                                                   \
    Policy,                                                                    \
    TENSOR_A_DTYPE,                                                            \
    TENSOR_B_DTYPE,                                                            \
    ElementA,                                                                  \
    ElementB,                                                                  \
    ElementS)                                                                  \
  MoEGEMMLauncher<LayoutA, LayoutB, Policy, TENSOR_A_DTYPE, TENSOR_B_DTYPE>(   \
      dpcpp_queue,                                                             \
      reinterpret_cast<ElementA*>(ptr_A.data_ptr()),                           \
      reinterpret_cast<ElementB*>(ptr_B.data_ptr()),                           \
      ptr_scales.has_value()                                                   \
          ? reinterpret_cast<ElementS*>(ptr_scales->data_ptr())                \
          : static_cast<ElementS*>(nullptr),                                   \
      ptr_bias.has_value() ? reinterpret_cast<ElementA*>(ptr_bias->data_ptr()) \
                           : static_cast<ElementA*>(nullptr),                  \
      reinterpret_cast<ElementA*>(ptr_D.data_ptr()),                           \
      N,                                                                       \
      K,                                                                       \
      reinterpret_cast<int*>(rows_per_expert.data_ptr()),                      \
      num_experts,                                                             \
      group_size,                                                              \
      static_cast<int*>(atomic_buffer.data_ptr()));
  } else if (is_B_block_fp8) {
    TORCH_CHECK(
        ptr_scales.has_value(), "block-fp8 grouped gemm must have scales");
    TORCH_CHECK(ptr_scales->is_contiguous(), "ptr_scales must be contiguous");
    TORCH_CHECK(
        ptr_scales->dim() == 3,
        "ptr_scales of block-fp8 must be 3D [num_experts, K/128, N/128]");
    TORCH_CHECK(
        ptr_scales->size(0) == num_experts,
        "ptr_scales.size(0) of block-fp8 must match num_experts");
    TORCH_CHECK(K % 128 == 0, "block-fp8 requires K divisible by 128");
    TORCH_CHECK(N % 128 == 0, "block-fp8 requires N divisible by 128");
    TORCH_CHECK(
        ptr_scales->size(1) == (K / 128) && ptr_scales->size(2) == (N / 128),
        "block-fp8 scales must be [E, K/128, N/128]; got [",
        ptr_scales->size(0),
        ", ",
        ptr_scales->size(1),
        ", ",
        ptr_scales->size(2),
        "] with N=",
        N,
        " K=",
        K);
    TORCH_CHECK(
        ptr_scales->dtype() == at::kFloat, "block-fp8 scales must be float32");
    group_size = 128;

#define W8BLOCKFP8LauncherCallER(policy)                                  \
  if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kHalf) {            \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::BLOCK_FP8,                                               \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kHalf) {       \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::BLOCK_FP8,                                               \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kBFloat16) { \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::BLOCK_FP8,                                               \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kBFloat16) {   \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::BLOCK_FP8,                                               \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        float);                                                           \
  } else {                                                                \
    TORCH_CHECK(                                                          \
        false,                                                            \
        "block-fp8 grouped gemm requires A in {fp16,bf16} and B in "      \
        "{float8_e4m3fn, float8_e5m2}");                                  \
  }

    if (A_avg_M <= 8) {
      using policy = w8a16_policy_m_16;
      W8BLOCKFP8LauncherCallER(policy);
    } else if (A_avg_M <= 32) {
      using policy = w8a16_policy_m_32;
      W8BLOCKFP8LauncherCallER(policy);
    } else {
      using policy = w8a16_policy;
      W8BLOCKFP8LauncherCallER(policy);
    }
#undef W8BLOCKFP8LauncherCallER
  } else if (is_weight_fp8) {
    TORCH_CHECK(ptr_scales.has_value(), "w8a16 grouped gemm must have scales");
    TORCH_CHECK(ptr_scales->is_contiguous(), "ptr_scales must be contiguous");
    TORCH_CHECK(
        ptr_scales->dim() == 1, "ptr_scales of fp8 must be 1D [num_experts]");
    TORCH_CHECK(
        ptr_scales->size(0) == num_experts,
        "ptr_scales.size(0) of fp8 must match num_experts");
    TORCH_CHECK(ptr_scales->dtype() == at::kFloat, "ptr_scales must be float");

#define W8A16LauncherCallER(policy)                                       \
  if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kHalf) {            \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::PER_TENSOR_FP8,                                          \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kHalf) {       \
    using scalar_t = half_t;                                              \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::PER_TENSOR_FP8,                                          \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e4m3fn && A_dtype == at::kBFloat16) { \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::PER_TENSOR_FP8,                                          \
        scalar_t,                                                         \
        float_e4m3_t,                                                     \
        float);                                                           \
  } else if (B_dtype == at::kFloat8_e5m2 && A_dtype == at::kBFloat16) {   \
    using scalar_t = bfloat16_t;                                          \
    MoEGEMMLauncherCallER(                                                \
        'R',                                                              \
        'R',                                                              \
        policy,                                                           \
        A_DTYPE::BITS16,                                                  \
        B_DTYPE::PER_TENSOR_FP8,                                          \
        scalar_t,                                                         \
        float_e5m2_t,                                                     \
        float);                                                           \
  }

    if (A_avg_M <= 8) {
      using policy = w8a16_policy_m_16;
      W8A16LauncherCallER(policy);
    } else if (A_avg_M <= 32) {
      using policy = w8a16_policy_m_32;
      W8A16LauncherCallER(policy);
    } else {
      using policy = w8a16_policy;
      W8A16LauncherCallER(policy);
    }
#undef W8A16LauncherCallER
  } else {
    TORCH_CHECK(
        !ptr_scales.has_value(), "w16a16 grouped gemm must not have scales");

#define W16A16LauncherCallER(policy) \
  if (A_dtype == at::kBFloat16) {    \
    using scalar_t = bfloat16_t;     \
    MoEGEMMLauncherCallER(           \
        'R',                         \
        'R',                         \
        policy,                      \
        A_DTYPE::BITS16,             \
        B_DTYPE::BITS16,             \
        scalar_t,                    \
        scalar_t,                    \
        scalar_t);                   \
  } else if (A_dtype == at::kHalf) { \
    using scalar_t = half_t;         \
    MoEGEMMLauncherCallER(           \
        'R',                         \
        'R',                         \
        policy,                      \
        A_DTYPE::BITS16,             \
        B_DTYPE::BITS16,             \
        scalar_t,                    \
        scalar_t,                    \
        scalar_t);                   \
  }

    if (A_avg_M <= 8) {
      using policy = w16a16_policy_m_16;
      W16A16LauncherCallER(policy);
    } else if (A_avg_M <= 16) {
      using policy = w16a16_policy_m_32;
      W16A16LauncherCallER(policy);
    } else {
      if (B_N <= 64) {
        using policy = w16a16_policy_n_64;
        W16A16LauncherCallER(policy);
      } else if (B_N <= 512) {
        using policy = w16a16_policy_n_128;
        W16A16LauncherCallER(policy);
      } else {
        using policy = w16a16_policy;
        W16A16LauncherCallER(policy);
      }
    }
#undef W16A16LauncherCallER
  }
#undef MoEGEMMLauncherCallER
  return ptr_D;
}
}  // namespace MoE
