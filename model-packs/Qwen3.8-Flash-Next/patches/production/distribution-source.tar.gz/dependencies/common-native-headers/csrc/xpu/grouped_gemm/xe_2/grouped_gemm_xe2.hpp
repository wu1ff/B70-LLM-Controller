/***************************************************************************************************
 * Copyright 2025 Intel corporation. All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 *LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/
#pragma once

#include "cute/tensor.hpp"
#include "cutlass/cutlass.h"
#include "cutlass/gemm/gemm.h"
#include "cutlass/gemm/group_array_problem_shape.hpp"
#include "cutlass/gemm/kernel/tile_scheduler.hpp"
#include "cutlass/kernel_hardware_info.hpp"
#include "cutlass/platform/platform.h"
#include "gemm_xe2.hpp"
#include <cute/util/compat.hpp>

#pragma clang diagnostic ignored "-Wpass-failed"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

namespace MoE {
using namespace cute;

template <typename T, char LayoutKind>
CUTE_DEVICE auto make_moe_tensor(T* ptr, int r, int c) {
  auto shape = make_shape(r, c);
  if constexpr (LayoutKind == 'C')
    return make_tensor(
        make_gmem_ptr(ptr), make_layout(shape, make_stride(_1{}, r)));
  else
    return make_tensor(
        make_gmem_ptr(ptr), make_layout(shape, make_stride(c, _1{})));
}

template <
    A_DTYPE TENSOR_A_DTYPE,
    B_DTYPE TENSOR_B_DTYPE,
    class GmemTiledCopyA,
    class GmemTiledCopyB,
    class GmemTiledCopyD,
    char LayoutKindA,
    char LayoutKindB,
    char LayoutKindD,
    class TiledMMA,
    typename ElementA,
    typename ElementB,
    typename ElementS,
    typename ElementBI,
    typename ElementD>
CUTE_DEVICE void MoEGEMM(
    const ElementA* Activations,
    const ElementB* Weights,
    const ElementS* Scales,
    const ElementBI* Bias,
    ElementD* Outputs,
    TiledMMA const& mma,
    const int* rows_per_expert,
    const int32_t num_experts,
    const int32_t group_size,
    const int32_t gemm_n,
    const int32_t gemm_k,
    int32_t* atomic_buffer,
    const sycl::local_accessor<int32_t, 1>& slm_mem_const) {
  constexpr char actual_layout_of_B = LayoutKindB ^ ('R' ^ 'C');
  static constexpr bool is_B_4bits =
      (TENSOR_B_DTYPE == B_DTYPE::INT4 || TENSOR_B_DTYPE == B_DTYPE::MXFP4);

  auto item = sycl::ext::oneapi::this_work_item::get_nd_item<3>();
  auto wg_tile = mma.tile_mnk();
  auto wg_tile_m = get<0>(wg_tile);
  auto wg_tile_n = get<1>(wg_tile);

  int group_id = item.get_group_linear_id();
  int gemm_n_pad = (gemm_n + wg_tile_n - 1) / wg_tile_n * wg_tile_n;
  int group_m_id = (group_id * wg_tile_n) / gemm_n_pad;
  int group_range = item.get_group_range(1);
  int local_id = item.get_local_linear_id();

  int pre_rows = 0;
  int pre_tiles = 0;

  int32_t* slm_mem = static_cast<int32_t*>(
      slm_mem_const.template get_multi_ptr<sycl::access::decorated::no>()
          .get());

  for (int i = 0; i < num_experts; ++i) {
    int gemm_m = rows_per_expert[i];
    int cumsum_rows_for_experts = pre_rows + gemm_m;
    int cumsum_tiles_for_experts =
        (gemm_m + wg_tile_m - 1) / wg_tile_m + pre_tiles;

    if (group_m_id >= cumsum_tiles_for_experts) {
      pre_rows = cumsum_rows_for_experts;
      pre_tiles = cumsum_tiles_for_experts;
      continue;
    }

    int expert_id = i;
    int64_t B_offset = static_cast<int64_t>(expert_id) *
                       static_cast<int64_t>(gemm_n) *
                       static_cast<int64_t>(gemm_k);
    if constexpr (is_B_4bits) {
      B_offset /= 2;
    }
    ElementA* ptr_A_curr_batch =
        const_cast<ElementA*>(Activations) + pre_rows * gemm_k;
    ElementB* ptr_B_curr_batch = const_cast<ElementB*>(Weights) + B_offset;
    ElementD* ptr_D_curr_batch = Outputs + pre_rows * gemm_n;
    ElementS* ptr_Scales_curr_batch = const_cast<ElementS*>(Scales) + expert_id;
    if constexpr (is_B_4bits) {
      // Scales layout [E, N, K/group_size] packed with 4-bit B.
      ptr_Scales_curr_batch =
          const_cast<ElementS*>(Scales) + B_offset * 2 / group_size;
    } else if constexpr (TENSOR_B_DTYPE == B_DTYPE::MXFP8) {
      // Scales layout [E, N, K/group_size] (host transposes from [E,K/32,N]).
      ptr_Scales_curr_batch =
          const_cast<ElementS*>(Scales) + B_offset / group_size;
    } else if constexpr (TENSOR_B_DTYPE == B_DTYPE::BLOCK_FP8) {
      // Block-FP8: scales [E, K/128, N/128] kept in that order.
      ptr_Scales_curr_batch = const_cast<ElementS*>(Scales) +
                              static_cast<int64_t>(expert_id) *
                                  static_cast<int64_t>(gemm_k / group_size) *
                                  static_cast<int64_t>(gemm_n / group_size);
    }
    ElementBI* ptr_Bias_curr_batch = nullptr;
    if (Bias != static_cast<ElementBI*>(nullptr)) {
      ptr_Bias_curr_batch = const_cast<ElementBI*>(Bias) + expert_id * gemm_n;
    }

    auto A_tensor = make_moe_tensor<ElementA, LayoutKindA>(
        ptr_A_curr_batch, gemm_m, gemm_k);
    auto B_tensor = [&]() {
      if constexpr (TENSOR_B_DTYPE == B_DTYPE::INT4) {
        return make_moe_tensor<int4_t, actual_layout_of_B>(
            reinterpret_cast<int4_t*>(ptr_B_curr_batch), gemm_n, gemm_k);
      } else if constexpr (TENSOR_B_DTYPE == B_DTYPE::MXFP4) {
        return make_moe_tensor<float_e2m1_t, actual_layout_of_B>(
            reinterpret_cast<float_e2m1_t*>(ptr_B_curr_batch), gemm_n, gemm_k);
      } else {
        return make_moe_tensor<ElementB, actual_layout_of_B>(
            ptr_B_curr_batch, gemm_n, gemm_k);
      }
    }();
    auto D_tensor = make_moe_tensor<ElementD, LayoutKindD>(
        ptr_D_curr_batch, gemm_m, gemm_n);

    while (group_m_id < cumsum_tiles_for_experts) {
      int n_coord = (group_id * wg_tile_n) % gemm_n_pad / wg_tile_n;
      int m_coord = (group_m_id - pre_tiles);
      auto tile_coord = make_coord(m_coord, n_coord, _, 0);

      if constexpr (
          is_B_4bits || TENSOR_B_DTYPE == B_DTYPE::MXFP8 ||
          TENSOR_B_DTYPE == B_DTYPE::BLOCK_FP8) {
        // MXFP8 reuses the 4-bit block-scale mainloop (E8M0 decode + per-K
        // group B scaling) with float_e4m3/e5m2 weights instead of packed
        // 4-bit. Scale layout must be [N, K/group_size] per expert.
#define XE_GEMM_4BITS_CALLER(GroupSize) \
  xe_gemm_4bits<                        \
      GmemTiledCopyA,                   \
      GmemTiledCopyB,                   \
      GmemTiledCopyD,                   \
      TENSOR_B_DTYPE,                   \
      GroupSize>(                       \
      A_tensor,                         \
      B_tensor,                         \
      ptr_Scales_curr_batch,            \
      ptr_Bias_curr_batch,              \
      D_tensor,                         \
      tile_coord,                       \
      mma);
        if (group_size == 32) {
          XE_GEMM_4BITS_CALLER(32)
        } else if (group_size == 64) {
          XE_GEMM_4BITS_CALLER(64)
        } else if (group_size == 128) {
          XE_GEMM_4BITS_CALLER(128)
        } else if (group_size == 256) {
          XE_GEMM_4BITS_CALLER(256)
        }
#undef XE_GEMM_4BITS_CALLER
      } else {
        xe_gemm<GmemTiledCopyA, GmemTiledCopyB, GmemTiledCopyD>(
            A_tensor,
            B_tensor,
            ptr_Scales_curr_batch,
            ptr_Bias_curr_batch,
            D_tensor,
            tile_coord,
            mma);
      }

      if (local_id == 0) {
        slm_mem[0] = cutlass::atomicAdd(atomic_buffer, 1);
      }
      sycl::group_barrier(item.get_group());
      group_id = group_range + slm_mem[0];
      group_m_id = (group_id * wg_tile_n) / gemm_n_pad;
    }
    pre_rows = cumsum_rows_for_experts;
    pre_tiles = cumsum_tiles_for_experts;
  }
}

}  // namespace MoE
