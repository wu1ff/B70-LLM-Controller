#include "paged_decode_xe2.h"
#include "paged_decode_utils.hpp"
// Use the generated extern header (only declares enabled policies)
#if __has_include("paged_decode_extern_gen.hpp")
  #include "paged_decode_extern_gen.hpp"
#else
  #include "paged_decode_extern.hpp"
#endif

namespace vllm::xpu::xe2 {
using namespace cute;

void cutlass_paged_decode_xe2(
    sycl::queue& queue,
    const at::Tensor& query,      // [seq_q, heads, head_size]
    const at::Tensor& key_cache,  // [num_block, block_size, heads, head_size]
    const at::Tensor& value_cache,
    at::Tensor& out,
    at::Tensor&
        temp_out,  // [batch, num_head_q, seq_q, head_size, num_kv_splits]
    at::Tensor& softmax_lse_accum,  // [batch, num_head_q, seq_q, num_kv_splits]
    const at::Tensor& block_table,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& cu_seqlens_k,
    int max_seqlen_q,
    int max_seqlen_k,
    std::optional<const at::Tensor>& k_scale,
    std::optional<const at::Tensor>& v_scale,
    double sm_scale,
    std::optional<const at::Tensor>& sm_sink_,
    int window_size_left,
    int window_size_right,
    bool is_varlen,
    bool is_paged,
    bool is_causal,
    bool is_local,
    bool is_sink,
    int num_kv_splits,
    std::optional<const at::Tensor>& is_prefill,
    std::optional<at::Tensor>& splits_per_seq,
    std::optional<at::Tensor>& work_list,
    std::optional<at::Tensor>& softmax_lse) {
  cutlass_paged_decode_impl(
      queue,
      query,
      key_cache,
      value_cache,
      out,
      temp_out,
      softmax_lse_accum,
      block_table,
      cu_seqlens_q,
      cu_seqlens_k,
      max_seqlen_q,
      max_seqlen_k,
      k_scale,
      v_scale,
      sm_scale,
      sm_sink_,
      window_size_left,
      window_size_right,
      is_varlen,
      is_paged,
      is_causal,
      is_local,
      is_sink,
      num_kv_splits,
      is_prefill,
      splits_per_seq,
      work_list,
      softmax_lse);
}

inline bool is_single_value_broadcast_tensor(const at::Tensor& t) {
  if (t.scalar_type() != at::ScalarType::Float) {
    return false;
  }
  for (int64_t i = 0; i < t.dim(); ++i) {
    if (t.size(i) > 1 && t.stride(i) != 0) {
      return false;
    }
  }
  return true;
}

void cutlass_paged_decode_impl(
    sycl::queue& queue,
    const at::Tensor& query,      // [seq_q, heads, head_size]
    const at::Tensor& key_cache,  // [num_block, block_size, heads, head_size]
    const at::Tensor& value_cache,
    at::Tensor& out,
    at::Tensor&
        temp_out,  // [batch, num_kv_splits, num_head_q, seq_q, head_size]
    at::Tensor& softmax_lse_accum,  // [batch, num_head_q, seq_q, num_kv_splits]
    const at::Tensor& block_table,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& cu_seqlens_k,
    int max_seqlen_q,
    int max_seqlen_k,
    std::optional<const at::Tensor>& k_scale,
    std::optional<const at::Tensor>& v_scale,
    double sm_scale,
    std::optional<const at::Tensor>& sm_sink_,
    int window_size_left,
    int window_size_right,
    bool is_varlen,
    bool is_paged,
    bool is_causal,
    bool is_local,
    bool is_sink,
    int num_kv_splits,
    std::optional<const at::Tensor>& is_prefill,
    std::optional<at::Tensor>& splits_per_seq,
    std::optional<at::Tensor>& work_list,
    std::optional<at::Tensor>& softmax_lse) {
  bool is_fp8_kv = key_cache.scalar_type() == at::ScalarType::Float8_e5m2 ||
                   key_cache.scalar_type() == at::ScalarType::Float8_e4m3fn;
  if (is_fp8_kv) {
    TORCH_CHECK(
        k_scale.has_value() && v_scale.has_value(),
        "FP8 KV cache requires both k_scale and v_scale tensors to be "
        "provided.");
    TORCH_CHECK(
        k_scale->scalar_type() == at::ScalarType::Float &&
            is_single_value_broadcast_tensor(*k_scale),
        "FP8 KV k_scale must be a float32 tensor with a single element.");
    TORCH_CHECK(
        v_scale->scalar_type() == at::ScalarType::Float &&
            is_single_value_broadcast_tensor(*v_scale),
        "FP8 KV v_scale must be a float32 tensor with a single element.");
  }

  // general params
  int batch_size, num_heads_q, num_heads_kv, head_size, v_head_size;
  // additional params
  int total_seqlen_q, total_seqlen_k;
  int num_blocks, block_size, max_blocks_per_seq;
  if (is_varlen) {
    // query: [total_seq, num_heads, head_size]
    batch_size = cu_seqlens_q.numel() - 1;
    num_heads_q = query.size(1);
    num_heads_kv = key_cache.size(1);
    head_size = query.size(2);
    v_head_size = value_cache.size(-1);
    total_seqlen_q = query.size(0);
    total_seqlen_k = key_cache.size(0);
  } else {
    // query: [batch, num_heads, seq, head_size]
    batch_size = query.size(0);
    num_heads_q = query.size(1);
    num_heads_kv = key_cache.size(1);
    head_size = query.size(3);
    v_head_size = value_cache.size(-1);
    max_seqlen_q = query.size(2);
    max_seqlen_k = key_cache.size(2);
  }

  if (is_paged) {
    // num_blocks is used to build total_seqlen_k for shape_K in kernels
    // it is not just the meaning of used blocks for kv.
    num_blocks = key_cache.size(0);
    block_size = key_cache.size(1);
    num_heads_kv = key_cache.size(2);
    max_blocks_per_seq = block_table.size(1);
    total_seqlen_k = num_blocks * block_size;
  }

  if (is_local) {
    window_size_left = window_size_left == -1 ? max_seqlen_k : window_size_left;
    window_size_right =
        window_size_right == -1 ? max_seqlen_k : window_size_right;
  }

  int page_stride_elements = 0;
  if (is_paged) {
    page_stride_elements =
        static_cast<int>(get_paged_kv_cache_page_stride_elements(key_cache));
  }

  paged_decode_args_t args = {
      query.data_ptr(),
      key_cache.data_ptr(),
      value_cache.data_ptr(),
      out.data_ptr(),
      temp_out.data_ptr(),
      softmax_lse_accum.data_ptr(),
      block_table.data_ptr(),
      cu_seqlens_q.data_ptr(),
      cu_seqlens_k.data_ptr(),
      max_seqlen_q,
      max_seqlen_k,
      total_seqlen_q,
      total_seqlen_k,
      is_fp8_kv ? k_scale.value().data_ptr() : nullptr,
      is_fp8_kv ? v_scale.value().data_ptr() : nullptr,
      static_cast<float>(sm_scale),
      is_sink ? sm_sink_.value().data_ptr() : nullptr,
      batch_size,
      num_heads_q,
      num_heads_kv,
      head_size,
      v_head_size,
      max_blocks_per_seq,
      block_size,
      window_size_left,
      window_size_right,
      is_varlen,  // varlen
      is_paged,   // paged
      is_causal,
      is_local,
      is_sink,
      num_kv_splits,
      nullptr,  // splits_per_seq, filled in below if applicable
      nullptr,  // work_list, filled in below if applicable
      0,        // total_wgs, filled in below if applicable
      key_cache.stride(0),
      key_cache.stride(1),
      key_cache.stride(2),
      value_cache.stride(0),
      value_cache.stride(1),
      value_cache.stride(2),
      is_prefill.has_value() ? is_prefill.value().data_ptr() : nullptr,
      // Q strides: for varlen Q is [total_seq, num_heads, head_size]; for
      // non-varlen Q is [batch, num_heads, seq, head_size].
      is_varlen ? query.stride(0) : query.stride(2),
      is_varlen ? query.stride(1) : query.stride(1),
      is_varlen ? int64_t{0} : query.stride(0),
      page_stride_elements};

  // For non-contiguous paged KV (e.g., cross-layer KV cache), enlarge
  // total_seqlen_k to cover the full physical extent for the 2D block
  // load surface descriptor. Without this, block loads for blocks at
  // higher physical addresses would return zeros.
  if (is_paged) {
    int64_t effective_total =
        get_paged_kv_cache_effective_total_seqlen(key_cache);
    if (effective_total > args.total_seqlen_k) {
      args.total_seqlen_k = static_cast<int>(effective_total);
    }
  }

  // Per-sequence adaptive split-K: use pre-computed splits_per_seq from Python
  // if available. This avoids GPU→CPU sync and extra computation here.
  if (splits_per_seq.has_value() && splits_per_seq->numel() > 0) {
    args.splits_per_seq = splits_per_seq->data_ptr<int>();
  }

  // Per-sequence work_list for compact grid scheduling
  if (work_list.has_value() && work_list->numel() > 0) {
    args.work_list = work_list->data_ptr<int>();
    args.total_wgs = work_list->size(0);  // [total_wgs, 4]
  }

  // Optional softmax_lse output, laid out as (num_heads_q, total_seqlen_q)
  // to match the CUDA/upstream FlashAttention convention (and the layout
  // chunk_prefill writes), so callers need no transpose.
  if (softmax_lse.has_value()) {
    const at::Tensor& lse = softmax_lse.value();
    TORCH_CHECK(
        lse.scalar_type() == at::ScalarType::Float,
        "paged_decode_xe2: softmax_lse must be float32");
    TORCH_CHECK(
        lse.dim() == 2 && lse.size(0) == num_heads_q,
        "paged_decode_xe2: softmax_lse must be (num_heads_q, total_seqlen_q)");
    TORCH_CHECK(
        lse.is_contiguous(),
        "paged_decode_xe2: softmax_lse must be contiguous");
    args.softmax_lse = lse.data_ptr<float>();
    args.lse_stride = static_cast<int>(lse.size(1));
  }

  TORCH_CHECK(
      query.stride(-1) == 1,
      "paged_decode_xe2: query must be contiguous in the last dimension "
      "(head_dim), got stride=",
      query.stride(-1));

  TORCH_CHECK(
      key_cache.stride(-1) == 1,
      "paged_decode_xe2: key_cache must be contiguous in the last dimension "
      "(head_dim), got stride=",
      key_cache.stride(-1));
  TORCH_CHECK(
      value_cache.stride(-1) == 1,
      "paged_decode_xe2: value_cache must be contiguous in the last dimension "
      "(head_dim), got stride=",
      value_cache.stride(-1));

  CutlassQKType cuQKType = aten_to_Cutlass_qk_dtype(query, key_cache);

  static constexpr int max_head_size = 576;
  TORCH_CHECK(
      head_size <= max_head_size,
      "FMHA forward only supports head dimension at most " +
          std::to_string(max_head_size));

  auto get_head_size_case = [](int head_size) -> int {
    if (head_size <= HEAD_SIZE_LIMIT_0) return 0;
    if (head_size <= HEAD_SIZE_LIMIT_1) return 1;
    if (head_size <= HEAD_SIZE_LIMIT_2) return 2;
    if (head_size <= HEAD_SIZE_LIMIT_3) return 3;
    if (head_size <= HEAD_SIZE_LIMIT_4) return 4;
    if (head_size <= HEAD_SIZE_LIMIT_5) return 5;
    if (head_size <= HEAD_SIZE_LIMIT_6) return 6;
    return -1;
  };

  int head_case = get_head_size_case(args.head_size);
  int num_q_group_size = num_heads_q / num_heads_kv;

  // The decode kernel tiles the GQA head-group across the grid's Q dimension
  // (see DecodeTileScheduler::to_underlying_arguments), so the qgroup bucket is
  // a packed-Q tile size rather than a hard cap on the GQA ratio. Ratios <= 8
  // fit a single _8 tile; larger ratios (e.g. falcon-7b's 71 query heads / 1 KV
  // head) are processed by ceil(ratio / qgroup) work-groups using the _16 tile.
  if (num_q_group_size <= 8) {
    dispatch_by_page_size<_8>(block_size, head_case, queue, cuQKType, args);
  } else {
    dispatch_by_page_size<_16>(block_size, head_case, queue, cuQKType, args);
  }
}

}  // namespace vllm::xpu::xe2
