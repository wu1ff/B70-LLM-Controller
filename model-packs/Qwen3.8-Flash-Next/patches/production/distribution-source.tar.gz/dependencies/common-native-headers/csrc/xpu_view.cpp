#include <ATen/ATen.h>
#include "ops.h"
#include <c10/core/Device.h>
#include <c10/xpu/XPUFunctions.h>
#include <memory>

namespace vllm::xpu {

/**
 * @class XPUHostViewAllocator
 * @brief Custom allocator that wraps existing host memory pointers for use with
 * XPU devices
 *
 * This allocator does not actually allocate new memory, but instead uses
 * pre-allocated host memory and wraps it in c10::DataPtr format for use within
 * the XPU system
 */

class XPUHostViewAllocator : public c10::Allocator {
 public:
  struct OwnerContext {
    torch::Tensor owner;
  };

  /**
   * @brief Constructor
   * @param host_ptr Pre-allocated host memory pointer
   * @param size Size of the host memory (in bytes)
   */
  XPUHostViewAllocator(void* host_ptr, size_t size, torch::Tensor owner)
      : host_ptr_(host_ptr), size_(size), owner_(std::move(owner)) {}

  /**
   * @brief Allocate memory (actually just validates and wraps existing host
   * memory)
   * @param n Requested memory size
   * @return Wrapped data pointer
   * @throws Exception if requested size exceeds pre-allocated memory size
   */
  c10::DataPtr allocate(size_t n) override {
    // Verify requested memory size doesn't exceed pre-allocated memory size
    TORCH_CHECK(
        n <= size_, "Requested size exceeds allocated host pointer size");
    // Use unique_ptr for RAII: if current_device() or DataPtr construction
    // throws, the OwnerContext is automatically cleaned up instead of leaked.
    auto ctx = std::make_unique<OwnerContext>(OwnerContext{owner_});
    auto device_id = c10::xpu::current_device();

    c10::DataPtr data_ptr{
        host_ptr_,
        ctx.get(),
        [](void* ptr) { delete static_cast<OwnerContext*>(ptr); },
        c10::Device(c10::DeviceType::XPU, device_id)};

    // DataPtr now owns the context via its deleter — release from unique_ptr.
    ctx.release();
    return data_ptr;
  }

  /**
   * @brief Check if data pointer is a simple pointer (requires no special
   * handling)
   * @param data_ptr Data pointer to check
   * @return Always returns true, indicating this is a simple data pointer
   */
  bool is_simple_data_ptr(const c10::DataPtr& data_ptr) const override {
    return true;
  }

  /**
   * @brief Data copy method
   * @param dest Destination memory address
   * @param src Source memory address
   * @param count Number of bytes to copy
   */
  void
  copy_data(void* dest, const void* src, std::size_t count) const override {
    std::memcpy(dest, src, count);
  }

 private:
  void* const host_ptr_;  // Pre-allocated host memory pointer
  const size_t size_;     // Size of pre-allocated memory
  torch::Tensor owner_;   // Keeps pinned host storage alive
};
}  // namespace vllm::xpu

// This function assumes that `cpu_tensor` is a CPU tensor,
// and that UVA (Unified Virtual Addressing) is enabled. If the given
// `cpu_tensor` is not pinned, a new pinned buffer is allocated and the data is
// copied into it, mirroring the CUDA implementation's fallback behavior.
torch::Tensor get_xpu_view_from_cpu_tensor(torch::Tensor& cpu_tensor) {
  TORCH_CHECK(cpu_tensor.device().is_cpu(), "Input tensor must be on CPU");

  auto device_id = c10::xpu::current_device();
  c10::Device xpu_device(c10::DeviceType::XPU, device_id);

  // Handle empty tensor.
  if (cpu_tensor.numel() == 0) {
    return torch::empty(
        cpu_tensor.sizes(), cpu_tensor.options().device(xpu_device));
  }

  // If the CPU tensor isn't pinned, allocate a new pinned buffer and copy
  // the (contiguous) data into it. Keep this pinned tensor alive as the
  // owner of the resulting view, just like the pinned input tensor would be.
  torch::Tensor pinned_owner;
  if (cpu_tensor.is_pinned()) {
    pinned_owner = cpu_tensor;
  } else {
    pinned_owner = at::empty_strided(
        cpu_tensor.sizes(),
        cpu_tensor.strides(),
        cpu_tensor.options().pinned_memory(true));
    pinned_owner.copy_(cpu_tensor);
  }

  // Get raw host pointer from the pinned tensor.
  void* host_ptr = pinned_owner.data_ptr();

  // We'll use the same sizes, strides, and dtype as the pinned CPU tensor.
  // TODO: check if layout is respected.
  auto sizes = pinned_owner.sizes();
  auto strides = pinned_owner.strides();
  auto scalar_type = pinned_owner.scalar_type();

  // Compute the number of bytes addressable from `host_ptr` given these
  // sizes/strides. This must NOT be `numel() * element_size()`: that is
  // only correct for a "dense" layout (e.g. a plain transpose/permute,
  // where every element in [0, numel) is used exactly once). A tensor with
  // gaps in its strides (e.g. produced by `narrow`/slicing) can require
  // more storage than `numel * element_size` to cover every element it
  // addresses, which would under-declare the view's Storage size. Nor can
  // we simply use `pinned_owner.storage().nbytes()`: when `pinned_owner`
  // is a caller-supplied already-pinned tensor with a non-zero
  // `storage_offset()` (e.g. itself a slice of a larger pinned buffer),
  // that reports the whole underlying storage's size measured from byte 0,
  // not from `host_ptr` (which already starts at the offset) -- that would
  // over-declare the view's size instead. Compute the span directly from
  // sizes/strides so it is correct in both cases.
  int64_t max_elem_offset = 0;
  for (size_t i = 0; i < sizes.size(); ++i) {
    if (sizes[i] > 1) max_elem_offset += (sizes[i] - 1) * strides[i];
  }
  size_t byte_size =
      static_cast<size_t>(max_elem_offset + 1) * pinned_owner.element_size();
  // Keep `pinned_owner` storage alive through the view tensor's lifetime.
  vllm::xpu::XPUHostViewAllocator allocator(host_ptr, byte_size, pinned_owner);
  c10::DataPtr data_ptr = allocator.allocate(byte_size);
  c10::Storage storage(
      c10::Storage::use_byte_size_t(), byte_size, std::move(data_ptr));

  auto impl = c10::make_intrusive<at::TensorImpl>(
      std::move(storage),
      c10::DispatchKeySet(c10::DispatchKey::XPU),
      at::scalarTypeToTypeMeta(scalar_type));

  // Set sizes and strides during construction to avoid extra copy
  impl->set_sizes_and_strides(sizes, strides);

  // Due to from_blob can only accept the device pointer, we use
  //  pluggable-allocator and storage to create tensor
  //  instead of tensor::from_blob
  torch::Tensor xpu_tensor = torch::Tensor::wrap_tensor_impl(impl);

  TORCH_CHECK(
      xpu_tensor.device().is_xpu(), "Resulting tensor is not on XPU device");
  return xpu_tensor;
}
