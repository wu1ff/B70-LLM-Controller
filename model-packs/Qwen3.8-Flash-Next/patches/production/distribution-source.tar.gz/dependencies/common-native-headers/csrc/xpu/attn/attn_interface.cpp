#include "csrc/utils.h"
#include "attn_interface.h"

#ifdef VLLM_XPU_ENABLE_XE2
  #include "csrc/xpu/attn/xe_2/fmha_xe2.h"
  #include "csrc/xpu/attn/xe_2/paged_decode_xe2.h"
#endif
#ifdef VLLM_XPU_ENABLE_XE3P
  #include "csrc/xpu/attn/xe_3/fmha_xe3.h"
  #include "csrc/xpu/attn/xe_3/paged_decode_xe3.h"
#endif

void cutlass_chunk_prefill_interface(
    sycl::queue& queue,
    const at::Tensor& query,      // [seq_q, heads, head_size]
    const at::Tensor& key_cache,  // [num_block, block_size, heads, head_size]
    const at::Tensor& value_cache,
    at::Tensor& out,
    const at::Tensor& block_table,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& cu_seqlens_k,
    int max_seqlen_q,
    int max_seqlen_k,
    std::optional<const at::Tensor>& q_scale,
    std::optional<const at::Tensor>& k_scale,
    std::optional<const at::Tensor>& v_scale,
    double sm_scale,
    std::optional<const at::Tensor>& sm_sink_,
    int window_size_left,
    int window_size_right,
    bool is_varlen,
    bool is_paged,
    bool is_causal,
    bool is_local,
    bool is_sink,
    std::optional<at::Tensor>& softmax_lse,
    std::optional<const at::Tensor>& is_prefill) {
  if (vllm::xpu::is_xe2_arch() || vllm::xpu::is_xe3_arch()) {
#ifdef VLLM_XPU_ENABLE_XE2
    // Use XE2 cutlass kernel (also used as WA for XE3/XE3P)
    vllm::xpu::xe2::cutlass_chunk_prefill_xe2(
        queue,
        query,
        key_cache,
        value_cache,
        out,
        block_table,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        k_scale,
        v_scale,
        sm_scale,
        sm_sink_,
        window_size_left,
        window_size_right,
        is_varlen,
        is_paged,
        is_causal,
        is_local,
        is_sink,
        softmax_lse,
        is_prefill);
#else
    TORCH_CHECK(false, "XE2 cutlass kernel is not enabled in this build.");
#endif
  }
#ifdef VLLM_XPU_ENABLE_XE3P
  else if (vllm::xpu::is_xe3p_arch()) {
    // Use XE3 cutlass kernel
    vllm::xpu::xe3::cutlass_chunk_prefill_xe3(
        queue,
        query,
        key_cache,
        value_cache,
        out,
        block_table,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        q_scale,
        k_scale,
        v_scale,
        sm_scale,
        sm_sink_,
        window_size_left,
        window_size_right,
        is_varlen,
        is_paged,
        is_causal,
        is_local,
        is_sink,
        softmax_lse,
        is_prefill);
  }
#endif
  else {
    TORCH_CHECK(false, "Only XE2/XE3 cutlass kernel is supported currently.");
  }
}

void cutlass_paged_decode_interface(
    sycl::queue& queue,
    const at::Tensor& query,      // [seq_q, heads, head_size]
    const at::Tensor& key_cache,  // [num_block, block_size, heads, head_size]
    const at::Tensor& value_cache,
    at::Tensor& out,
    at::Tensor&
        temp_out,  // [batch, num_head_q, seq_q, head_size, num_kv_splits]
    at::Tensor& softmax_lse_accum,  // [batch, num_head_q, seq_q, num_kv_splits]
    const at::Tensor& block_table,
    const at::Tensor& cu_seqlens_q,
    const at::Tensor& cu_seqlens_k,
    int max_seqlen_q,
    int max_seqlen_k,
    std::optional<const at::Tensor>& q_scale,
    std::optional<const at::Tensor>& k_scale,
    std::optional<const at::Tensor>& v_scale,
    double sm_scale,
    std::optional<const at::Tensor>& sm_sink_,
    int window_size_left,
    int window_size_right,
    bool is_varlen,
    bool is_paged,
    bool is_causal,
    bool is_local,
    bool is_sink,
    int num_kv_splits,
    std::optional<const at::Tensor>& is_prefill,
    std::optional<at::Tensor>& splits_per_seq,
    std::optional<at::Tensor>& work_list,
    std::optional<at::Tensor>& softmax_lse) {
  if (vllm::xpu::is_xe2_arch() || vllm::xpu::is_xe3_arch()) {
#ifdef VLLM_XPU_ENABLE_XE2
    // Use XE2 cutlass kernel (also used as WA for XE3/XE3P)
    vllm::xpu::xe2::cutlass_paged_decode_xe2(
        queue,
        query,
        key_cache,
        value_cache,
        out,
        temp_out,
        softmax_lse_accum,
        block_table,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        k_scale,
        v_scale,
        sm_scale,
        sm_sink_,
        window_size_left,
        window_size_right,
        is_varlen,
        is_paged,
        is_causal,
        is_local,
        is_sink,
        num_kv_splits,
        is_prefill,
        splits_per_seq,
        work_list,
        softmax_lse);
#else
    TORCH_CHECK(false, "XE2 cutlass kernel is not enabled in this build.");
#endif
  }
#ifdef VLLM_XPU_ENABLE_XE3P
  else if (vllm::xpu::is_xe3p_arch()) {
    // Use XE3 cutlass kernel for XE3P (CRI simulator)
    vllm::xpu::xe3::cutlass_paged_decode_xe3(
        queue,
        query,
        key_cache,
        value_cache,
        out,
        temp_out,
        softmax_lse_accum,
        block_table,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        q_scale,
        k_scale,
        v_scale,
        sm_scale,
        sm_sink_,
        window_size_left,
        window_size_right,
        is_varlen,
        is_paged,
        is_causal,
        is_local,
        is_sink,
        num_kv_splits,
        is_prefill,
        splits_per_seq,
        work_list,
        softmax_lse);
  }
#endif
  else {
    TORCH_CHECK(false, "Only XE2/XE3 cutlass kernel is supported currently.");
  }
}
